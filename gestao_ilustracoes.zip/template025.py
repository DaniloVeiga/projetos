import pandas as pd
import dash
from dash import dcc, html, Input, Output, State
from dash.exceptions import PreventUpdate
import plotly.io as pio
import tempfile
from datetime import datetime
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import plotly.express as px
import sqlite3
import openpyxl
import kaleido

# ==========================================
# LEITURA
# ==========================================
# ==========================================
# LEITURA - STATUS POR TIPO DE LIBERAÇÃO
# ==========================================

conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
df = pd.read_sql_query("""SELECT * FROM tipo_ilustracoes""",conexao)
df_geral = pd.read_sql_query("""SELECT * FROM ilustracoes""", conexao)
df_geral0 = pd.read_sql_query("""SELECT * FROM ilustracoes WHERE  grupo_principal == '0.0'""", conexao)
#export segmentado.
conexao.close()
df["distribuicao_tipos_percent"] = df["distribuicao_tipos_percent"].astype(float).round(2)

# ==========================================
# LEITURA - STATUS DA PÁGINA
# ==========================================

conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
df_grupo1 = pd.read_sql_query("""SELECT * FROM status_ilustracoes""",conexao)
conexao.close()
df_grupo1['grupo_principal'] = df_grupo1['grupo_principal'].astype(str)
df_grupo1['status_da_pagina_de_texto'] = df_grupo1['status_da_pagina_de_texto'].astype(str)
df_grupo1['quantidade'] = df_grupo1['quantidade'].astype(int)

# ==========================================
# GRUPO 2
# ==========================================

# ==========================================
# LEITURA - STATUS NÚMERO DE ILUSTRAÇÕES
# ==========================================

conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
df_grupo2 = pd.read_sql_query("""SELECT * FROM numero_ilustracoes""",conexao)
conexao.close()
df_grupo2 = df_grupo2[['grupo_principal','numero_da_ilustracao_devolutiva','quantidade']]
df_grupo2['grupo_principal'] = (df_grupo2['grupo_principal'].astype(str))
df_grupo2['numero_da_ilustracao_devolutiva'] = (df_grupo2['numero_da_ilustracao_devolutiva'].astype(str))
df_grupo2['quantidade'] = (df_grupo2['quantidade'].astype(int))

# ==========================================
# GRUPO 3
# ==========================================
# ==========================================
# LEITURA - STATUS DA DATA DE DIGITALIZAÇÃO
# ==========================================

conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
df_grupo3 = pd.read_sql_query("""SELECT * FROM data_digitalizacoes_ilustracoes""",conexao)
conexao.close()
df_grupo3.columns = ['id','grupo_principal','data_da_digitalizacao_devolutiva','devolutiva','quantidade']
df_grupo3 = df_grupo3[(df_grupo3['data_da_digitalizacao_devolutiva'] != '-') & (df_grupo3['devolutiva'] != '-')].copy()
df_grupo3['grupo_principal'] = (df_grupo3['grupo_principal'].astype(str))
df_grupo3['devolutiva'] = (df_grupo3['devolutiva'].astype(str))
df_grupo3['data_da_digitalizacao_devolutiva'] = (df_grupo3['data_da_digitalizacao_devolutiva'].astype(str))
df_grupo3['quantidade'] = (pd.to_numeric(df_grupo3['quantidade']))

# ==========================================
# GRUPO 4
# ==========================================
# ==========================================
# LEITURA - STATUS POR TIPO DE LIBERAÇÃO
# ==========================================

conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')

df_grupo4 = pd.read_sql_query("""SELECT * FROM data_digitalizacoes_ilustracoes_ir""",conexao)
conexao.close()
df_grupo4.columns = ['id','grupo_principal','data_da_digitalizacao_devolutiva_ir','devolutiva_ir','quantidade']
df_grupo4 = df_grupo4[(df_grupo4['data_da_digitalizacao_devolutiva_ir'] != '-') & (df_grupo4['devolutiva_ir'] != '-')].copy()
df_grupo4['grupo_principal'] = (df_grupo4['grupo_principal'].astype(str))
df_grupo4['devolutiva_ir'] = (df_grupo4['devolutiva_ir'].astype(str))
df_grupo4['data_da_digitalizacao_devolutiva_ir'] = (
df_grupo4['data_da_digitalizacao_devolutiva_ir'].astype(str))
df_grupo4['quantidade'] = (pd.to_numeric(df_grupo4['quantidade']))

# ==========================================
# FUNÇÃO PARA GERAR FIGURA
# ==========================================
def criar_figura(grupo):

    df_filtrado = df[df['grupo_principal'].astype(str) == str(grupo)]
    fig = make_subplots(rows=1,cols=2,specs=[[{"type": "table"}, {"type": "domain"}]],subplot_titles=("Tabela", "Distribuição"))

    # ------------------------------
    # TABELA
    # ------------------------------
    fig.add_trace(go.Table(
            header=dict(values=list(df_filtrado.columns),fill_color="#2C3E50",font=dict(color="white",size=12)),
            cells=dict(values=[df_filtrado[col] for col in df_filtrado.columns])),row=1,col=1)

    # ------------------------------
    # PIZZA
    # ------------------------------
    fig.add_trace(go.Pie(labels=df_filtrado['tipo_de_liberacao'],values=df_filtrado['distribuicao_tipos_percent'],textinfo='percent+label'),row=1,col=2)
    fig.update_layout(title_text=f"Distribuição de Tipos - Grupo {grupo}",title_x=0.5,height=700)

    return fig


# ==========================================
# APP
# ==========================================
app = dash.Dash(__name__)
app.layout = html.Div([
    html.H2("Controle de Ilustrações",style={"textAlign": "center"}),dcc.Tabs([
        # ==================================
        # GUIA PRINCIPAL COM FILTRO
        # ==================================
        dcc.Tab(label="Status por Tipo de Liberação",children=[html.Br(),html.Label("Selecione o Grupo:",style={"fontWeight": "bold"}),
                #dcc.Dropdown(id="filtro-grupo",options=[{"label":"Todos","value":"0"}+{"label": f"Grupo {g}","value": str(g)}
                #    for g in sorted(df['grupo_principal'].astype(str).unique())],value="0",clearable=False, style={"width": "300px","marginBottom": "20px"}),
                dcc.Dropdown(
    id="filtro-grupo",
    options=[
        {"label": "Todos", "value": "0"}
    ] + [
        {"label": f"Grupo {g}", "value": str(g)}
        for g in sorted(df["grupo_principal"].astype(str).unique())
        if str(g) != "0"
    ],
    value="0",
    clearable=False,
    style={"width": "300px", "marginBottom": "20px"}
),
            html.Div([

                    html.Button("Exportar XLSX [SCORE]",id="btn-exportar-tipo-liberacao",style={"backgroundColor": "#27AE60","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                    html.Button("Exportar PNG",id="btn-exportar-png-tipo-liberacao",style={"backgroundColor": "#3498DB","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                    dcc.Download(id="download-tipo-liberacao-xlsx"),
                    dcc.Download(id="download-png-tipo-liberacao")],style={"display": "flex","gap": "10px","marginBottom": "15px"}),
                    dcc.Graph(id="grafico-grupo",figure=criar_figura("0"),
                        config={"displaylogo": False,"modeBarButtonsToRemove": ["toImage"]})]),

        # ==================================
        # DEMAIS GUIAS
        # ==================================
        dcc.Tab(label="Status da Página",children=[html.Br(),html.Div([html.Div([html.Label("Grupo"),
            dcc.Dropdown(id="grupo1_filtro_grupo",options=[{"label": "Todos","value": "Todos"}] + [{"label": grupo,"value": grupo}
                for grupo in sorted(df_grupo1["grupo_principal"].unique())],value="Todos",clearable=False)],style={"width": "45%"}),
                    html.Div([html.Label("Status"),
                              dcc.Dropdown(id="grupo1_filtro_status",value="Todos",clearable=False)],style={"width": "45%"})],style={"display": "flex","justifyContent": "space-around","marginBottom": "20px"}),
                    html.Div([html.Button("Exportar XLSX [SCORE]",id="btn-exportar-grupo1",style={"backgroundColor": "#27AE60","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                                html.Button("Exportar PNG",id="btn-exportar-png-grupo1",style={"backgroundColor": "#3498DB","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                                dcc.Download(id="download-grupo1-xlsx"),
                                dcc.Download(id="download-png-grupo1")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                            dcc.Graph(id="grupo1_grafico",
                                config={"displaylogo": False,"modeBarButtonsToRemove": ["toImage"]}),
                    html.H3("Detalhamento",style={"marginTop": "20px","color": "#2C3E50"}),
                    html.Div(id="grupo1_tabela")]),

        dcc.Tab(label="Status do número da Ilustração",children=[html.Br(),
            html.Div([html.Div([html.Label("Grupo"),dcc.Dropdown(id="grupo2_filtro_grupo",options=[{"label": "Todos","value": "Todos"}] + [{"label": grupo,"value": grupo}
            for grupo in sorted(df_grupo2["grupo_principal"].unique())],value="Todos",clearable=False)],style={"width": "45%"}),
                html.Div([html.Label("Número da Ilustração"),
                    dcc.Dropdown(id="grupo2_filtro_ilustracao",value="Todos",clearable=False)],style={"width": "45%"})],style={"display": "flex","justifyContent": "space-around","marginBottom": "20px"}),
                html.Div([html.Button("Exportar XLSX [SCORE]",id="btn-exportar-grupo2",style={"backgroundColor": "#27AE60","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                            html.Button("Exportar PNG",id="btn-exportar-png-grupo2",style={"backgroundColor": "#3498DB","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                            dcc.Download(id="download-grupo2-xlsx"),
                            dcc.Download(id="download-png-grupo2")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                            dcc.Graph(id="grupo2_grafico",config={"displaylogo": False,"modeBarButtonsToRemove": ["toImage"]}),
                    html.H3("Detalhamento",style={"marginTop": "20px","color": "#2C3E50"}),
                    html.Div(id="grupo2_tabela")]),              
        dcc.Tab(label="Status da Digitalização",children=[html.Br(),
                    html.Div([html.Div([html.Label("Grupo"),
                                    dcc.Dropdown(id="grupo3_filtro_grupo",options=[{"label": "Todos","value": "Todos"}] + [{"label": grupo,"value": grupo}
                                            for grupo in sorted(df_grupo3["grupo_principal"].unique())],value="Todos",clearable=False)],style={"width": "45%"}),html.Div([
                    html.Label("devolutiva"),dcc.Dropdown(id="grupo3_filtro_devolutiva",value="Todos",clearable=False)],style={"width": "45%"})],style={"display": "flex","justifyContent": "space-around","marginBottom": "20px"}),
                    html.Div([html.Button("Exportar XLSX [SCORE]",id="btn-exportar-grupo3",style={"backgroundColor": "#27AE60","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                            html.Button("Exportar PNG",id="btn-exportar-png-grupo3",style={"backgroundColor": "#3498DB","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                            dcc.Download(id="download-grupo3-xlsx"),
                            dcc.Download(id="download-png-grupo3")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                            dcc.Graph(id="grupo3_grafico",config={"displaylogo": False,"modeBarButtonsToRemove": ["toImage"]}),
                            html.H3("Detalhamento",style={"marginTop": "20px","color": "#2C3E50"}),
                            html.Div(id="grupo3_tabela")]),        
                            dcc.Tab(label="Status da Digitalização Real",children=[html.Br(),
                            html.Div([html.Div([html.Label("Grupo"),
                            dcc.Dropdown(id="grupo4_filtro_grupo",options=[{"label": "Todos","value": "Todos"}] + [{"label": grupo,"value": grupo}
                                for grupo in sorted(df_grupo4["grupo_principal"].unique())],value="Todos",clearable=False)],style={"width": "45%"}),
                html.Div([html.Label("Devolutiva IR"), 
                          dcc.Dropdown(id="grupo4_filtro_devolutiva",value="Todos",clearable=False)],style={"width": "45%"})],style={"display": "flex","justifyContent": "space-around","marginBottom": "20px"}),
                html.Div([
                    html.Button("Exportar XLSX [SCORE]",id="btn-exportar-grupo4",style={"backgroundColor": "#27AE60","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                    html.Button("Exportar PNG",id="btn-exportar-png-grupo4",style={"backgroundColor": "#3498DB","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                    dcc.Download(id="download-grupo4-xlsx"),
                    dcc.Download(id="download-png-grupo4")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                    dcc.Graph(id="grupo4_grafico",config={"displaylogo": False,"modeBarButtonsToRemove": ["toImage"]}),
        html.H3("Detalhamento",style={"marginTop": "20px","color": "#2C3E50"}),
        html.Div(id="grupo4_tabela")])])])

# ==========================================
# CALLBACK
# ==========================================
@app.callback(
    Output("grafico-grupo", "figure"),
    Input("filtro-grupo", "value")
)
def atualizar_grafico(grupo):

    return criar_figura(grupo)


@app.callback(
    Output("grupo1_filtro_status", "options"),
    Output("grupo1_filtro_status", "value"),
    Input("grupo1_filtro_grupo", "value")
)
def atualizar_status_grupo1(grupo):

    if grupo == "Todos":

        status_disponiveis = sorted(
            df_grupo1["status_da_pagina_de_texto"].unique()
        )

    else:

        status_disponiveis = sorted(
            df_grupo1.loc[
                df_grupo1["grupo_principal"] == grupo,
                "status_da_pagina_de_texto"
            ].unique()
        )

    options = [
        {
            "label": "Todos",
            "value": "Todos"
        }
    ] + [
        {
            "label": status,
            "value": status
        }
        for status in status_disponiveis
    ]

    return options, "Todos"

@app.callback(
    Output("grupo1_grafico", "figure"),
    Output("grupo1_tabela", "children"),
    Input("grupo1_filtro_grupo", "value"),
    Input("grupo1_filtro_status", "value")
)
def atualizar_visualizacao_grupo1(grupo, status):

    dados = df_grupo1.copy()

    if grupo != "Todos":
        dados = dados[
            dados["grupo_principal"] == grupo
        ]

    if status != "Todos":
        dados = dados[
            dados["status_da_pagina_de_texto"] == status
        ]

    dados_agrupados = (
        dados
        .groupby(
            ["grupo_principal", "status_da_pagina_de_texto"],
            as_index=False
        )["quantidade"]
        .sum()
    )

    fig = px.bar(
        dados_agrupados,
        x="grupo_principal",
        y="quantidade",
        color="status_da_pagina_de_texto",
        text="quantidade",
        barmode="group"
    )

    fig.update_traces(
        textposition="inside",
        textfont_color="white"
    )

    fig.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",
        legend_title="Status",
    )

    tabela = html.Table(

    [

        html.Thead(

            html.Tr(

                [

                    html.Th(
                        coluna,
                        style={
                            "backgroundColor": "#2C3E50",
                            "color": "white",
                            "border": "1px solid black",
                            "padding": "8px",
                            "textAlign": "center",
                            "fontWeight": "bold"
                        }
                    )

                    for coluna in dados_agrupados.columns

                ]

            )

        ),

        html.Tbody(

            [

                html.Tr(

                    [

                        html.Td(
                            dados_agrupados.iloc[i][coluna],
                            style={
                                "border": "1px solid #D3D3D3",
                                "padding": "8px",
                                "textAlign": "center"
                            }
                        )

                        for coluna in dados_agrupados.columns

                    ],

                    style={
                        "backgroundColor":
                            "#F2F2F2"
                            if i % 2 == 0
                            else "white"
                    }

                )

                for i in range(
                    len(dados_agrupados)
                )

            ]

        )

    ],

    style={
        "width": "100%",
        "borderCollapse": "collapse",
        "fontFamily": "Arial",
        "marginTop": "10px"
    }

)
    return fig, tabela

@app.callback(
    Output(
        "grupo2_filtro_ilustracao",
        "options"
    ),
    Output(
        "grupo2_filtro_ilustracao",
        "value"
    ),
    Input(
        "grupo2_filtro_grupo",
        "value"
    )
)
def atualizar_ilustracao_grupo2(grupo):

    if grupo == "Todos":

        ilustracoes = sorted(
            df_grupo2[
                "numero_da_ilustracao_devolutiva"
            ].unique()
        )

    else:

        ilustracoes = sorted(
            df_grupo2.loc[
                df_grupo2[
                    "grupo_principal"
                ] == grupo,
                "numero_da_ilustracao_devolutiva"
            ].unique()
        )

    options = [

        {
            "label": "Todos",
            "value": "Todos"
        }

    ] + [

        {
            "label": item,
            "value": item
        }

        for item in ilustracoes

    ]

    return options, "Todos"

@app.callback(
    Output(
        "grupo2_grafico",
        "figure"
    ),
    Output(
        "grupo2_tabela",
        "children"
    ),
    Input(
        "grupo2_filtro_grupo",
        "value"
    ),
    Input(
        "grupo2_filtro_ilustracao",
        "value"
    )
)
def atualizar_visualizacao_grupo2(
    grupo,
    ilustracao
):

    dados = df_grupo2.copy()

    if grupo != "Todos":

        dados = dados[
            dados[
                "grupo_principal"
            ] == grupo
        ]

    if ilustracao != "Todos":

        dados = dados[
            dados[
                "numero_da_ilustracao_devolutiva"
            ] == ilustracao
        ]

    dados_agrupados = (

        dados

        .groupby(
            [
                "grupo_principal",
                "numero_da_ilustracao_devolutiva"
            ],
            as_index=False
        )["quantidade"]

        .sum()

    )

    fig = px.bar(
        dados_agrupados,
        x="grupo_principal",
        y="quantidade",
        color="numero_da_ilustracao_devolutiva",
        text="quantidade",
        barmode="group"
    )

    fig.update_traces(
        textposition="inside",
        textfont_color="white"
    )

    fig.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",
        legend_title="Número da Ilustração"
    )

    tabela = html.Table(

        [

            html.Thead(

                html.Tr(

                    [

                        html.Th(

                            coluna,

                            style={
                                "backgroundColor": "#2C3E50",
                                "color": "white",
                                "border": "1px solid black",
                                "padding": "8px",
                                "textAlign": "center",
                                "fontWeight": "bold"
                            }

                        )

                        for coluna in dados_agrupados.columns

                    ]

                )

            ),

            html.Tbody(

                [

                    html.Tr(

                        [

                            html.Td(

                                dados_agrupados.iloc[i][coluna],

                                style={
                                    "border": "1px solid #D3D3D3",
                                    "padding": "8px",
                                    "textAlign": "center"
                                }

                            )

                            for coluna in dados_agrupados.columns

                        ],

                        style={
                            "backgroundColor":
                                "#F2F2F2"
                                if i % 2 == 0
                                else "white"
                        }

                    )

                    for i in range(
                        len(dados_agrupados)
                    )

                ]

            )

        ],

        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "fontFamily": "Arial",
            "marginTop": "10px"
        }

    )

    return fig, tabela

@app.callback(
    Output(
        "grupo3_filtro_devolutiva",
        "options"
    ),
    Output(
        "grupo3_filtro_devolutiva",
        "value"
    ),
    Input(
        "grupo3_filtro_grupo",
        "value"
    )
)
def atualizar_devolutiva_grupo3(grupo):

    if grupo == "Todos":

        devolutivas = sorted(
            df_grupo3["data_da_digitalizacao_devolutiva"].unique()
        )

    else:

        devolutivas = sorted(
            df_grupo3.loc[
                df_grupo3["grupo_principal"] == grupo,
                "data_da_digitalizacao_devolutiva"
            ].unique()
        )

    options = [

        {
            "label": "Todos",
            "value": "Todos"
        }

    ] + [

        {
            "label": item,
            "value": item
        }

        for item in devolutivas

    ]

    return options, "Todos"

@app.callback(
    Output(
        "grupo3_grafico",
        "figure"
    ),
    Output(
        "grupo3_tabela",
        "children"
    ),
    Input(
        "grupo3_filtro_grupo",
        "value"
    ),
    Input(
        "grupo3_filtro_devolutiva",
        "value"
    )
)
def atualizar_visualizacao_grupo3(
    grupo,
    devolutiva
):

    dados = df_grupo3.copy()

    if grupo != "Todos":

        dados = dados[
            dados["grupo_principal"] == grupo
        ]

    if devolutiva != "Todos":

        dados = dados[
            dados["data_da_digitalizacao_devolutiva"] == devolutiva
        ]

    dados_agrupados = (

        dados

        .groupby(
            [
                "grupo_principal",
                "data_da_digitalizacao_devolutiva",
                "devolutiva"
            ],
            as_index=False
        )["quantidade"]

        .sum()

    )

    
    
    fig = px.bar(
        dados_agrupados,
        x="grupo_principal",
        y="quantidade",
        color="data_da_digitalizacao_devolutiva",
        text="quantidade",
        barmode="group"
    )

    fig.update_traces(
    textposition="outside"
)

    fig.update_layout(
        plot_bgcolor='white',
        paper_bgcolor='white',
        legend_title='data_da_digitalizacao_devolutiva',
        height=max(
            1000,
            len(dados_agrupados["grupo_principal"].unique()) * 45
        ),
        barmode='group'
    )

    fig.update_xaxes(
        showgrid=True,
        gridcolor='lightgray'
    )

    fig.update_yaxes(
    showgrid=True,
    gridcolor='lightgray',
    showline=True,
    linewidth=1,
    linecolor='lightgray',
    mirror=True
)

    fig.update_xaxes(
        showgrid=False,
        showline=True,
        linewidth=1,
        linecolor='lightgray',
        mirror=True
    )

    fig.update_layout(
        barmode="group",
        bargap=0.30,
        bargroupgap=0.15
    )


    fig.update_traces(
        textposition="inside",
        textfont_color="white"
    )

    fig.update_layout(
        title="Distribuição por Data da Digitalização",
        plot_bgcolor="white",
        paper_bgcolor="white",
        legend_title="data_da_digitalizacao_devolutiva"
    )

    tabela = html.Table(

        [

            html.Thead(

                html.Tr(

                    [

                        html.Th(

                            coluna,

                            style={
                                "backgroundColor": "#2C3E50",
                                "color": "white",
                                "border": "1px solid black",
                                "padding": "8px",
                                "textAlign": "center",
                                "fontWeight": "bold"
                            }

                        )

                        for coluna in dados_agrupados.columns

                    ]

                )

            ),

            html.Tbody(

                [

                    html.Tr(

                        [

                            html.Td(

                                dados_agrupados.iloc[i][coluna],

                                style={
                                    "border": "1px solid #D3D3D3",
                                    "padding": "8px",
                                    "textAlign": "center"
                                }

                            )

                            for coluna in dados_agrupados.columns

                        ],

                        style={
                            "backgroundColor":
                                "#F2F2F2"
                                if i % 2 == 0
                                else "white"
                        }

                    )

                    for i in range(
                        len(dados_agrupados)
                    )

                ]

            )

        ],

        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "fontFamily": "Arial",
            "marginTop": "10px"
        }

    )

    return fig, tabela

@app.callback(
    Output(
        "grupo4_filtro_devolutiva",
        "options"
    ),
    Output(
        "grupo4_filtro_devolutiva",
        "value"
    ),
    Input(
        "grupo4_filtro_grupo",
        "value"
    )
)
def atualizar_devolutiva_grupo4(grupo):

    if grupo == "Todos":

        devolutivas = sorted(
            df_grupo4["data_da_digitalizacao_devolutiva_ir"].unique()
        )

    else:

        devolutivas = sorted(
            df_grupo4.loc[
                df_grupo4["grupo_principal"] == grupo,
                "data_da_digitalizacao_devolutiva_ir"
            ].unique()
        )

    options = [
        {
            "label": "Todos",
            "value": "Todos"
        }
    ] + [
        {
            "label": item,
            "value": item
        }
        for item in devolutivas
    ]

    return options, "Todos"

@app.callback(
    Output(
        "grupo4_grafico",
        "figure"
    ),
    Output(
        "grupo4_tabela",
        "children"
    ),
    Input(
        "grupo4_filtro_grupo",
        "value"
    ),
    Input(
        "grupo4_filtro_devolutiva",
        "value"
    )
)
def atualizar_visualizacao_grupo4(
    grupo,
    devolutiva
):

    dados = df_grupo4.copy()

    if grupo != "Todos":

        dados = dados[
            dados["grupo_principal"] == grupo
        ]

    if devolutiva != "Todos":

        dados = dados[
            #dados["devolutiva_ir"] == devolutiva
            dados["data_da_digitalizacao_devolutiva_ir"] == devolutiva
        ]

    dados_agrupados = (

        dados

        .groupby(
            [
                "grupo_principal",
                "data_da_digitalizacao_devolutiva_ir",
                "devolutiva_ir"
            ],
            as_index=False
        )["quantidade"]

        .sum()

    )

    fig = px.bar(
    dados_agrupados,
    x="grupo_principal",
    y="quantidade",
    color="data_da_digitalizacao_devolutiva_ir",
    text="quantidade",
    barmode="group"
)

    
    fig.update_traces(
        texttemplate="%{y}",
        #textposition="outside"
        textposition="inside"
    )


    fig.update_layout(
        title="Distribuição por Data da Digitalização IR",
        plot_bgcolor="white",
        paper_bgcolor="white",
        legend_title="Data da Digitalização IR",
        barmode="group",
        bargap=0.30,
        bargroupgap=0.15,
        height=700
    )

    fig.update_yaxes(
        showgrid=True,
        gridcolor="lightgray",
        showline=True,
        linewidth=1,
        linecolor="lightgray",
        mirror=True
    )

    fig.update_xaxes(
        showline=True,
        linewidth=1,
        linecolor="lightgray",
        mirror=True
    )

    tabela = html.Table(

        [

            html.Thead(

                html.Tr(

                    [

                        html.Th(

                            coluna,

                            style={
                                "backgroundColor": "#2C3E50",
                                "color": "white",
                                "border": "1px solid black",
                                "padding": "8px",
                                "textAlign": "center",
                                "fontWeight": "bold"
                            }

                        )

                        for coluna in dados_agrupados.columns

                    ]

                )

            ),

            html.Tbody(

                [

                    html.Tr(

                        [

                            html.Td(

                                dados_agrupados.iloc[i][coluna],

                                style={
                                    "border": "1px solid #D3D3D3",
                                    "padding": "8px",
                                    "textAlign": "center"
                                }

                            )

                            for coluna in dados_agrupados.columns

                        ],

                        style={
                            "backgroundColor":
                                "#F2F2F2"
                                if i % 2 == 0
                                else "white"
                        }

                    )

                    for i in range(
                        len(dados_agrupados)
                    )

                ]

            )

        ],

        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "fontFamily": "Arial",
            "marginTop": "10px"
        }

    )

    return fig, tabela


#-botões_exportação
#-btn-1
#tipo_ilustracoes
@app.callback(
    Output("download-tipo-liberacao-xlsx","data"),
    Input("btn-exportar-tipo-liberacao","n_clicks"),
    State("filtro-grupo","value"),
    prevent_initial_call=True
)
def exportar_tipo_liberacao(n_clicks, grupo):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")

    if grupo == "0":
        query = """
            SELECT *
            FROM ilustracoes
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
            SELECT *
            FROM ilustracoes
            WHERE grupo_principal = (? || '.0')
        """
        dados = pd.read_sql_query(
            query,
            conn,
            params=[str(grupo)]
        )

    conn.close()

    nome_arquivo = (
        f"tipo_liberacao_grupo_{grupo}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

#-btn-2
#status_ilustracoes
@app.callback(
    Output("download-grupo1-xlsx", "data"),
    Input("btn-exportar-grupo1", "n_clicks"),
    State("grupo1_filtro_grupo", "value"),
    State("grupo1_filtro_status", "value"),
    prevent_initial_call=True
)
def exportar_grupo1_xlsx(n_clicks, grupo, status):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")

    if grupo == "Todos" and status == "Todos":
        query = """
            SELECT *
            FROM ilustracoes
        """
        dados = pd.read_sql_query(query, conn)

    elif grupo == "Todos":
        query = """
            SELECT *
            FROM ilustracoes
            WHERE status_da_pagina_de_texto = ?
        """
        dados = pd.read_sql_query(query, conn, params=[status])

    elif status == "Todos":
        query = """
            SELECT *
            FROM ilustracoes
            WHERE grupo_principal = (? || '.0')
        """
        dados = pd.read_sql_query(query, conn, params=[grupo])

    else:
        query = """
            SELECT *
            FROM ilustracoes
            WHERE grupo_principal = (? || '.0')
              AND status_da_pagina_de_texto = ?
        """
        dados = pd.read_sql_query(query, conn, params=[grupo, status])

    conn.close()

    nome_arquivo = (
        f"status_ilustracao_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

#-btn-3
#numero_da_ilustracao_devolutiva
@app.callback(
    Output("download-grupo2-xlsx","data"),
    Input("btn-exportar-grupo2","n_clicks"),
    State("grupo2_filtro_grupo","value"),
    State("grupo2_filtro_ilustracao","value"),
    prevent_initial_call=True)

def exportar_grupo2_xlsx(n_clicks, grupo, status):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")

    if grupo == "Todos" and status == "Todos":
        query = """
            SELECT *
            FROM ilustracoes
        """
        dados = pd.read_sql_query(query, conn)

    elif grupo == "Todos":
        query = """
            SELECT *
            FROM ilustracoes
            WHERE numero_da_ilustracao_devolutiva = ?
        """
        dados = pd.read_sql_query(query, conn, params=[status])

    elif status == "Todos":
        query = """
            SELECT *
            FROM ilustracoes
            WHERE grupo_principal = (? || '.0')
        """
        dados = pd.read_sql_query(query, conn, params=[grupo])

    else:
        query = """
            SELECT *
            FROM ilustracoes
            WHERE grupo_principal = (? || '.0')
              AND numero_da_ilustracao_devolutiva = ?
        """
        dados = pd.read_sql_query(query, conn, params=[grupo, status])

    conn.close()

    nome_arquivo = (
        f"status_numero_ilustracao_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

#-btn-4
@app.callback(
    Output("download-grupo3-xlsx", "data"),
    Input("btn-exportar-grupo3", "n_clicks"),
    State("grupo3_filtro_grupo", "value"),
    State("grupo3_filtro_devolutiva", "value"),
    prevent_initial_call=True
)

def exportar_grupo3_xlsx(n_clicks, grupo, status):

    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")

    query = "SELECT * FROM ilustracoes WHERE 1=1"
    params = []

    if grupo != "Todos":
        query += " AND grupo_principal = ?"
        params.append(grupo)

    if status != "Todos":
        query += " AND data_da_digitalizacao_devolutiva = ?"
        params.append(status)

    dados = pd.read_sql_query(
        query,
        conn,
        params=params
    )

    conn.close()

    nome_arquivo = (
        f"status_data_digitalizacao_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

#-btn-5
#data_da_digitalizacao_devolutiva_ir
@app.callback(
    Output("download-grupo4-xlsx", "data"),
    Input("btn-exportar-grupo4", "n_clicks"),
    State("grupo4_filtro_grupo", "value"),
    State("grupo4_filtro_devolutiva", "value"),
    prevent_initial_call=True
)
def exportar_grupo4_xlsx(n_clicks, grupo, status):

    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")

    query = "SELECT * FROM ilustracoes WHERE 1=1"
    params = []

    if grupo != "Todos":
        query += " AND grupo_principal = ?"
        params.append(grupo)

    if status != "Todos":
        query += " AND data_da_digitalizacao_devolutiva_ir = ?"
        params.append(status)

    dados = pd.read_sql_query(
        query,
        conn,
        params=params
    )

    conn.close()

    nome_arquivo = (
        f"status_data_digitalizacao_REAL_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )


#-png-1
@app.callback(
    Output("download-png-tipo-liberacao","data"),
    Input("btn-exportar-png-tipo-liberacao","n_clicks"),
    State("grafico-grupo","figure"),
    prevent_initial_call=True)
def exportar_png_tipo_liberacao(n_clicks,figura):
    if not figura: raise PreventUpdate
    fig = pio.from_json(pio.to_json(figura))
    with tempfile.NamedTemporaryFile(delete=False,suffix=".png") as tmp: caminho = tmp.name
    fig.write_image(caminho,format="png",width=1800,height=900)
    return dcc.send_file(caminho)

#-png-2
@app.callback(
    Output("download-png-grupo1","data"),
    Input("btn-exportar-png-grupo1","n_clicks"),
    State("grupo1_grafico","figure"),
    prevent_initial_call=True)

def exportar_png_grupo1(n_clicks,figura):
    if not figura: raise PreventUpdate
    fig = go.Figure(figura)
    with tempfile.NamedTemporaryFile( delete=False,suffix=".png") as tmp: caminho = tmp.name
    fig.write_image(caminho,engine="kaleido",format="png",width=1800,height=900)
    return dcc.send_file(caminho)

#-png-3
@app.callback(
    Output("download-png-grupo2","data"),
    Input("btn-exportar-png-grupo2","n_clicks"),
    State("grupo2_grafico","figure"),
    prevent_initial_call=True)
def exportar_png_grupo2(n_clicks,figura):
    if not figura: raise PreventUpdate
    fig = go.Figure(figura)
    with tempfile.NamedTemporaryFile(delete=False,suffix=".png") as tmp: caminho = tmp.name
    fig.write_image(caminho,engine="kaleido",format="png",width=1800,height=900)
    return dcc.send_file(caminho)

#-png-4
@app.callback(
    Output("download-png-grupo3","data"),
    Input("btn-exportar-png-grupo3","n_clicks"),
    State("grupo3_grafico","figure"),
    prevent_initial_call=True
)
def exportar_png_grupo3(n_clicks,figura):
    if not figura: raise PreventUpdate
    fig = go.Figure(figura)
    with tempfile.NamedTemporaryFile(delete=False,suffix=".png") as tmp: caminho = tmp.name
    fig.write_image(caminho,engine="kaleido",format="png",width=1800,height=900)
    return dcc.send_file(caminho)

#-png-5
@app.callback(
    Output("download-png-grupo4","data"),
    Input("btn-exportar-png-grupo4","n_clicks"),
    State("grupo4_grafico","figure"),
    prevent_initial_call=True)

def exportar_png_grupo4(n_clicks,figura):
    if not figura: raise PreventUpdate
    fig = go.Figure(figura)
    with tempfile.NamedTemporaryFile(delete=False,suffix=".png") as tmp: caminho = tmp.name
    fig.write_image(caminho,engine="kaleido",format="png",width=1800,height=900)
    return dcc.send_file(caminho)

# ==========================================
# EXECUÇÃO
# ==========================================
if __name__ == "__main__":
    app.run(debug=True,port=8051)