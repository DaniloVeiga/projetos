import glob
import time
import pandas as pd
import os
import sqlite3
import numpy as np
import subprocess

def cria_pastas():
    os.makedirs('base_consulta', exist_ok=True)
    os.makedirs('base_convertida', exist_ok=True)
    os.makedirs('base_compilada', exist_ok=True)
    os.makedirs('base_compilada\distribuicao', exist_ok=True)
    os.makedirs('base_sql', exist_ok=True)

def cria_banco_ilustracoes():
    conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
    cursor_ilustracoes = conexao.cursor()
    cursor_ilustracoes = cursor_ilustracoes.execute('''
    CREATE TABLE IF NOT EXISTS ilustracoes(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                indice_base TEXT,
                pagina_de_texto TEXT,
                grupo_principal TEXT,
                subgrupo TEXT,
                tipo_de_liberacao TEXT,
                area_do_assunto TEXT,
                status_da_pagina_de_texto TEXT,
                tipo_de_pagina_de_texto TEXT,
                numero_da_ilustracao TEXT,
                data_da_digitalizacao TEXT,
                data_da_digitalização_da_ilustracao_real TEXT,
                associado_a_um_conjunto_de_construcao TEXT, 
                relevante_para_EBV TEXT,
                data_de_publicacao TEXT,
                denominacao TEXT,
                observacao TEXT,
                modelo TEXT,
                modelo_EUA TEXT,
                aplicacao TEXT,
                obsoletos TEXT,
                ultima_modificacao TEXT,
                base TEXT,
                modelo_RDW TEXT,
                ano_corrente TEXT,
                sla_digitalizacao_anos TEXT,
                sla_digitalizacao_real_anos TEXT,
                data_da_digitalizacao_triagem TEXT,
                data_da_digitalizacao_real_triagem TEXT,
                numero_da_ilustracao_devolutiva TEXT,
                data_da_digitalizacao_devolutiva TEXT,
                data_da_digitalizacao_devolutiva_ir TEXT,
                UNIQUE(indice_base, pagina_de_texto, numero_da_ilustracao, base)                                                                                                                                                                                
                                                    )
                                                    ''')
    conexao.commit()
    conexao.close()


def pacote_consulta():
    lista_arquivo = []
    arquivos = glob.glob(r'.\txt_catalogo\*.txt')
    n_arquivos = len(arquivos)

    for i in range(n_arquivos):
        lista_arquivo.append(arquivos[i][15:])

        #print(arquivos[i][15:])

    print('Total de arquivo(s) capturado(s).: {} arquivo(s) txt.'.format(n_arquivos))
    tabela = {'Ilustações Capuradas':lista_arquivo}
    df_tabela = pd.DataFrame(tabela)
    df_tabela.to_excel(r'.\base_consulta\indice_ilustações_txt.xlsx', index=False, sheet_name='Ilstrurações')


def importador():
    leitor = pd.read_excel(r'.\base_consulta\indice_ilustações_txt.xlsx')
    n_linhas = len(leitor)

    for i in range(n_linhas):
        nome_arquivo = leitor.iloc[i, 0]
        print('Base {} convertida com sucesso.'.format(nome_arquivo))
        #stime.sleep(1)
        caminho_csv = os.path.join('.\\txt_catalogo', nome_arquivo)
        df = pd.read_csv(caminho_csv,encoding='latin-1',sep='\t',quotechar='"',skiprows=1  # ignora "Classificação de dados: confidencial"
    )
        df['base'] = nome_arquivo
        nome_excel = nome_arquivo.replace('.txt', '.xlsx')
        df.to_excel('.\\base_convertida\\{}'.format(nome_excel), index=False)

def pacote_consulta_xlsx():
    lista_arquivo = []
    arquivos = glob.glob(r'.\base_convertida\*.xlsx')
    n_arquivos = len(arquivos)

    for i in range(n_arquivos):
        lista_arquivo.append(arquivos[i][18:])

    print('Total de arquivo(s) capturado(s).: {} arquivo(s) xlsx.'.format(n_arquivos))
    tabela = {'Ilustações Capuradas':lista_arquivo}
    df_tabela = pd.DataFrame(tabela)
    df_tabela.to_excel(r'.\base_consulta\indice_ilustações_xlsx.xlsx', index=False, sheet_name='Ilstrurações')

def compilador():
    lista_dfs = []
    
    leitor = pd.read_excel(r'.\base_consulta\indice_ilustações_xlsx.xlsx')
    
    base_dir = r'base_convertida'
    
    for i in range(len(leitor)):
        nome_arquivo = leitor.iloc[i, 0]
        caminho_completo = os.path.join(base_dir, nome_arquivo)
        
        if os.path.exists(caminho_completo):
            df = pd.read_excel(caminho_completo)
            lista_dfs.append(df)
            print(f'{nome_arquivo} carregado')
        else:
            print(f'Arquivo não encontrado: {caminho_completo}')
        
        time.sleep(0.2)
    
    if lista_dfs:
        df_final = pd.concat(lista_dfs, ignore_index=True)
        df_final.to_excel(r'.\base_compilada\base_compilada.xlsx', index=False)
        print('Arquivo final gerado')
    else:
        print('Nenhum arquivo foi carregado')

def adequacao_base():
    caminho = r'.\base_compilada\base_compilada.xlsx'

    df = pd.read_excel(caminho)

    # Primeiro converte a coluna inteira para string
    df[df.columns[range(14)]] = df[df.columns[range(14)]].astype('string')
    df[df.columns[15]] = df[df.columns[15]].astype('string')
    df[df.columns[16]] = df[df.columns[16]].astype('string')
    df[df.columns[17]] = df[df.columns[17]].astype('string')
    df[df.columns[18]] = df[df.columns[18]].astype('string')
    df[df.columns[19]] = df[df.columns[19]].astype('string')
    df[df.columns[20]] = df[df.columns[20]].astype('string')
    df[df.columns[22]] = df[df.columns[22]].astype('string')

    # Depois trata os nulos
    df[df.columns[range(14)]] = df[df.columns[range(14)]].fillna('-')
    df[df.columns[15]] = df[df.columns[15]].fillna('-')
    df[df.columns[16]] = df[df.columns[16]].fillna('-')
    df[df.columns[17]] = df[df.columns[17]].fillna('-')
    df[df.columns[18]] = df[df.columns[18]].fillna('-')
    df[df.columns[19]] = df[df.columns[19]].fillna('-')
    df[df.columns[20]] = df[df.columns[20]].fillna('-')
    df[df.columns[22]] = df[df.columns[22]].fillna('-')

    df.rename(columns={df.columns[0]:'indice_base'}, inplace=True)

    # Salvar
    df.to_excel(r'.\base_compilada\base_compilada_adq.xlsx', index=False)
    print('Base adequada com sucesso!!!')

def adq_filtro():
    arquivo = (r'.\base_compilada\base_compilada_adq.xlsx')
    lista_coluna001 = []
    lista_coluna002 = []
    lista_coluna003 = []
    lista_coluna004 = []
    lista_coluna005 = []
    lista_coluna006 = []
    lista_coluna007 = []
    lista_coluna008 = []
    lista_coluna009 = []
    lista_coluna010 = []
    lista_coluna011 = []
    lista_coluna012 = []
    lista_coluna013 = []
    lista_coluna014 = []
    lista_coluna015 = []
    lista_coluna016 = []
    lista_coluna017 = []
    lista_coluna018 = []
    lista_coluna019 = []
    lista_coluna020 = []
    lista_coluna021 = []
    lista_coluna022 = []
    lista_coluna023 = []
    lista_coluna024 = []
    lista_coluna025 = []
    lista_coluna026 = []
    lista_coluna027 = []
    lista_coluna028 = []
    #lista_coluna029 = []
    lista_coluna030 = []
    #lista_coluna031 = []
    lista_coluna032 = []
    lista_coluna033 = []
    leitor = pd.read_excel(arquivo)
    base_ilustracao_filtrada = leitor[(leitor['indice_base']!='-')]
    conta_linha = len(base_ilustracao_filtrada)
    for a in range(conta_linha):
        lista_coluna001.append(base_ilustracao_filtrada.iloc[a,0])
        lista_coluna002.append(base_ilustracao_filtrada.iloc[a,1])
        lista_coluna003.append(base_ilustracao_filtrada.iloc[a,2])
        lista_coluna004.append(base_ilustracao_filtrada.iloc[a,3])
        lista_coluna005.append(base_ilustracao_filtrada.iloc[a,4])
        lista_coluna006.append(base_ilustracao_filtrada.iloc[a,5])
        lista_coluna007.append(base_ilustracao_filtrada.iloc[a,6])
        lista_coluna008.append(base_ilustracao_filtrada.iloc[a,7])
        lista_coluna009.append(base_ilustracao_filtrada.iloc[a,8])
        lista_coluna010.append(base_ilustracao_filtrada.iloc[a,9][0:4])
        lista_coluna011.append(base_ilustracao_filtrada.iloc[a,10][0:4])
        lista_coluna012.append(base_ilustracao_filtrada.iloc[a,11])
        lista_coluna013.append(base_ilustracao_filtrada.iloc[a,12])
        lista_coluna014.append(base_ilustracao_filtrada.iloc[a,13])
        lista_coluna015.append(base_ilustracao_filtrada.iloc[a,14])
        lista_coluna016.append(base_ilustracao_filtrada.iloc[a,15])
        lista_coluna017.append(base_ilustracao_filtrada.iloc[a,16])
        lista_coluna018.append(base_ilustracao_filtrada.iloc[a,17])
        lista_coluna019.append(base_ilustracao_filtrada.iloc[a,18])
        lista_coluna020.append(base_ilustracao_filtrada.iloc[a,19])
        lista_coluna021.append(base_ilustracao_filtrada.iloc[a,20][0:4])
        lista_coluna022.append(base_ilustracao_filtrada.iloc[a,21])
        lista_coluna023.append(base_ilustracao_filtrada.iloc[a,22])
        if lista_coluna010[a] == '-':
            lista_coluna024.append('-')
        else:
            lista_coluna024.append(pd.Timestamp.now().year)
        if lista_coluna010[a] == '-':
            lista_coluna025.append('-')
        else:
            lista_coluna025.append(int(lista_coluna024[a])-int(lista_coluna010[a]))
        if lista_coluna011[a] == '-':
            lista_coluna026.append('-')
        else:
            lista_coluna026.append(int(lista_coluna024[a])-int(lista_coluna011[a]))
        if lista_coluna025[a] == '-':
            lista_coluna027.append('-')
        elif lista_coluna025[a] > 0 and lista_coluna025[a] <= 20:
            lista_coluna027.append('Digitalização há menos de 20 anos')
        else:
            lista_coluna027.append('Digitalização há mais de 20 anos')
        if lista_coluna026[a] == '-':
            lista_coluna028.append('-')
        elif lista_coluna026[a] <= 20:
            lista_coluna028.append('Digitalização há menos de 20 anos')
        elif lista_coluna026[a] > 20:
            lista_coluna028.append('Digitalização há mais de 20 anos')

        lista_coluna010 = [item.replace('-', 'nulo') if isinstance(item, str) else item for item in lista_coluna010]
        lista_coluna011 = [item.replace('-', 'nulo') if isinstance(item, str) else item for item in lista_coluna011]
        lista_coluna024 = [item.replace('-', 'nulo') if isinstance(item, str) else item for item in lista_coluna024]
        lista_coluna025 = [item.replace('-', 'nulo') if isinstance(item, str) else item for item in lista_coluna025]
        lista_coluna026 = [item.replace('-', 'nulo') if isinstance(item, str) else item for item in lista_coluna026]
        lista_coluna027 = [item.replace('-', 'nulo') if isinstance(item, str) else item for item in lista_coluna027]
        lista_coluna028 = [item.replace('-', 'nulo') if isinstance(item, str) else item for item in lista_coluna028]

        lista_coluna030.append(np.where(lista_coluna009[a] == '-','TEM QUE INCLUIR IMAGEM','JÁ TEM IMAGEM'))

        #if lista_coluna027[a] == 'nulo' or lista_coluna027[a] == 'Digitalização há mais de 20 anos':
        #    lista_coluna033.append('TEM QUE INCLUIR IMAGEM')
        #else:
        #    lista_coluna033.append('JÁ TEM IMAGEM')
        if lista_coluna025[a] == 'nulo':
            lista_coluna033.append('TEM QUE INCLUIR IMAGEM')
        elif lista_coluna025[a] <= 20:
            lista_coluna033.append('JÁ TEM IMAGEM')
        else:  # > 20
            lista_coluna033.append('TEM QUE INCLUIR IMAGEM')

        if lista_coluna026[a] == 'nulo':
            lista_coluna032.append('TEM QUE INCLUIR IMAGEM')
        elif lista_coluna026[a] <= 20:
            lista_coluna032.append('JÁ TEM IMAGEM')
        else:  # > 20
            lista_coluna032.append('TEM QUE INCLUIR IMAGEM')

        #if lista_coluna028[a] == 'nulo' or lista_coluna028[a] == 'Digitalização há mais de 20 anos':
        #    lista_coluna032.append('TEM QUE INCLUIR IMAGEM')
        #else:
        #    lista_coluna032.append('JÁ TEM IMAGEM')
        
    tabela = {
        'indice_base':pd.Series(lista_coluna001),
        'Página de texto':pd.Series(lista_coluna002),
        'Grupo principal':pd.Series(lista_coluna003),
        'Subgrupo':pd.Series(lista_coluna004),
        'Tipo de liberação':pd.Series(lista_coluna005),
        'Área do assunto':pd.Series(lista_coluna006),
        'Status da página de texto':pd.Series(lista_coluna007),
        'Tipo de página de texto':pd.Series(lista_coluna008),
        'Número da ilustração':pd.Series(lista_coluna009),
        'Data da digitalização':pd.Series(lista_coluna010),
        'Data da digitalização da ilustração real':pd.Series(lista_coluna011),
        'Associado a um conjunto de construção':pd.Series(lista_coluna012),
        'Relevante para EBV':pd.Series(lista_coluna013),
        'Data de publicação':pd.Series(lista_coluna014),
        'Denominação':pd.Series(lista_coluna015),
        'Observação':pd.Series(lista_coluna016),
        'Modelo':pd.Series(lista_coluna017),
        'Modelo EUA':pd.Series(lista_coluna018),
        'Aplicação':pd.Series(lista_coluna019),
        'Obsoletos':pd.Series(lista_coluna020),
        'última modificação':pd.Series(lista_coluna021),
        'base':pd.Series(lista_coluna022),
        'Modelo RDW':pd.Series(lista_coluna023),
        'Ano corrente':pd.Series(lista_coluna024),
        'SLA digitalização [anos]':pd.Series(lista_coluna025),
        'SLA digitalização Real [anos]':pd.Series(lista_coluna026),
        'data_da_digitalizacao_triagem':pd.Series(lista_coluna027),
        'data_da_digitalizacao_real_triagem':pd.Series(lista_coluna028),
        'numero_da_ilustracao_devolutiva':pd.Series(lista_coluna030),
        'data_da_digitalizacao_devolutiva':pd.Series(lista_coluna033),
        'data_da_digitalizacao_devolutiva_IR':pd.Series(lista_coluna032),
        #'Borderô':pd.Series(lista_coluna029)
    }

    df_tabela = pd.DataFrame(tabela)
    df_tabela_filtrada = df_tabela[(df_tabela['Página de texto']!='999-099')]
    df_tabela_filtrada.to_excel(r'.\base_compilada\base_compilada_adq_filtrada.xlsx',index=False)

def tipo_libercao():
    leitor = pd.read_excel(r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    df_leitor = leitor.groupby(['Grupo principal', 'Tipo de liberação']).size().reset_index(name='Quantidade').sort_values(['Grupo principal', 'Tipo de liberação'])
    df_leitor.to_excel(r'.\base_compilada\base_compilada_tipo_liberacao.xlsx', index=False)

def tipo_libercao_distribuicao():
    leitor = pd.read_excel(r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    df_leitor = leitor.groupby(['Grupo principal', 'Tipo de liberação']).size().reset_index(name='Quantidade').sort_values(['Grupo principal', 'Tipo de liberação'])
    total_grupo = leitor.groupby('Grupo principal').size()
    df_leitor['Quantidade Grupo'] = df_leitor['Grupo principal'].map(total_grupo)
    df_leitor['Distribuicao Tipos %'] = (df_leitor['Quantidade'] / df_leitor['Quantidade Grupo'])*100
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_compilada_tipo_liberacao_distribuicao.xlsx', index=False)

def status_da_pagina_de_texto():
    leitor = pd.read_excel(r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    df_leitor = leitor.groupby(['Grupo principal','Status da página de texto']).size().reset_index(name='Quantidade').sort_values(['Grupo principal', 'Status da página de texto'])
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_compilada_status_da_pagina_de_texto.xlsx', index=False)

def numero_da_ilustracao():
    leitor = pd.read_excel(r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    df_leitor = leitor.groupby(['Grupo principal','Número da ilustração']).size().reset_index(name='Quantidade').sort_values(['Grupo principal', 'Número da ilustração'])
    df_leitor.to_excel(r'.\base_compilada\base_compilada_numero_da_ilustracao.xlsx', index=False)

def numero_da_ilustracao_distribuicao():
    leitor = pd.read_excel(r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    df_leitor = leitor.filter(items=['Grupo principal','numero_da_ilustracao_devolutiva'])
    df_leitor = df_leitor.groupby(['Grupo principal','numero_da_ilustracao_devolutiva']).size().reset_index(name='Quantidade').sort_values(['Grupo principal','numero_da_ilustracao_devolutiva'])
    total_grupo = leitor.groupby('Grupo principal').size()
    df_leitor['Quantidade Grupo'] = df_leitor['Grupo principal'].map(total_grupo)
    df_leitor['Distribuicao numero_da_ilustracao %'] = (df_leitor['Quantidade'] / df_leitor['Quantidade Grupo'])*100
    df_leitor['Distribuicao numero_da_ilustracao %'] = df_leitor['Distribuicao numero_da_ilustracao %'].round(2)
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_compilada_numero_da_ilustracao_distribuicao.xlsx', index=False)

def data_da_digitalizacao():
    leitor = pd.read_excel(r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    df_leitor = leitor.groupby(['Grupo principal','Data da digitalização']).size().reset_index(name='Quantidade').sort_values(['Grupo principal', 'Data da digitalização'])
    df_leitor.to_excel(r'.\base_compilada\base_compilada_data_da_digitalizacao.xlsx', index=False)

def data_da_digitalizacao_distribuicao():
    arquivo = (r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    leitor = pd.read_excel(arquivo)
    conta_linha = len(leitor)
    lista_coluna001 = []
    lista_coluna002 = []
    lista_coluna003 = []
    lista_coluna004 = []

    for a in range(conta_linha):
        lista_coluna001.append(str(leitor.iloc[a,2]))
        lista_coluna002.append(str(leitor.iloc[a,29]))
        #lista_coluna003.append(str(leitor.iloc[a,24]))
        lista_coluna004.append(str(leitor.iloc[a,26]))

    tabela = {
        'Grupo_principal':pd.Series(lista_coluna001),
        'data_da_digitalizacao_devolutiva':pd.Series(lista_coluna002),
        #'SLA [ANOS]':pd.Series(lista_coluna003),
        'Devolutiva':pd.Series(lista_coluna004)
    }

    df_tabela = pd.DataFrame(tabela)
    df_tabela.index.name='ID'

    df_classificacao = df_tabela.groupby(['Grupo_principal','data_da_digitalizacao_devolutiva','Devolutiva']
                                         ).size().reset_index(name='Quantidade').sort_values([
                                             'Grupo_principal','data_da_digitalizacao_devolutiva','Devolutiva'])

    
    df_classificacao.to_excel(r'.\base_compilada\distribuicao\base_compilada_data_da_digitalizacao_distribuicao.xlsx', index=False)


def data_da_digitalizacao_da_ilustracao_real():
    leitor = pd.read_excel(r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    df_leitor = leitor.groupby(['Grupo principal','Data da digitalização da ilustração real']).size().reset_index(name='Quantidade').sort_values(['Grupo principal', 'Data da digitalização da ilustração real'])
    df_leitor.to_excel(r'.\base_compilada\base_compilada_data_da_digitalização_da_ilustracao_real.xlsx', index=False)

def data_da_digitalizacao_distribuicao_IR():
    arquivo = (r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    leitor = pd.read_excel(arquivo)
    conta_linha = len(leitor)
    lista_coluna001 = []
    lista_coluna002 = []
    lista_coluna003 = []
    lista_coluna004 = []

    for a in range(conta_linha):
        lista_coluna001.append(str(leitor.iloc[a,2]))
        lista_coluna002.append(str(leitor.iloc[a,30]))
        #lista_coluna003.append(str(leitor.iloc[a,25]))
        lista_coluna004.append(str(leitor.iloc[a,27]))

    tabela = {
        'Grupo_principal':pd.Series(lista_coluna001),
        'data_da_digitalizacao_devolutiva_IR':pd.Series(lista_coluna002),
        #'SLA_IR [ANOS]':pd.Series(lista_coluna003),
        'Devolutiva_IR':pd.Series(lista_coluna004)
    }

    df_tabela = pd.DataFrame(tabela)
    df_tabela.index.name='ID'

    df_classificacao = df_tabela.groupby(['Grupo_principal','data_da_digitalizacao_devolutiva_IR','Devolutiva_IR']
                                         ).size().reset_index(name='Quantidade').sort_values([
                                             'Grupo_principal','data_da_digitalizacao_devolutiva_IR','Devolutiva_IR'])

   
    df_classificacao.to_excel(r'.\base_compilada\distribuicao\base_compilada_data_da_digitalizacao_distribuicao_IR.xlsx', index=False)

def formatar_data(valor):
    if pd.isna(valor):
        return None
    try:
        return valor.strftime('%d/%m/%Y')
    except:
        return None

def importador_ilustracoes():
    leitor = pd.read_excel(r'.\base_compilada\base_compilada_adq_filtrada.xlsx')
    conta_linhas = len(leitor)
    # ---------- CONEXÃO ----------
    conexao = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")
    cursor = conexao.cursor()

    # ---------- QUERY CORRIGIDA ----------
    query = """
    INSERT OR IGNORE INTO ilustracoes (
        indice_base,
        pagina_de_texto,
        grupo_principal,
        subgrupo,
        tipo_de_liberacao,
        area_do_assunto,
        status_da_pagina_de_texto,
        tipo_de_pagina_de_texto,
        numero_da_ilustracao,
        data_da_digitalizacao,
        data_da_digitalização_da_ilustracao_real,
        associado_a_um_conjunto_de_construcao,
        relevante_para_EBV,
        data_de_publicacao,
        denominacao,
        observacao,
        modelo,
        modelo_EUA,
        aplicacao,
        obsoletos,
        ultima_modificacao,
        base,
        modelo_RDW,
        ano_corrente,
        sla_digitalizacao_anos,
        sla_digitalizacao_real_anos,
        data_da_digitalizacao_triagem,
        data_da_digitalizacao_real_triagem,
        numero_da_ilustracao_devolutiva,
        data_da_digitalizacao_devolutiva,
        data_da_digitalizacao_devolutiva_ir
        )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """

    # ---------- LOOP ----------
    for i in range(conta_linhas):
        valores = (
            leitor.iloc[i, 0],
            leitor.iloc[i, 1],
            leitor.iloc[i, 2],
            leitor.iloc[i, 3],
            leitor.iloc[i, 4],
            leitor.iloc[i, 5],
            leitor.iloc[i, 6],
            leitor.iloc[i, 7],
            leitor.iloc[i, 8],
            leitor.iloc[i, 9],
            leitor.iloc[i, 10],
            leitor.iloc[i, 11],
            leitor.iloc[i, 12],
            leitor.iloc[i, 13],
            leitor.iloc[i, 14],
            leitor.iloc[i, 15],
            leitor.iloc[i, 16],
            leitor.iloc[i, 17],
            leitor.iloc[i, 18],
            leitor.iloc[i, 19],
            leitor.iloc[i, 20],
            leitor.iloc[i, 21],
            leitor.iloc[i, 22],
            leitor.iloc[i, 23],
            leitor.iloc[i, 24],
            leitor.iloc[i, 25],
            leitor.iloc[i, 26],
            leitor.iloc[i, 27],
            leitor.iloc[i, 28],
            leitor.iloc[i, 29],
            leitor.iloc[i, 30],
        )

        cursor.execute(query, valores)

    conexao.commit()
    conexao.close()

def criar_base_tipo():
    conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
    cursor_ilustracoes = conexao.cursor()
    cursor_ilustracoes = cursor_ilustracoes .execute('''
    CREATE TABLE IF NOT EXISTS tipo_ilustracoes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        grupo_principal TEXT,            
        tipo_de_liberacao TEXT,
        quantidade TEXT,
        quantidade_grupo TEXT,
        distribuicao_tipos_percent TEXT,
        UNIQUE(grupo_principal, tipo_de_liberacao, quantidade, quantidade_grupo,distribuicao_tipos_percent)    
        )
                                                     ''')
    conexao.commit()
    conexao.close()

def criar_base_status():
    conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
    cursor_ilustracoes = conexao.cursor()
    cursor_ilustracoes = cursor_ilustracoes .execute('''
    CREATE TABLE IF NOT EXISTS status_ilustracoes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        grupo_principal TEXT,            
        status_da_pagina_de_texto TEXT,
        quantidade TEXT,
        UNIQUE(grupo_principal, status_da_pagina_de_texto, quantidade)
        )
                                                     ''')
    conexao.commit()
    conexao.close()

def criar_base_num():
    conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
    cursor_ilustracoes = conexao.cursor()
    cursor_ilustracoes = cursor_ilustracoes .execute('''
    CREATE TABLE IF NOT EXISTS numero_ilustracoes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        grupo_principal TEXT,            
        numero_da_ilustracao_devolutiva TEXT,
        quantidade TEXT,
        quantidade_grupo TEXT,
        distribuicao_numero_da_ilustracao_percent TEXT,
        UNIQUE(grupo_principal,numero_da_ilustracao_devolutiva,quantidade, quantidade_grupo, distribuicao_numero_da_ilustracao_percent)
        )
                                                     ''')
    conexao.commit()
    conexao.close()

def criar_base_ddigit():
    conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
    cursor_ilustracoes = conexao.cursor()
    cursor_ilustracoes = cursor_ilustracoes .execute('''
    CREATE TABLE IF NOT EXISTS data_digitalizacoes_ilustracoes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        grupo_principal TEXT,            
        data_da_digitalizacao_devolutiva TEXT,
        devolutiva TEXT,
        quantidade TEXT,
        UNIQUE(grupo_principal, data_da_digitalizacao_devolutiva, devolutiva, quantidade)
        )
                                                     ''')
    conexao.commit()
    conexao.close()

def criar_base_ddigit_ir():
    conexao = sqlite3.connect(r'.\base_sql\bd_ilustracoes.db')
    cursor_ilustracoes = conexao.cursor()
    cursor_ilustracoes = cursor_ilustracoes .execute('''
    CREATE TABLE IF NOT EXISTS data_digitalizacoes_ilustracoes_ir(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        grupo_principal TEXT,            
        data_da_digitalizacao_devolutiva_ir TEXT,
        devolutiva_ir TEXT,
        quantidade TEXT,
        UNIQUE(grupo_principal,data_da_digitalizacao_devolutiva_ir, devolutiva_ir, quantidade)
        )
                                                     ''')
    conexao.commit()
    conexao.close()

def importador_base_tipo():
    leitor = pd.read_excel(r'.\base_compilada\distribuicao\base_compilada_tipo_liberacao_distribuicao.xlsx', usecols=[0,1,2,3,4])
    conta_linhas = len(leitor)
    # ---------- CONEXÃO ----------
    conexao = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")
    cursor = conexao.cursor()

    # ---------- QUERY CORRIGIDA ----------
    query = """
    INSERT OR IGNORE INTO tipo_ilustracoes (
        grupo_principal,
        tipo_de_liberacao,
        quantidade,
        quantidade_grupo,
        distribuicao_tipos_percent
        )
    VALUES (?, ?, ?, ?, ?)
    """

    # ---------- LOOP ----------
    for i in range(conta_linhas):
        valores = (
            str(leitor.iloc[i, 0]),
            str(leitor.iloc[i, 1]),
            str(leitor.iloc[i, 2]),
            str(leitor.iloc[i, 3]),
            str(leitor.iloc[i, 4]),
                
        )
        #print(valores)
        cursor.execute(query, valores)

    conexao.commit()
    conexao.close()

def importador_base_status():
    leitor = pd.read_excel(r'.\base_compilada\distribuicao\base_compilada_status_da_pagina_de_texto.xlsx', usecols=[0,1,2])
    conta_linhas = len(leitor)
    # ---------- CONEXÃO ----------
    conexao = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")
    cursor = conexao.cursor()

    # ---------- QUERY CORRIGIDA ----------
    query = """
    INSERT OR IGNORE INTO status_ilustracoes (
        grupo_principal,            
        status_da_pagina_de_texto,
        quantidade
        )
    VALUES (?, ?, ?)
    """

    # ---------- LOOP ----------
    for i in range(conta_linhas):
        valores = (
            str(leitor.iloc[i, 0]),
            str(leitor.iloc[i, 1]),
            str(leitor.iloc[i, 2])
                
        )
        #print(valores)
        cursor.execute(query, valores)

    conexao.commit()
    conexao.close()

def importador_base_num():
    leitor = pd.read_excel(r'.\base_compilada\distribuicao\base_compilada_numero_da_ilustracao_distribuicao.xlsx', usecols=[0,1,2,3,4])
    conta_linhas = len(leitor)
    # ---------- CONEXÃO ----------
    conexao = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")
    cursor = conexao.cursor()

    # ---------- QUERY CORRIGIDA ----------
    query = """
    INSERT OR IGNORE INTO numero_ilustracoes (
        grupo_principal,            
        numero_da_ilustracao_devolutiva,
        quantidade,
        quantidade_grupo,
        distribuicao_numero_da_ilustracao_percent
        )
    VALUES (?, ?, ?, ?, ?)
    """

    # ---------- LOOP ----------
    for i in range(conta_linhas):
        valores = (
            str(leitor.iloc[i, 0]),
            str(leitor.iloc[i, 1]),
            str(leitor.iloc[i, 2]),
            str(leitor.iloc[i, 3]),
            str(leitor.iloc[i, 4])
                
        )
        #print(valores)
        cursor.execute(query, valores)

    conexao.commit()
    conexao.close()

def importador_base_ddigit():
    leitor = pd.read_excel(r'.\base_compilada\distribuicao\base_compilada_data_da_digitalizacao_distribuicao.xlsx', usecols=[0,1,2,3])
    conta_linhas = len(leitor)
    # ---------- CONEXÃO ----------
    conexao = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")
    cursor = conexao.cursor()

    # ---------- QUERY CORRIGIDA ----------
    query = """
    INSERT OR IGNORE INTO data_digitalizacoes_ilustracoes (
        grupo_principal,            
        data_da_digitalizacao_devolutiva,
        devolutiva,
        quantidade
        )
    VALUES (?, ?, ?, ?)
    """

    # ---------- LOOP ----------
    for i in range(conta_linhas):
        valores = (
            str(leitor.iloc[i, 0]),
            str(leitor.iloc[i, 1]),
            str(leitor.iloc[i, 2]),
            str(leitor.iloc[i, 3])
                
        )
        #print(valores)
        cursor.execute(query, valores)

    conexao.commit()
    conexao.close()

def importador_base_ddigit_ir():
    leitor = pd.read_excel(r'.\base_compilada\distribuicao\base_compilada_data_da_digitalizacao_distribuicao_IR.xlsx', usecols=[0,1,2,3])
    conta_linhas = len(leitor)
    # ---------- CONEXÃO ----------
    conexao = sqlite3.connect(r".\base_sql\bd_ilustracoes.db")
    cursor = conexao.cursor()

    # ---------- QUERY CORRIGIDA ----------
    query = """
    INSERT OR IGNORE INTO data_digitalizacoes_ilustracoes_ir (
        grupo_principal,            
        data_da_digitalizacao_devolutiva_ir,
        devolutiva_ir,
        quantidade
        )
    VALUES (?, ?, ?, ?)
    """

    # ---------- LOOP ----------
    for i in range(conta_linhas):
        valores = (
            str(leitor.iloc[i, 0]),
            str(leitor.iloc[i, 1]),
            str(leitor.iloc[i, 2]),
            str(leitor.iloc[i, 3])
                
        )
        #print(valores)
        cursor.execute(query, valores)

    conexao.commit()
    conexao.close()



def bloqueio_pastas():
    lista_pastas = [r'.\base_consulta',r'.\base_compilada',r'.\base_convertida',r'.\base_sql']
    usuario_permitido = "zequinha"

    for pasta in lista_pastas:
        # Remove herança
        subprocess.run(f'icacls "{pasta}" /inheritance:r',shell=True)
        # Concede acesso total apenas ao usuário especificado
        subprocess.run(f'icacls "{pasta}" /grant {usuario_permitido}:(OI)(CI)F',shell=True)
        #para não bloquear processos do Windows.
        #subprocess.run(f'icacls "{pasta}" /grant SYSTEM:(OI)(CI)F',shell=True)
        #acesso a adminsitradores
        #subprocess.run(f'icacls "{pasta}" /grant "Administrators:(OI)(CI)F"',shell=True)

        print("Permissões aplicadas.")    

#
os.system('cls')
cria_pastas()
cria_banco_ilustracoes()
criar_base_tipo()
criar_base_status()
criar_base_num()
criar_base_ddigit()
criar_base_ddigit_ir()
pacote_consulta()
importador()
pacote_consulta_xlsx()
compilador()
adequacao_base()
adq_filtro()
tipo_libercao()
tipo_libercao_distribuicao()
status_da_pagina_de_texto()
numero_da_ilustracao()
data_da_digitalizacao()
data_da_digitalizacao_da_ilustracao_real()
numero_da_ilustracao_distribuicao()
data_da_digitalizacao_distribuicao()
data_da_digitalizacao_distribuicao_IR()
importador_ilustracoes()
importador_base_tipo()
importador_base_status()
importador_base_num()
importador_base_ddigit()
importador_base_ddigit_ir()
#bloqueio_pastas()