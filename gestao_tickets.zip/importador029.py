import pandas as pd
from datetime import datetime
from datetime import datetime, timedelta
import os
import sqlite3
import numpy as np

#---------Insumos-----------------
base_csv = r'.\base\relatorio_ETKA.csv'
agora = datetime.now().strftime('%d-%m-%Y')
excel_adq_filtrada = fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada.xlsx'
excel_auto_arquivado = fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_AUTO_ARCHIVED.xlsx'
excel_distribuica_auto_arquivado = fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_AUTO_ARCHIVED.xlsx'
excel_good = fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_GOOD.xlsx'
excel_distribuicao_good = fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_GOOD.xlsx'
excel_satisfactory = fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_SATISFACTORY.xlsx'
excel_distribuicao_satisfactory = fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_SATISFACTORY.xlsx'
excel_sufficient = fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_SUFFICIENT.xlsx'
excel_distribuicao_sufficient = fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_SUFFICIENT.xlsx'
excel_very_good = fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_VERY_GOOD.xlsx'
excel_distribuicao_very_good = fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_VERY_GOOD.xlsx'
excel_base_geral = fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx'
excel_score_diario = r'.\base_compilada\\distribuicao\painel_diario.xlsx'
excel_score_diario_kpi = r'.\base_compilada\\distribuicao\painel_diario_kpi.xlsx'
excel_score_mensal = r'.\base_compilada\\distribuicao\painel_mensal.xlsx'
excel_score_mensal_kpi = r'.\base_compilada\\distribuicao\painel_mensal_kpi.xlsx'
excel_score_mensal_kpi2 = r'.\base_compilada\\distribuicao\painel_mensal_kpi2.xlsx'
excel_score_mensal_kpi3 = r'.\base_compilada\\distribuicao\painel_mensal_kpi3.xlsx'
excel_score_mensal_kpi4 = r'.\base_compilada\\distribuicao\painel_mensal_kpi4.xlsx'
excel_score_mensal_kpi5 = r'.\base_compilada\\distribuicao\painel_mensal_kpi5.xlsx'
excel_score_anual = r'.\base_compilada\\distribuicao\painel_anual.xlsx'
excel_score_anual_kpi = r'.\base_compilada\\distribuicao\painel_anual_kpi.xlsx'
excel_duracao_mensal = r'.\base_compilada\distribuicao\painel_duracao_mensal.xlsx'
excel_duracao_anual = r'.\base_compilada\distribuicao\painel_duracao_anual.xlsx'
excel_base_categoria = r'.\base_compilada\distribuicao\base_categoria.xlsx'
excel_base_categoria2 = r'.\base_compilada\distribuicao\base_categoria2.xlsx'
excel_base_categoria3 = r'.\base_compilada\distribuicao\base_categoria3.xlsx'
excel_base_categoria4 = r'.\base_compilada\distribuicao\base_categoria4.xlsx'
excel_base_periodo_mensal = r'.\base_compilada\distribuicao\base_periodo_mensal.xlsx'
excel_base_periodo_mensal2 = r'.\base_compilada\distribuicao\base_periodo_mensal2.xlsx'
excel_base_periodo_anual = r'.\base_compilada\distribuicao\base_periodo_anual.xlsx'
excel_base_avaliacao = r'.\base_compilada\\distribuicao\painel_mensal_kpi_avaliacao.xlsx'
bd_geral = r'.\base_sql\auto_arquivado.db'
bd_distribuicao = r'.\base_sql\base_distribuicoes.db'
bd_geral_processado = r'.\base_sql\base_geral_processada.db'
#---------------------------------

def cria_pastas():
    os.system('cls')
    os.makedirs('base_convertida', exist_ok=True)
    os.makedirs('base_consulta', exist_ok=True)
    os.makedirs('base_compilada', exist_ok=True)
    os.makedirs('base_compilada\\distribuicao', exist_ok=True)
    os.makedirs('base_sql', exist_ok=True)

def importar_base_padrao():
    #agora = datetime.now().strftime('%d-%m-%Y')
    #leitor = pd.read_csv(base_csv, sep=';')
    #leitor = pd.read_csv(base_csv, sep=';', encoding='cp1252')
    leitor = pd.read_csv(base_csv, sep=';', encoding='utf-8-sig')
    leitor.to_excel(fr'.\base_convertida\relatorio_ETKA_{agora}.xlsx', index=False)

def relatorio_filtro():
    lista_colunas_filtradas = ['Ticket ID','Archive date','Evaluation','Editor category','Editor category','Net Time']
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_convertida\relatorio_ETKA_{agora}.xlsx')
    df_leitor = leitor.filter(items=lista_colunas_filtradas)
    df_leitor['Net Time - MM'] = (df_leitor['Net Time']/60)
    df_leitor['Net Time - HH'] = (df_leitor['Net Time']/3600)
    df_leitor['Net Time - HH/DD'] = (df_leitor['Net Time']/(3600*24))
    df_leitor['Duração'] = df_leitor['Net Time'].apply(
    lambda x: '{:02d}:{:02d}:{:02d}'.format(
        int(timedelta(seconds=int(x)).total_seconds() // 3600),
        int((timedelta(seconds=int(x)).total_seconds() % 3600) // 60),
        int(timedelta(seconds=int(x)).total_seconds() % 60)))
    df_leitor.to_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada.xlsx', index=False)

def filtro_auto_arquivado():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada.xlsx')
    df_leitor = leitor[leitor['Evaluation'] == '(AUTO_ARCHIVED)']
    df_leitor.to_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_AUTO_ARCHIVED.xlsx', index=False)

def filtro_bom():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada.xlsx')
    df_leitor = leitor[leitor['Evaluation'] == 'GOOD']
    df_leitor.to_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_GOOD.xlsx', index=False)

def filtro_satisfatorio():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada.xlsx')
    df_leitor = leitor[leitor['Evaluation'] == 'SATISFACTORY']
    df_leitor.to_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_SATISFACTORY.xlsx', index=False)

def filtro_suficiente():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada.xlsx')
    df_leitor = leitor[leitor['Evaluation'] == 'SUFFICIENT']
    df_leitor.to_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_SUFFICIENT.xlsx', index=False)

def filtro_muito_bom():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada.xlsx')
    df_leitor = leitor[leitor['Evaluation'] == 'VERY GOOD']
    df_leitor.to_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_VERY_GOOD.xlsx', index=False)

def quantificacao_auto_arquivado():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_AUTO_ARCHIVED.xlsx')
    df_leitor = leitor.groupby(['Archive date', 'Editor category']).size().reset_index(name='Quantidade').sort_values(['Archive date', 'Editor category'])
    total_data = leitor.groupby(['Archive date']).size()
    df_leitor['Quantidade Por Data'] = df_leitor['Archive date'].map(total_data)
    df_leitor['Distribuicao Por Data %'] = ((df_leitor['Quantidade'] / df_leitor['Quantidade Por Data'])*100).round(2)
    df_leitor.to_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_AUTO_ARCHIVED.xlsx', index=False)

def quantificacao_bom():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_GOOD.xlsx')
    df_leitor = leitor.groupby(['Archive date', 'Editor category']).size().reset_index(name='Quantidade').sort_values(['Archive date', 'Editor category'])
    total_data = leitor.groupby(['Archive date']).size()
    df_leitor['Quantidade Por Data'] = df_leitor['Archive date'].map(total_data)
    df_leitor['Distribuicao Por Data %'] = ((df_leitor['Quantidade'] / df_leitor['Quantidade Por Data'])*100).round(2)
    df_leitor.to_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_GOOD.xlsx', index=False)

def quantificacao_satisfatorio():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_SATISFACTORY.xlsx')
    df_leitor = leitor.groupby(['Archive date', 'Editor category']).size().reset_index(name='Quantidade').sort_values(['Archive date', 'Editor category'])
    total_data = leitor.groupby(['Archive date']).size()
    df_leitor['Quantidade Por Data'] = df_leitor['Archive date'].map(total_data)
    df_leitor['Distribuicao Por Data %'] = ((df_leitor['Quantidade'] / df_leitor['Quantidade Por Data'])*100).round(2)
    df_leitor.to_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_SATISFACTORY.xlsx', index=False)

def quantificacao_suficiente():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_SUFFICIENT.xlsx')
    df_leitor = leitor.groupby(['Archive date', 'Editor category']).size().reset_index(name='Quantidade').sort_values(['Archive date', 'Editor category'])
    total_data = leitor.groupby(['Archive date']).size()
    df_leitor['Quantidade Por Data'] = df_leitor['Archive date'].map(total_data)
    df_leitor['Distribuicao Por Data %'] = ((df_leitor['Quantidade'] / df_leitor['Quantidade Por Data'])*100).round(2)
    df_leitor.to_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_SUFFICIENT.xlsx', index=False)

def quantificacao_muito_bom():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_VERY_GOOD.xlsx')
    df_leitor = leitor.groupby(['Archive date', 'Editor category']).size().reset_index(name='Quantidade').sort_values(['Archive date', 'Editor category'])
    total_data = leitor.groupby(['Archive date']).size()
    df_leitor['Quantidade Por Data'] = df_leitor['Archive date'].map(total_data)
    df_leitor['Distribuicao Por Data %'] = ((df_leitor['Quantidade'] / df_leitor['Quantidade Por Data'])*100).round(2)
    df_leitor.to_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_VERY_GOOD.xlsx', index=False)

def base_geral():
    leitor = pd.read_excel(excel_adq_filtrada)
    leitor.columns = leitor.columns.str.strip()
    #leitor['Net Time - Ticket'] = (leitor.groupby('Ticket ID')['Net Time'].transform('sum'))
    leitor['Net Time - Ticket'] = (leitor.groupby('Ticket ID')['Net Time'].transform('sum'))
    leitor['Diario'] = (pd.to_datetime(leitor['Archive date'], format='%d.%m.%Y').dt.strftime('%d.%m.%Y'))
    leitor['Net Time - Diario'] = (leitor.groupby('Diario')['Net Time'].transform('sum'))
    #leitor['Evaluation_Diario_tickets'] = (leitor.groupby('Archive date')['Evaluation'].transform('size'))
    leitor['Evaluation_Diario_tickets'] = (leitor.groupby(['Archive date', 'Evaluation'])['Evaluation'].transform('count'))
    #leitor['Evaluation_Diario_tickets'] = (leitor.groupby('Archive date')['Evaluation'].transform('count'))
    leitor['Diario_tickets'] = (leitor.groupby('Diario')['Ticket ID'].transform('count'))
    leitor['Mensal'] = (pd.to_datetime(leitor['Archive date'], format='%d.%m.%Y').dt.strftime('%m.%Y'))
    leitor['Mensal'] = leitor['Mensal'].replace({r'^01\.':'janeiro.',
                                                 r'^02\.':'fevereiro.',
                                                 r'^03\.':'março.',
                                                 r'04\.':'abril.',
                                                 r'05\.':'maio.',
                                                 r'06\.':'junho.',
                                                 r'07\.':'julho.',
                                                 r'08\.':'agosto.',
                                                 r'09\.':'setembro.',
                                                 r'10\.':'outubro.',
                                                 r'11\.':'novembro.',
                                                 r'12\.':'dezembro.',}, regex=True)
    leitor['Net Time - Mensal'] = (leitor.groupby('Mensal')['Net Time'].transform('sum'))
    leitor['Evaluation_Mensal_tickets'] = (leitor.groupby(['Mensal', 'Evaluation'])['Evaluation'].transform('count'))
    leitor['Mensal_tickets'] = (leitor.groupby('Mensal')['Ticket ID'].transform('count'))
    leitor['Net Time - Média Mensal'] = leitor['Net Time - Mensal']/leitor['Mensal_tickets']
    #leitor['Duração'] = leitor['Net Time'].apply(
    #    lambda x: '{:02d}:{:02d}:{:02d}'.format(
    #        int(timedelta(seconds=int(x)).total_seconds() // 3600),
    #        int((timedelta(seconds=int(x)).total_seconds() % 3600) // 60),
    #        int(timedelta(seconds=int(x)).total_seconds() % 60)))
    leitor['Duração Mensal - Média'] = leitor['Net Time - Média Mensal'].apply(
            lambda x: '{:02d}:{:02d}:{:02d}'.format(
            int(timedelta(seconds=int(x)).total_seconds() // 3600),
            int((timedelta(seconds=int(x)).total_seconds() % 3600) // 60),
            int(timedelta(seconds=int(x)).total_seconds() % 60)))
    leitor['Duração Mensal - Consolidada'] = leitor['Net Time - Mensal'].apply(
            lambda x: '{:02d}:{:02d}:{:02d}'.format(
            int(timedelta(seconds=int(x)).total_seconds() // 3600),
            int((timedelta(seconds=int(x)).total_seconds() % 3600) // 60),
            int(timedelta(seconds=int(x)).total_seconds() % 60)))
    leitor['Anual'] = (pd.to_datetime(leitor['Archive date'], format='%d.%m.%Y').dt.strftime('%Y'))
    leitor['Net Time - Anual'] = (leitor.groupby('Anual')['Net Time'].transform('sum'))
    leitor['anual_tickets'] = (leitor.groupby('Anual')['Ticket ID'].transform('count'))
    leitor['Net Time - Média Anual'] = leitor['Net Time - Anual']/leitor['anual_tickets']
    leitor['Duração Anual - Média'] = leitor['Net Time - Média Anual'].apply(
                lambda x: '{:02d}:{:02d}:{:02d}'.format(
                int(timedelta(seconds=int(x)).total_seconds() // 3600),
                int((timedelta(seconds=int(x)).total_seconds() % 3600) // 60),
                int(timedelta(seconds=int(x)).total_seconds() % 60)))
    leitor['Duração Anual - Consolidada'] = leitor['Net Time - Anual'].apply(
                lambda x: '{:02d}:{:02d}:{:02d}'.format(
                int(timedelta(seconds=int(x)).total_seconds() // 3600),
                int((timedelta(seconds=int(x)).total_seconds() % 3600) // 60),
                int(timedelta(seconds=int(x)).total_seconds() % 60)))
    leitor['IO'] = 1
    leitor['Base_historica_consolidado'] = leitor['IO'].sum()
    leitor['Diario_tickets_percent'] = leitor['Diario_tickets']/leitor['anual_tickets']
    leitor['Mensal_tickets_percent'] = leitor['Mensal_tickets']/leitor['anual_tickets']
    leitor['anual_tickets_percent'] = leitor['anual_tickets']/leitor['Base_historica_consolidado'] 
    leitor['Evaluation_Diario'] = leitor.groupby(['Diario', 'Evaluation'])['Evaluation'].transform('count')
    leitor['Category_Diario'] = leitor.groupby(['Diario', 'Editor category'])['Editor category'].transform('count')
    leitor['Evaluation_Mensal'] = leitor.groupby(['Mensal', 'Evaluation'])['Evaluation'].transform('count')
    leitor['Category_Mensal'] = leitor.groupby(['Mensal', 'Editor category'])['Editor category'].transform('count')
    leitor['Evaluation_anual'] = leitor.groupby(['Anual','Evaluation'])['Evaluation'].transform('count')
    leitor['Category_anual'] = leitor.groupby(['Anual', 'Editor category'])['Editor category'].transform('count')
    leitor['Avaliacao'] = leitor['Evaluation'].replace({r'(AUTO_ARCHIVED)':'NÃO AVALIADO',
                                                        r'GOOD':'AVALIADO',
                                                        r'VERY GOOD':'AVALIADO',
                                                        r'SATISFACTORY':'AVALIADO',
                                                        r'SUFFICIENT':'AVALIADO'})
    leitor['Avaliacao_Mensal'] = leitor.groupby(['Mensal', 'Avaliacao'])['Avaliacao'].transform('count')
    leitor['Avaliacao_Anual'] = leitor.groupby(['Anual', 'Avaliacao'])['Avaliacao'].transform('count')
    leitor['Equivalencia_Categoria'] = np.where(leitor['Editor category'] == 'Availabilty / alternatives','SVE – Sem Info',
                                                np.where(leitor['Editor category'] == 'Carport data','ERRO DE CATÁLOGO',
                                                        np.where(leitor['Editor category'] == 'Fitting Parts','SUBSTITUIÇÃO DE PEÇA',
                                                                np.where(leitor['Editor category'] == 'None (inquiry is justified)','ILUSTRAÇÃO',
                                                                         np.where(leitor['Editor category'] ==  'Price','RESPONSABILIDADE DE OUTRAS ÁREAS',
                                                                                  np.where(leitor['Editor category'] == 'Repair support','INFORMAÇÕES ADICIONAIS PERTINENTES',
                                                                                           np.where(leitor['Editor category'] == 'Retrofit','TIQUETE INVÁLIDO',
                                                                                                    np.where(leitor['Editor category'] == 'Verification','SVE - COM INFORMAÇÃO',
                                                                                                             np.where(leitor['Editor category'] == 'Wrong delivery','INFORMAÇÃO DE CONTEÚDO DO ETKA','Não classificado')))))))))
    leitor['Equivalencia_Categoria_tickets_MENSAL'] = leitor.groupby(['Mensal','Equivalencia_Categoria'])['Equivalencia_Categoria'].transform('count')
    leitor['Equivalencia_efetiva'] = (leitor['Equivalencia_Categoria_tickets_MENSAL']/leitor['Mensal_tickets']).round(2)
    #Equivalencia_Categoria_tickets_MENSAL
    #Mensal_tickets
    leitor['Evaluation_elegibilidade'] = np.where(leitor['Evaluation'] == '(AUTO_ARCHIVED)',
                                                  'NÃO ELEGÍVEL PARA O CÁLCULO.','ELEGÍVEL')
    leitor['Peso_Media_Mensal'] = np.where(leitor['Evaluation'] == 'VERY GOOD',100,
                                                 np.where(leitor['Evaluation'] == 'GOOD',84,
                                                          np.where(leitor['Evaluation'] == 'SATISFACTORY',67,
                                                                   np.where(leitor['Evaluation'] == 'SUFFICIENT',50,0))))
    leitor['Evaluation_Mensal_tickets_elegiveis'] = np.where(leitor['Evaluation_elegibilidade'] == 'ELEGÍVEL',
                                                             (leitor.groupby(['Mensal', 'Evaluation_elegibilidade'])['Evaluation_elegibilidade'].transform('count'))
                                                             ,0)
    leitor['Media_Mensal'] = np.where(leitor['Evaluation_elegibilidade'] == 'ELEGÍVEL',(leitor['Evaluation_Mensal']*leitor['Peso_Media_Mensal'])/leitor['Evaluation_Mensal_tickets_elegiveis'] ,0).round(2)
    leitor['Equivalencia_Categoria_tickets_ANUAL'] = leitor.groupby(['Anual','Equivalencia_Categoria'])['Equivalencia_Categoria'].transform('count')
    leitor['Equivalencia_efetiva_ANUAL'] = (leitor['Equivalencia_Categoria_tickets_ANUAL']/leitor['anual_tickets']).round(2)
    
    leitor.to_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx', index=False)
    
def score_diario():
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Diario','Diario_tickets',
                                     'Diario_tickets_percent','Anual']).drop_duplicates().sort_values(
                                        by='Diario', ascending=True)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_diario.xlsx', index=False)

def score_diario_kpi():
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Diario','Diario_tickets',
                                     'Diario_tickets_percent','Anual','Evaluation','Evaluation_Diario',
                                     'Editor category','Category_Diario',
                                     ]).drop_duplicates().sort_values(by='Diario', ascending=True)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_diario_kpi.xlsx', index=False)

def score_mensal():
    leitor = pd.read_excel(excel_base_geral)
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Mensal','Mensal_tickets',
                                     'Mensal_tickets_percent','Anual',
                                     ]).drop_duplicates().sort_values(by='Mensal',ascending=True)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_mensal.xlsx', index=False)

def score_mensal_kpi():
    leitor = pd.read_excel(excel_base_geral)
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Mensal','Mensal_tickets',
                                     'Mensal_tickets_percent','Anual',
                                     'Evaluation','Evaluation_Mensal'
                                     ]).drop_duplicates().sort_values(by='Mensal',ascending=True)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_mensal_kpi.xlsx', index=False)

def score_mensal_kpi2():
    leitor = pd.read_excel(excel_base_geral)
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Mensal','Mensal_tickets','Avaliacao','Avaliacao_Mensal',
                                     'Mensal_tickets_percent','Anual',
                                     ]).drop_duplicates().sort_values(by='Mensal',ascending=True)
    df_leitor['Avaliacao_Mensal_percent'] =(df_leitor['Avaliacao_Mensal']/df_leitor['Mensal_tickets']).round(2)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_mensal_kpi2.xlsx', index=False)

def score_mensal_kpi3():
    leitor = pd.read_excel(excel_base_geral)
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Mensal','Mensal_tickets',
                                     'Mensal_tickets_percent','Anual',
                                     'Evaluation','Evaluation_Mensal','Evaluation_elegibilidade','Peso_Media_Mensal','Evaluation_Mensal_tickets_elegiveis','Media_Mensal','Media_Mensal_Consolidada'
                                     ]).drop_duplicates().sort_values(by='Mensal',ascending=True)
    df_leitor['Media_Mensal_Consolidada'] = (df_leitor.groupby('Mensal')['Media_Mensal'].transform('sum')).round(2)
    df_leitor['Media_Mensal'] = df_leitor['Media_Mensal'].round(2)
    df_leitor['Mensal_tickets_percent'] = df_leitor['Mensal_tickets_percent'].round(2)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_mensal_kpi3.xlsx', index=False)

def score_mensal_kpi4():
    leitor = pd.read_excel(excel_base_geral)
    df_leitor = leitor.filter(items=['Mensal','Mensal_tickets',
                                     'Equivalencia_Categoria','Equivalencia_Categoria_tickets_MENSAL',
                                     'Anual']).drop_duplicates().sort_values(by='Mensal',ascending=True)
    #df_leitor['Media_Mensal_Consolidada'] = (df_leitor.groupby('Mensal')['Media_Mensal'].transform('sum')).round(2)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_mensal_kpi4.xlsx', index=False)

def score_mensal_kpi5():
    import pandas as pd

    leitor = pd.read_excel(excel_score_mensal_kpi3)

    meses = {
        'janeiro': 1,
        'fevereiro': 2,
        'março': 3,
        'abril': 4,
        'maio': 5,
        'junho': 6,
        'julho': 7,
        'agosto': 8,
        'setembro': 9,
        'outubro': 10,
        'novembro': 11,
        'dezembro': 12
    }

    # Seleciona apenas as colunas necessárias
    df_leitor = (leitor[['Mensal', 'Anual', 'Media_Mensal_Consolidada']].drop_duplicates().copy())# Converte "abril.2026" para datetime
    df_leitor['Mensal_dt'] = pd.to_datetime(df_leitor['Mensal'].apply(lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]:02d}-01"))

    # Ordenação cronológica
    df_leitor = df_leitor.sort_values('Mensal_dt')

    # Cálculos anuais
    df_leitor['Media_Consolidada'] = (
        df_leitor.groupby('Anual')['Media_Mensal_Consolidada']
        .transform('sum')
        .round(2)
    )

    df_leitor['N'] = (
        df_leitor.groupby('Anual')['Mensal']
        .transform('count')
    )

    df_leitor['Media_Anual'] = (
        df_leitor['Media_Consolidada'] / df_leitor['N']
    ).round(2)

    # Remove coluna auxiliar
    df_leitor = df_leitor.drop(columns=['Mensal_dt'])

    # Exporta
    df_leitor.to_excel(r'.\base_compilada\distribuicao\painel_mensal_kpi5.xlsx',index=False)

def score_mensal_kpi_categoria():
    leitor = pd.read_excel(excel_base_geral)
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Mensal','Mensal_tickets',
                                     'Mensal_tickets_percent','Anual',
                                     'Editor category','Category_Mensal'
                                     ]).drop_duplicates().sort_values(by='Mensal',ascending=True)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_mensal_kpi_categoria.xlsx', index=False)

def score_mensal_kpi_avaliacao():
    leitor = pd.read_excel(excel_base_geral)
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Mensal','Mensal_tickets',
                                     'Mensal_tickets_percent','Anual',
                                     'Avaliacao','Avaliacao_Mensal'
                                     ]).drop_duplicates().sort_values(by='Mensal',ascending=True)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_mensal_kpi_avaliacao.xlsx', index=False)

def score_anual():
    leitor = pd.read_excel(excel_base_geral)
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Anual','anual_tickets',
                                     'anual_tickets_percent','Base_historica_consolidado'
                                     ]).drop_duplicates().sort_values(by='Anual',ascending=True)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_anual.xlsx', index=False)

def score_anual_kpi():
    leitor = pd.read_excel(excel_base_geral)
    #df_leitor = leitor.drop_duplicates(subset=['Diario'])
    df_leitor = leitor.filter(items=['Anual','anual_tickets',
                                     'anual_tickets_percent','Base_historica_consolidado',
                                     'Evaluation','Evaluation_anual'
                                     ]).drop_duplicates().sort_values(by='Anual',ascending=True)
    df_leitor.to_excel(r'.\base_compilada\\distribuicao\painel_anual_kpi.xlsx', index=False)

def score_duracao_mensal():
    agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')

    # Somar a duração por mês
    duracao = (
        leitor.groupby('Mensal')['Duração Mensal - Consolidada']
        .first()  # ajuste se precisar de sum
        .reset_index()
    )

    # Dataframe principal
    df_leitor = (
        leitor.filter(items=['Mensal', 'Net Time - Mensal','Mensal_tickets','Net Time - Média Mensal','Duração Mensal - Média'])
        .drop_duplicates()
        .sort_values(by='Mensal', ascending=True)
    )
    df_leitor['Net Time - Média Mensal'] = (df_leitor['Net Time - Mensal']/df_leitor['Mensal_tickets']).round(0)

    # Adiciona a coluna Duração
    df_leitor = df_leitor.merge(duracao, on='Mensal', how='left')

    df_leitor.to_excel(r'.\base_compilada\distribuicao\painel_duracao_mensal.xlsx', index=False)

def score_duracao_anual():
    agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    duracao = (leitor.groupby('Mensal')['Duração Mensal - Consolidada'].first().reset_index())
    df_leitor = (leitor.filter(items=['Mensal', 'Net Time - Mensal',
                             'Mensal_tickets','Net Time - Média Mensal',
                             'Duração Mensal - Média',
                             'Anual','Net Time - Anual',
                             'anual_tickets','Net Time - Média Anual','Duração Anual - Média',
                             'Duração Anual - Consolidada']).drop_duplicates().sort_values(by='Mensal', ascending=True))
    df_leitor['Net Time - Média Mensal'] = (df_leitor['Net Time - Mensal']/df_leitor['Mensal_tickets']).round(0)
    df_leitor = df_leitor.merge(duracao, on='Mensal', how='left')
    df_leitor.to_excel(r'.\base_compilada\distribuicao\painel_duracao_anual.xlsx', index=False)

def score_categoria():
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    df_leitor = (leitor.filter(items=['Mensal','Anual', 'Evaluation','Evaluation_Mensal_tickets','Mensal_tickets']).drop_duplicates().sort_values(by='Mensal', ascending=True))
    df_leitor['Evaluation_percent'] = (df_leitor['Evaluation_Mensal_tickets'] / df_leitor['Mensal_tickets']).round(4)
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_categoria.xlsx', index=False)

def score_categoria2():
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    df_leitor = (leitor.filter(items=['Mensal','Anual', 'Editor category','Category_Mensal','Mensal_tickets']).drop_duplicates().sort_values(by='Mensal', ascending=True))
    df_leitor['Category_Mensal_percent'] = (df_leitor['Category_Mensal'] / df_leitor['Mensal_tickets']).round(4)
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_categoria2.xlsx', index=False)

def score_categoria3():
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    df_leitor = (leitor.filter(items=['Mensal','Anual', 'Equivalencia_Categoria','Equivalencia_Categoria_tickets_MENSAL','Mensal_tickets']).drop_duplicates().sort_values(by='Mensal', ascending=True))
    df_leitor['Category_Mensal_percent'] = (df_leitor['Equivalencia_Categoria_tickets_MENSAL'] / df_leitor['Mensal_tickets']).round(4)
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_categoria3.xlsx', index=False)

def score_categoria4():
    agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    df_leitor = leitor.filter(items=['Mensal','Mensal_tickets','Anual','anual_tickets']).drop_duplicates().sort_values(by='Anual', ascending=True)
    df_leitor['n_periodo'] = df_leitor.groupby(['Anual', 'Mensal'])['Mensal'].transform('count')
    df_leitor['n_periodo_anual'] = df_leitor.groupby(['Anual', 'n_periodo'])['n_periodo'].transform('sum')
    df_leitor['Volume_Medio'] = (df_leitor['anual_tickets']/df_leitor['n_periodo_anual']).round(2)
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_categoria4.xlsx', index=False)

def score_periodo_mensal():
    agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    df_leitor = (leitor.filter(items=['Mensal','Evaluation','Evaluation_Mensal_tickets','Mensal_tickets','Anual']).drop_duplicates().sort_values(by='Anual', ascending=True))
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_periodo_mensal.xlsx', index=False)

def score_periodo_mensal2():
    agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    df_leitor = (leitor.filter(items=['Mensal','Equivalencia_Categoria','Equivalencia_Categoria_tickets_MENSAL','Mensal_tickets','Equivalencia_efetiva','Anual','Equivalencia_efetiva']).drop_duplicates().sort_values(by='Anual', ascending=True))
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_periodo_mensal2.xlsx', index=False)

def score_periodo_anual():
    agora = datetime.now().strftime('%d-%m-%Y')
    leitor = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    #df_leitor = (leitor.filter(items=['Mensal','Equivalencia_Categoria','Equivalencia_Categoria_tickets_MENSAL','Mensal_tickets','Equivalencia_efetiva','Anual','Equivalencia_efetiva']).drop_duplicates().sort_values(by='Anual', ascending=True))
    df_leitor = (leitor.filter(items=['Anual','Equivalencia_Categoria','Equivalencia_Categoria_tickets_ANUAL','anual_tickets','Equivalencia_efetiva_ANUAL']).drop_duplicates().sort_values(by='Anual', ascending=True))
    df_leitor.to_excel(r'.\base_compilada\distribuicao\base_periodo_anual.xlsx', index=False)

def compilacao():
    #agora = datetime.now().strftime('%d-%m-%Y')
    leitor1 = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada.xlsx')
    leitor2 = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_AUTO_ARCHIVED.xlsx')
    leitor3 = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_GOOD.xlsx')
    leitor4 = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_SATISFACTORY.xlsx')
    leitor5 = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_SUFFICIENT.xlsx')
    leitor6 = pd.read_excel(fr'.\base_compilada\relatorio_ETKA_{agora}_filtrada_VERY_GOOD.xlsx')
    leitor7 = pd.read_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_AUTO_ARCHIVED.xlsx')
    leitor8 = pd.read_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_GOOD.xlsx')
    leitor9 = pd.read_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_SATISFACTORY.xlsx')
    leitor10 = pd.read_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_SUFFICIENT.xlsx')
    leitor11 = pd.read_excel(fr'.\base_compilada\\distribuicao\relatorio_ETKA_{agora}_distribuicao_VERY_GOOD.xlsx')
    leitor12 = pd.read_excel(fr'.\base_compilada\\distribuicao\base_mes_ano_{agora}.xlsx')
    leitor13 = pd.read_excel(r'.\base_compilada\\distribuicao\painel_diario.xlsx')
    with pd.ExcelWriter(fr'.\base_consulta\relatorio_ETKA_{agora}_base_compilada.xlsx', engine='xlsxwriter') as writer:
        leitor1.to_excel(writer,index=False,sheet_name='BASE FILTRADA')
        leitor2.to_excel(writer,index=False,sheet_name='AUTO_ARCHIVED')
        leitor3.to_excel(writer,index=False,sheet_name='GOOD')
        leitor4.to_excel(writer,index=False,sheet_name='SATISFACTORY')
        leitor5.to_excel(writer,index=False,sheet_name='SUFFICIENT')
        leitor6.to_excel(writer,index=False,sheet_name='VERY_GOOD')
        leitor7.to_excel(writer,index=False,sheet_name='DIST_AUTO_ARCHIVED')
        leitor8.to_excel(writer,index=False,sheet_name='DIST_GOOD')
        leitor9.to_excel(writer,index=False,sheet_name='DIST_SATISFACTORY')
        leitor10.to_excel(writer,index=False,sheet_name='DIST_SUFFICIENT')
        leitor11.to_excel(writer,index=False,sheet_name='DIST_VERY_GOOD')
        leitor12.to_excel(writer, index=False, sheet_name='BASE_GERAL')
        leitor13.to_excel(writer, index=False,sheet_name='SCORE_DIARIO')

def criar_banco_geral(bd_geral):
    conexao = sqlite3.connect(bd_geral)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS geral_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Ticket_ID INTEGER,
        Archive_date TEXT,
        Evaluation TEXT,
        Editor_category TEXT,
        Net_Time TEXT,
        Net_Time_MM TEXT,
        Net_Time_HH TEXT,
        Net_Time_DD TEXT,
        DURACAO TEXT,
        UNIQUE(Ticket_ID, Archive_date, Evaluation, Editor_category, Net_Time, Net_Time_MM, Net_Time_HH, Net_Time_DD, DURACAO)
        )''')
    conexao.commit()
    conexao.close()

def importar_banco_geral(excel_adq_filtrada):
    leitor = pd.read_excel(excel_adq_filtrada)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_geral)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO geral_tabela(
    Ticket_ID,
    Archive_date,
    Evaluation,
    Editor_category,
    Net_Time,
    Net_Time_MM,
    Net_Time_HH,
    Net_Time_DD,
    DURACAO)
    VALUES(?,?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]),
                    str(leitor.iloc[a,8]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_auto_arquivado(bd_geral):
    conexao = sqlite3.connect(bd_geral)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS auto_arquivado_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Evaluation TEXT,
        Editor_category TEXT,
        Net_Time TEXT,
        Net_Time_MM TEXT,
        Net_Time_HH TEXT,
        Net_Time_DD TEXT,
        DURACAO TEXT,
        UNIQUE(Archive_date, Evaluation, Editor_category, Net_Time, Net_Time_MM, Net_Time_HH, Net_Time_DD, DURACAO)
        )''')
    conexao.commit()
    conexao.close()

def importar_banco_auto_arquivado(excel_auto_arquivado):
    leitor = pd.read_excel(excel_auto_arquivado)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_geral)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO auto_arquivado_tabela(
    Archive_date,
    Evaluation,
    Editor_category,
    Net_Time,
    Net_Time_MM,
    Net_Time_HH,
    Net_Time_DD,
    DURACAO)
    VALUES(?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_good(bd_geral):
    conexao = sqlite3.connect(bd_geral)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS good_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Evaluation TEXT,
        Editor_category TEXT,
        Net_Time TEXT,
        Net_Time_MM TEXT,
        Net_Time_HH TEXT,
        Net_Time_DD TEXT,
        DURACAO TEXT,
        UNIQUE(Archive_date,
                Evaluation,
                Editor_category,
                Net_Time,
                Net_Time_MM,
                Net_Time_HH,
                Net_Time_DD,
                DURACAO
        ))''')
    conexao.commit()
    conexao.close()

def importar_banco_good(excel_good):
    leitor = pd.read_excel(excel_good)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_geral)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO good_tabela(
    Archive_date,
    Evaluation,
    Editor_category,
    Net_Time,
    Net_Time_MM,
    Net_Time_HH,
    Net_Time_DD,
    DURACAO)
    VALUES(?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

#excel_satisfactory
def criar_satisfactory(bd_geral):
    conexao = sqlite3.connect(bd_geral)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS satisfactory_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Evaluation TEXT,
        Editor_category TEXT,
        Net_Time TEXT,
        Net_Time_MM TEXT,
        Net_Time_HH TEXT,
        Net_Time_DD TEXT,
        DURACAO TEXT,
        UNIQUE(Archive_date,
                Evaluation,
                Editor_category,
                Net_Time,
                Net_Time_MM,
                Net_Time_HH,
                Net_Time_DD,
                DURACAO))''')
    conexao.commit()
    conexao.close()

def importar_banco_satisfactory(excel_satisfactory):
    leitor = pd.read_excel(excel_satisfactory)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_geral)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO satisfactory_tabela(
    Archive_date,
    Evaluation,
    Editor_category,
    Net_Time,
    Net_Time_MM,
    Net_Time_HH,
    Net_Time_DD,
    DURACAO)
    VALUES(?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

#excel_SUFFICIENT
def criar_sufficient(bd_geral):
    conexao = sqlite3.connect(bd_geral)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS sufficient_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Evaluation TEXT,
        Editor_category TEXT,
        Net_Time TEXT,
        Net_Time_MM TEXT,
        Net_Time_HH TEXT,
        Net_Time_DD TEXT,
        DURACAO TEXT,
        UNIQUE(Archive_date,
                Evaluation,
                Editor_category,
                Net_Time,
                Net_Time_MM,
                Net_Time_HH,
                Net_Time_DD,
                DURACAO))''')
    conexao.commit()
    conexao.close()

def importar_banco_sufficient(excel_sufficient):
    leitor = pd.read_excel(excel_sufficient)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_geral)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO sufficient_tabela(
    Archive_date,
    Evaluation,
    Editor_category,
    Net_Time,
    Net_Time_MM,
    Net_Time_HH,
    Net_Time_DD,
    DURACAO)
    VALUES(?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_very_good(bd_geral):
    conexao = sqlite3.connect(bd_geral)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS very_good_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Evaluation TEXT,
        Editor_category TEXT,
        Net_Time TEXT,
        Net_Time_MM TEXT,
        Net_Time_HH TEXT,
        Net_Time_DD TEXT,
        DURACAO TEXT,
        UNIQUE(Archive_date,
                Evaluation,
                Editor_category,
                Net_Time,
                Net_Time_MM,
                Net_Time_HH,
                Net_Time_DD,
                DURACAO))''')
    conexao.commit()
    conexao.close()

def importar_banco_very_good(excel_very_good):
    leitor = pd.read_excel(excel_very_good)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_geral)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO very_good_tabela(
    Archive_date,
    Evaluation,
    Editor_category,
    Net_Time,
    Net_Time_MM,
    Net_Time_HH,
    Net_Time_DD,
    DURACAO)
    VALUES(?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_distribuicao_auto_arq(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS distr_auto_arquivado_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Editor_category TEXT,
        Quantidade TEXT,
        Quantidade_Por_Data TEXT,
        Distribuicao_Por_Data_PERCENT TEXT,
        UNIQUE(Archive_date,
                Editor_category,
                Quantidade,
                Quantidade_Por_Data,
                Distribuicao_Por_Data_PERCENT))''')
    conexao.commit()
    conexao.close()

def importar_banco_dist_aut_arq(excel_distribuica_auto_arquivado):
    leitor = pd.read_excel(excel_distribuica_auto_arquivado)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_auto_arquivado_tabela(
    Archive_date,
    Editor_category,
    Quantidade,
    Quantidade_Por_Data,
    Distribuicao_Por_Data_PERCENT)
    VALUES(?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()


def criar_banco_distribuicao_good(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS distr_good_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Editor_category TEXT,
        Quantidade TEXT,
        Quantidade_Por_Data TEXT,
        Distribuicao_Por_Data_PERCENT TEXT,
        UNIQUE(Archive_date,
                Editor_category,
                Quantidade,
                Quantidade_Por_Data,
                Distribuicao_Por_Data_PERCENT))''')
    conexao.commit()
    conexao.close()

def importar_banco_distr_good(excel_distribuicao_good):
    leitor = pd.read_excel(excel_distribuicao_good)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_good_tabela(
    Archive_date,
    Editor_category,
    Quantidade,
    Quantidade_Por_Data,
    Distribuicao_Por_Data_PERCENT)
    VALUES(?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_distribuicao_satisfactory(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS distr_satisfactory_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Editor_category TEXT,
        Quantidade TEXT,
        Quantidade_Por_Data TEXT,
        Distribuicao_Por_Data_PERCENT TEXT,
        UNIQUE(Archive_date,
                Editor_category,
                Quantidade,
                Quantidade_Por_Data,
                Distribuicao_Por_Data_PERCENT))''')
    conexao.commit()
    conexao.close()

def importar_banco_distr_satisfactory(excel_distribuicao_satisfactory):
    leitor = pd.read_excel(excel_distribuicao_satisfactory)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_satisfactory_tabela(
    Archive_date,
    Editor_category,
    Quantidade,
    Quantidade_Por_Data,
    Distribuicao_Por_Data_PERCENT)
    VALUES(?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()


def criar_banco_distribuicao_sufficient(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS distr_sufficient_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Editor_category TEXT,
        Quantidade TEXT,
        Quantidade_Por_Data TEXT,
        Distribuicao_Por_Data_PERCENT TEXT,
        UNIQUE(Archive_date,
                Editor_category,
                Quantidade,
                Quantidade_Por_Data,
                Distribuicao_Por_Data_PERCENT))''')
    conexao.commit()
    conexao.close()

def importar_banco_distr_sufficient(excel_distribuicao_sufficient):
    leitor = pd.read_excel(excel_distribuicao_sufficient)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_sufficient_tabela(
    Archive_date,
    Editor_category,
    Quantidade,
    Quantidade_Por_Data,
    Distribuicao_Por_Data_PERCENT)
    VALUES(?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()


def criar_banco_distribuicao_very_good(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_auto_arquivado = conexao.cursor()
    cursor_auto_arquivado = cursor_auto_arquivado.execute('''
        CREATE TABLE IF NOT EXISTS distr_very_good_tabela(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Archive_date TEXT,
        Editor_category TEXT,
        Quantidade TEXT,
        Quantidade_Por_Data TEXT,
        Distribuicao_Por_Data_PERCENT TEXT,
        UNIQUE(Archive_date,
                Editor_category,
                Quantidade,
                Quantidade_Por_Data,
                Distribuicao_Por_Data_PERCENT))''')
    conexao.commit()
    conexao.close()

def importar_banco_distr_very_good(excel_distribuicao_very_good):
    leitor = pd.read_excel(excel_distribuicao_very_good)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_very_good_tabela(
    Archive_date,
    Editor_category,
    Quantidade,
    Quantidade_Por_Data,
    Distribuicao_Por_Data_PERCENT)
    VALUES(?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_mensal(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_mensal(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Mensal_tickets TEXT,
        Mensal_tickets_percent TEXT,
        Anual TEXT,
        UNIQUE(Mensal,
                Mensal_tickets,
                Mensal_tickets_percent,
                Anual))
        '''
    )

def importar_banco_mensal(excel_score_mensal):
    leitor = pd.read_excel(excel_score_mensal)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_mensal(
    Mensal,
    Mensal_tickets,
    Mensal_tickets_percent,
    Anual)
    VALUES(?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_mensa_kpi(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_mensal_kpi(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Mensal_tickets TEXT,
        Mensal_tickets_percent TEXT,
        Anual TEXT,
        Evaluation TEXT,
        Evaluation_Mensal TEXT,
        UNIQUE(Mensal,
                Mensal_tickets,
                Mensal_tickets_percent,
                Anual,
                Evaluation,
                Evaluation_Mensal))
        '''
    )


def importar_banco_mensal_kpi(excel_score_mensal_kpi):
    leitor = pd.read_excel(excel_score_mensal_kpi)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_mensal_kpi(
    Mensal,
    Mensal_tickets,
    Mensal_tickets_percent,
    Anual,
    Evaluation,
    Evaluation_Mensal)
    VALUES(?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_mensa_kpi2(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_mensal_kpi2(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Mensal_tickets INTEGER,
        Avaliacao TEXT,
        Avaliacao_Mensal INTEGER,
        Mensal_tickets_percent TEXT,
        Anual INTEGER,
        Avaliacao_Mensal_percent REAL,
        UNIQUE(Mensal,
                Mensal_tickets,
                Avaliacao,
                Avaliacao_Mensal,
                Mensal_tickets_percent,
                Anual,
                Avaliacao_Mensal_percent))
        '''
    )

def importar_banco_mensal_kpi2(excel_score_mensal_kpi2):
    leitor = pd.read_excel(excel_score_mensal_kpi2)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_mensal_kpi2(
    Mensal,
    Mensal_tickets,
    Avaliacao, 
    Avaliacao_Mensal,
    Mensal_tickets_percent,
    Anual,
    Avaliacao_Mensal_percent)
    VALUES(?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),)
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()
    
def criar_banco_mensa_kpi3(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_mensal_kpi3(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Mensal_tickets INTEGER,
        Mensal_tickets_percent TEXT,
        Anual INTEGER,
        Evaluation TEXT,
        Evaluation_Mensal INTEGER,
        Evaluation_elegibilidade TEXT,
        Peso_Media_Mensal INTEGER,
        Evaluation_Mensal_tickets_elegiveis INTEGER,
        Media_Mensal REAL,
        Media_Mensal_Consolidada REAL,
        UNIQUE(Mensal,
                Mensal_tickets,
                Mensal_tickets_percent,
                Anual,
                Evaluation,
                Evaluation_Mensal,
                Evaluation_elegibilidade,
                Peso_Media_Mensal,
                Evaluation_Mensal_tickets_elegiveis,
                Media_Mensal,
                Media_Mensal_Consolidada))
        '''
    )

def importar_banco_mensal_kpi3(excel_score_mensal_kpi3):
    leitor = pd.read_excel(excel_score_mensal_kpi3)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_mensal_kpi3(
    Mensal,
    Mensal_tickets,
    Mensal_tickets_percent,
    Anual,
    Evaluation,
    Evaluation_Mensal,
    Evaluation_elegibilidade,
    Peso_Media_Mensal,
    Evaluation_Mensal_tickets_elegiveis,
    Media_Mensal,
    Media_Mensal_Consolidada
    )
    VALUES(?,?,?,?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]),
                    str(leitor.iloc[a,8]),
                    str(leitor.iloc[a,9]),
                    str(leitor.iloc[a,10]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_mensa_kpi4(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_mensal_kpi4(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Mensal_tickets INTEGER,
        Equivalencia_Categoria TEXT,
        Equivalencia_Categoria_tickets_MENSAL INTEGER,
        Anual INTEGER,
        UNIQUE(Mensal,
                Mensal_tickets,
                Equivalencia_Categoria,
                Equivalencia_Categoria_tickets_MENSAL,
                Anual))
        '''
    )

def importar_banco_mensal_kpi4(excel_score_mensal_kpi4):
    leitor = pd.read_excel(excel_score_mensal_kpi4)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_mensal_kpi4(
    Mensal,
    Mensal_tickets,
    Equivalencia_Categoria,
    Equivalencia_Categoria_tickets_MENSAL,
    Anual
    )
    VALUES(?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_mensa_kpi5(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_mensal_kpi5(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Anual INTEGER,
        Media_Mensal_Consolidada REAL,
        Media_Consolidada REAL,
        N INTEGER,
        Media_Anual REAL,
        UNIQUE(Mensal,
                Anual,
                Media_Mensal_Consolidada,
                Media_Consolidada,
                N,
                Media_Anual))
        '''
    )

def importar_banco_mensal_kpi5(excel_score_mensal_kpi5):
    leitor = pd.read_excel(excel_score_mensal_kpi5)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_mensal_kpi5(
    Mensal,
    Anual,
    Media_Mensal_Consolidada,
    Media_Consolidada,
    N,
    Media_Anual
    )
    VALUES(?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()


def criar_banco_anual(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_anual(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Anual TEXT,
        anual_tickets TEXT,
        anual_tickets_percent TEXT,
        Base_historica_consolidado TEXT,
        UNIQUE(Anual,
                anual_tickets,
                anual_tickets_percent,
                Base_historica_consolidado))
        ''')
def importar_banco_anual(excel_score_anual):
    leitor = pd.read_excel(excel_score_anual)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_anual(
    Anual,
    anual_tickets,
    anual_tickets_percent,
    Base_historica_consolidado)
    VALUES(?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_duracao_mensal(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_duracao_mensal(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Net_Time_Mensal TEXT,
        Mensal_tickets TEXT,
        Net_Time_Media_Mensal TEXT,
        Duracao_Mensal_Media TEXT,
        Duracao_Mensal_Consolidada TEXT,
        UNIQUE(Mensal,
                Net_Time_Mensal,
                Mensal_tickets,
                Net_Time_Media_Mensal,
                Duracao_Mensal_Media,
                Duracao_Mensal_Consolidada))
        ''')

def importar_duracao_mensal(excel_duracao_mensal):
    leitor = pd.read_excel(excel_duracao_mensal)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_duracao_mensal(
    Mensal,
    Net_Time_Mensal,
    Mensal_tickets,
    Net_Time_Media_Mensal,
    Duracao_Mensal_Media,
    Duracao_Mensal_Consolidada)
    VALUES(?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_duracao_anual(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_duracao_anual(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Net_Time_Mensal INTEGER,
        Mensal_tickets INTEGER,
        Net_Time_Media_Mensal TEXT,
        Duracao_Mensal_Media TEXT,
        Anual TEXT,
        Net_Time_Anual INTEGER, 
        Anual_tickets INTEGER,
        Net_Time_Media_Anual TEXT,
        Duracao_Anual_Media TEXT,
        Duracao_Anual_Consolidada TEXT,
        Duracao_Mensal_Consolidada TEXT,
        UNIQUE(Mensal,
                Net_Time_Mensal,
                Mensal_tickets,
                Net_Time_Media_Mensal,
                Duracao_Mensal_Media,
                Anual,
                Net_Time_Anual, 
                Anual_tickets,
                Net_Time_Media_Anual,
                Duracao_Anual_Media,
                Duracao_Anual_Consolidada,
                Duracao_Mensal_Consolidada))
        ''')

def importar_duracao_anual(excel_duracao_anual):
    leitor = pd.read_excel(excel_duracao_anual)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_duracao_anual(
    Mensal,
            Net_Time_Mensal,
            Mensal_tickets,
            Net_Time_Media_Mensal,
            Duracao_Mensal_Media,
            Anual,
            Net_Time_Anual, 
            Anual_tickets,
            Net_Time_Media_Anual,
            Duracao_Anual_Media,
            Duracao_Anual_Consolidada,
            Duracao_Mensal_Consolidada
    )
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]),
                    str(leitor.iloc[a,8]),
                    str(leitor.iloc[a,9]),
                    str(leitor.iloc[a,10]),
                    str(leitor.iloc[a,11]))

        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_categoria(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_categoria(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Anual TEXT,
        Evaluation TEXT,
        Evaluation_Mensal_tickets INTEGER,
        Mensal_tickets TEXT,
        Evaluation_percent TEXT,
        UNIQUE(Mensal,
                Anual,
                Evaluation,
                Evaluation_Mensal_tickets,
                Mensal_tickets,
                Evaluation_percent))
        ''')

def importar_banco_categoria(excel_base_categoria):
    leitor = pd.read_excel(excel_base_categoria)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_categoria(
    Mensal,
    Anual,
    Evaluation,
    Evaluation_Mensal_tickets,
    Mensal_tickets,
    Evaluation_percent)
    VALUES(?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_categoria4(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_categoria4(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Mensal_tickets INTEGER,
        Anual TEXT,
        anual_tickets INTEGER,
        n_periodo INTEGER,
        n_periodo_anual INTEGER,
        Volume_Medio REAL,
        UNIQUE(Mensal,
                Mensal_tickets,
                Anual,
                anual_tickets,
                n_periodo,
                n_periodo_anual,
                Volume_Medio))
        ''')

def importar_banco_categoria4(excel_base_categoria4):
    leitor = pd.read_excel(excel_base_categoria4)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_categoria4(
    Mensal,
    Mensal_tickets,
    Anual,
    anual_tickets,
    n_periodo,
    n_periodo_anual,
    Volume_Medio)
    VALUES(?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),)
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_periodo_mensal(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_periodo_mensal(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Equivalencia_Categoria TEXT,
        Equivalencia_Categoria_tickets_MENSAL INTEGER,
        Mensal_tickets INTEGER,
        Equivalencia_efetiva REAL,
        Anual INTEGER,
        UNIQUE(Mensal,
                Equivalencia_Categoria,
                Equivalencia_Categoria_tickets_MENSAL,
                Mensal_tickets,
                Equivalencia_efetiva,
                Anual))
        ''')

def importar_banco_periodo_mensal(excel_base_periodo_mensal2):
    leitor = pd.read_excel(excel_base_periodo_mensal2)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_periodo_mensal(
    Mensal,
    Equivalencia_Categoria,
    Equivalencia_Categoria_tickets_MENSAL,
    Mensal_tickets,
    Equivalencia_efetiva,
    Anual)
    VALUES(?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_periodo_anual(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_periodo_anual(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Anual INTEGER,
        Equivalencia_Categoria TEXT,
        Equivalencia_Categoria_tickets_ANUAL INTEGER,
        anual_tickets INTEGER,
        Equivalencia_efetiva_ANUAL REAL,
        UNIQUE(Anual,
                Equivalencia_Categoria,
                Equivalencia_Categoria_tickets_ANUAL,
                anual_tickets,
                Equivalencia_efetiva_ANUAL))
        ''')

def importar_banco_periodo_anual(excel_base_periodo_anual):
    leitor = pd.read_excel(excel_base_periodo_anual)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_periodo_anual(
    Anual,
    Equivalencia_Categoria,
    Equivalencia_Categoria_tickets_ANUAL,
    anual_tickets,
    Equivalencia_efetiva_ANUAL)
    VALUES(?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_monitoria(bd_distribuicao):
    conexao = sqlite3.connect(bd_distribuicao)
    cursor_banco_mensal = conexao.cursor()
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS distr_monitoria(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Mensal TEXT,
        Mensal_tickets INTEGER,
        Mensal_tickets_percent TEXT,
        Anual INTEGER,
        Avaliacao TEXT,
        Avaliacao_Mensal INTEGER,
        UNIQUE(Mensal,
                Mensal_tickets,
                Mensal_tickets_percent,
                Anual,
                Avaliacao,
                Avaliacao_Mensal))
        ''')
    
def importar_banco_monitoria(excel_base_avaliacao):
    leitor = pd.read_excel(excel_base_avaliacao)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_distribuicao)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO distr_monitoria(
    Mensal,
    Mensal_tickets,
    Mensal_tickets_percent,
    Anual,
    Avaliacao,
    Avaliacao_Mensal
    )
    VALUES(?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

def criar_banco_geral_processado(bd_geral_processado):
    conexao = sqlite3.connect(bd_geral_processado)
    cursor_banco_mensal = conexao.cursor()
    '''
    '''
    cursor_banco_mensal = cursor_banco_mensal.execute(
        '''
        CREATE TABLE IF NOT EXISTS tabela_mes_ano_compilado(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Ticket_ID TEXT,
        Archive_date TEXT,
        Evaluation TEXT,
        Editor_category TEXT,
        Net_Time TEXT,
        Net_Time_MM TEXT,
        Net_Time_HH TEXT,
        Net_Time_HHDD TEXT,
        Duracao TEXT,
        Net_Time_Ticket TEXT,
        Diario TEXT,
        Net_Time_Diario TEXT,
        Evaluation_Diario_tickets TEXT,
        Diario_tickets TEXT,
        Mensal TEXT,
        Net_Time_Mensal TEXT,
        Evaluation_Mensal_tickets TEXT,
        Mensal_tickets TEXT,
        Net_Time_Media_Mensal TEXT,
        Duracao_Mensal_Media TEXT,
        Duracao_Mensal_Consolidada TEXT,
        Anual TEXT,
        Net_Time_Anual TEXT,
        anual_tickets TEXT,
        Net_Time_Media_Anual TEXT,
        Duracao_Anual_Media TEXT,
        Duracao_Anual_Consolidada TEXT,
        IO TEXT,
        Base_historica_consolidado TEXT,
        Diario_tickets_percent TEXT,
        Mensal_tickets_percent TEXT,
        anual_tickets_percent TEXT,
        Evaluation_Diario TEXT,
        Category_Diario TEXT,
        Evaluation_Mensal TEXT,
        Category_Mensal TEXT,
        Evaluation_anual TEXT,
        Category_anual TEXT,
        Avaliacao TEXT,
        Avaliacao_Mensal TEXT,
        Avaliacao_Anual TEXT,
        Equivalencia_Categoria TEXT,
        Equivalencia_Categoria_tickets_MENSAL TEXT,
        Evaluation_elegibilidade TEXT,
        Peso_Media_Mensal TEXT,
        Evaluation_Mensal_tickets_elegiveis TEXT,
        Media_Mensal TEXT,
        UNIQUE(Ticket_ID,
                Archive_date,
                Evaluation,
                Editor_category,
                Net_Time,
                Net_Time_MM,
                Net_Time_HH,
                Net_Time_HHDD,
                Duracao,
                Net_Time_Ticket,
                Diario,
                Net_Time_Diario,
                Evaluation_Diario_tickets,
                Diario_tickets,
                Mensal,
                Net_Time_Mensal,
                Evaluation_Mensal_tickets,
                Mensal_tickets,
                Net_Time_Media_Mensal,
                Duracao_Mensal_Media,
                Duracao_Mensal_Consolidada,
                Anual,
                Net_Time_Anual,
                anual_tickets,
                Net_Time_Media_Anual,
                Duracao_Anual_Media,
                Duracao_Anual_Consolidada,
                IO,
                Base_historica_consolidado,
                Diario_tickets_percent,
                Mensal_tickets_percent,
                anual_tickets_percent,
                Evaluation_Diario,
                Category_Diario,
                Evaluation_Mensal,
                Category_Mensal,
                Evaluation_anual,
                Category_anual,
                Avaliacao,
                Avaliacao_Mensal,
                Avaliacao_Anual,
                Equivalencia_Categoria,
                Equivalencia_Categoria_tickets_MENSAL,
                Evaluation_elegibilidade,
                Peso_Media_Mensal,
                Evaluation_Mensal_tickets_elegiveis,
                Media_Mensal))
        ''')
    
def importar_banco_geral_processado(excel_base_geral):
    leitor = pd.read_excel(excel_base_geral)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(bd_geral_processado)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO tabela_mes_ano_compilado(
                Ticket_ID,
                Archive_date,
                Evaluation,
                Editor_category,
                Net_Time,
                Net_Time_MM,
                Net_Time_HH,
                Net_Time_HHDD,
                Duracao,
                Net_Time_Ticket,
                Diario,
                Net_Time_Diario,
                Evaluation_Diario_tickets,
                Diario_tickets,
                Mensal,
                Net_Time_Mensal,
                Evaluation_Mensal_tickets,
                Mensal_tickets,
                Net_Time_Media_Mensal,
                Duracao_Mensal_Media,
                Duracao_Mensal_Consolidada,
                Anual,
                Net_Time_Anual,
                anual_tickets,
                Net_Time_Media_Anual,
                Duracao_Anual_Media,
                Duracao_Anual_Consolidada,
                IO,
                Base_historica_consolidado,
                Diario_tickets_percent,
                Mensal_tickets_percent,
                anual_tickets_percent,
                Evaluation_Diario,
                Category_Diario,
                Evaluation_Mensal,
                Category_Mensal,
                Evaluation_anual,
                Category_anual,
                Avaliacao,
                Avaliacao_Mensal,
                Avaliacao_Anual,
                Equivalencia_Categoria,
                Equivalencia_Categoria_tickets_MENSAL,
                Evaluation_elegibilidade,
                Peso_Media_Mensal,
                Evaluation_Mensal_tickets_elegiveis,
                Media_Mensal
    )
    VALUES(?,?,?,?,?,?,?,?,?,?,
    ?,?,?,?,?,?,?,?,?,?,
    ?,?,?,?,?,?,?,?,?,?,
    ?,?,?,?,?,?,?,?,?,?,
    ?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]),
                    str(leitor.iloc[a,8]),
                    str(leitor.iloc[a,9]),
                    str(leitor.iloc[a,10]),
                    str(leitor.iloc[a,11]),
                    str(leitor.iloc[a,12]),
                    str(leitor.iloc[a,13]),
                    str(leitor.iloc[a,14]),
                    str(leitor.iloc[a,15]),
                    str(leitor.iloc[a,16]),
                    str(leitor.iloc[a,17]),
                    str(leitor.iloc[a,18]),
                    str(leitor.iloc[a,19]),
                    str(leitor.iloc[a,20]),
                    str(leitor.iloc[a,21]),
                    str(leitor.iloc[a,22]),
                    str(leitor.iloc[a,23]),
                    str(leitor.iloc[a,24]),
                    str(leitor.iloc[a,25]),
                    str(leitor.iloc[a,26]),
                    str(leitor.iloc[a,27]),
                    str(leitor.iloc[a,28]),
                    str(leitor.iloc[a,29]),
                    str(leitor.iloc[a,30]),
                    str(leitor.iloc[a,31]),
                    str(leitor.iloc[a,32]),
                    str(leitor.iloc[a,33]),
                    str(leitor.iloc[a,34]),
                    str(leitor.iloc[a,35]),
                    str(leitor.iloc[a,36]),
                    str(leitor.iloc[a,37]),
                    str(leitor.iloc[a,38]),
                    str(leitor.iloc[a,39]),
                    str(leitor.iloc[a,40]),
                    str(leitor.iloc[a,41]),
                    str(leitor.iloc[a,42]),
                    str(leitor.iloc[a,43]),
                    str(leitor.iloc[a,44]),
                    str(leitor.iloc[a,45]),
                    str(leitor.iloc[a,46]))
        cursor.execute(query,valores)

    conexao.commit()
    conexao.close()

cria_pastas()
print('*** Pastas criadas com sucesso!!!')
importar_base_padrao()
print('*** Base convertida criada com sucesso!!! Extensão convertida de *.csv para *.xlsx')
relatorio_filtro()
print(f'*** Base filtrada criada com sucesso!!! Realizado triagem de colunas.')
filtro_auto_arquivado()
print(f'*** Base relatorio_ETKA_{agora}_filtrada_AUTO_ARCHIVED.xlsx criada com sucesso!!!')
filtro_bom()
print(f'*** Base relatorio_ETKA_{agora}_filtrada_GOOD.xlsx criada com sucesso!!!')
filtro_satisfatorio()
print(f'*** Base relatorio_ETKA_{agora}_filtrada_SATISFACTORY.xlsx criada com sucesso!!!')
filtro_suficiente()
print(f'*** Base relatorio_ETKA_{agora}_filtrada_SUFFICIENT.xlsx criada com sucesso!!!')
filtro_muito_bom()
print(f'*** Base relatorio_ETKA_{agora}_filtrada_VERY_GOOD.xlsx criada com sucesso!!!')
quantificacao_auto_arquivado()
print(f'*** Base relatorio_ETKA_{agora}_distribuicao_AUTO_ARCHIVED.xlsx criada com sucesso!!!')
quantificacao_bom()
print(f'*** Base relatorio_ETKA_{agora}_distribuicao_GOOD.xlsx.xlsx criada com sucesso!!!')
quantificacao_satisfatorio()
print(f'*** Base relatorio_ETKA_{agora}_distribuicao_SATISFACTORY.xlsx criada com sucesso!!!')
quantificacao_suficiente()
print(f'*** Base relatorio_ETKA_{agora}_distribuicao_SUFFICIENT.xlsx criada com sucesso!!!')
quantificacao_muito_bom()
print(f'*** Base relatorio_ETKA_{agora}_distribuicao_VERY_GOOD.xlsx criada com sucesso!!!')
base_geral()
print(f'*** Base mes_ano_{agora}.xlsx criada com sucesso!!!')
score_diario()
print(f'*** Base score_diario.xlsx criada com sucesso!!!')
score_diario_kpi()
print(f'*** Base score_diario_kpi.xlsx criada com sucesso!!!')
score_mensal()
print(f'*** Base score_mensal.xlsx criada com sucesso!!!')
score_mensal_kpi()
print(f'*** Base score_mensal_kpi.xlsx criada com sucesso!!!')
score_mensal_kpi2()
print(f'*** Base score_mensal_kpi2.xlsx criada com sucesso!!!')
score_mensal_kpi3()
print(f'*** Base score_mensal_kpi3.xlsx criada com sucesso!!!')
score_mensal_kpi4()
print(f'*** Base score_mensal_kpi4.xlsx criada com sucesso!!!')
score_mensal_kpi5()
print(f'*** Base score_mensal_kpi5.xlsx criada com sucesso!!!')
score_mensal_kpi_categoria()
print(f'*** Base score_mensal_kpi_categoria.xlsx criada com sucesso!!!')
score_mensal_kpi_avaliacao()
print(f'*** Base score_mensal_kpi_avaliacao.xlsx criada com sucesso!!!')
score_anual()
print(f'*** Base score_anual.xlsx criada com sucesso!!!')
score_anual_kpi()
print(f'*** Base score_anual_kpi.xlsx criada com sucesso!!!')
score_duracao_mensal()
print(f'*** Base painel_duracao_mensal.xlsx criada com sucesso!!!')
score_duracao_anual()
print(f'*** Base painel_duracao_anual.xlsx criada com sucesso!!!')
score_categoria()
print(f'*** Base painel_categoria.xlsx criada com sucesso!!!')
score_categoria2()
print(f'*** Base painel_categoria2.xlsx criada com sucesso!!!')
score_categoria3()
print(f'*** Base painel_categoria3.xlsx criada com sucesso!!!')
score_categoria4()
print(f'*** Base painel_categoria4.xlsx criada com sucesso!!!')
score_periodo_mensal()
print(f'*** Base periodo_mensal.xlsx criada com sucesso!!!')
score_periodo_mensal2()
print(f'*** Base periodo_mensal2.xlsx criada com sucesso!!!')
score_periodo_anual()
print(f'*** Base periodo_anual.xlsx criada com sucesso!!!')
compilacao()
print(f'*** Base relatorio_ETKA_{agora}_base_compilada.xlsx criada com sucesso!!!')
criar_banco_geral(bd_geral)
print('*** Banco de dados Geral criado com sucesso!!!')
importar_banco_geral(excel_adq_filtrada)
criar_banco_auto_arquivado(bd_geral)
importar_banco_auto_arquivado(excel_auto_arquivado)
criar_banco_good(bd_geral)
importar_banco_good(excel_good)
criar_satisfactory(bd_geral)
importar_banco_satisfactory(excel_satisfactory)
criar_sufficient(bd_geral)
importar_banco_sufficient(excel_sufficient)
criar_very_good(bd_geral)
importar_banco_very_good(excel_very_good)
criar_banco_distribuicao_auto_arq(bd_distribuicao)
criar_banco_distribuicao_good(bd_distribuicao)
criar_banco_distribuicao_satisfactory(bd_distribuicao)
criar_banco_distribuicao_sufficient(bd_distribuicao)
criar_banco_distribuicao_very_good(bd_distribuicao)
criar_banco_mensal(bd_distribuicao)
criar_banco_anual(bd_distribuicao)
criar_banco_mensa_kpi(bd_distribuicao)
criar_banco_mensa_kpi2(bd_distribuicao)
criar_banco_mensa_kpi3(bd_distribuicao)
criar_banco_mensa_kpi4(bd_distribuicao)
criar_banco_mensa_kpi5(bd_distribuicao)
criar_banco_duracao_mensal(bd_distribuicao)
criar_banco_duracao_anual(bd_distribuicao)
criar_banco_categoria(bd_distribuicao)
criar_banco_categoria4(bd_distribuicao)
criar_banco_periodo_mensal(bd_distribuicao)
criar_banco_monitoria(bd_distribuicao)
criar_banco_periodo_anual(bd_distribuicao)
criar_banco_geral_processado(bd_geral_processado)
print('*** Banco de dadosW criado com sucesso!!!')
importar_banco_dist_aut_arq(excel_distribuica_auto_arquivado)
importar_banco_distr_good(excel_distribuicao_good)
importar_banco_distr_satisfactory(excel_distribuicao_satisfactory)
importar_banco_distr_sufficient(excel_distribuicao_sufficient)
importar_banco_distr_very_good(excel_distribuicao_very_good)
importar_banco_mensal(excel_score_mensal)
importar_banco_anual(excel_score_anual)
importar_banco_mensal_kpi(excel_score_mensal_kpi)
importar_banco_mensal_kpi2(excel_score_mensal_kpi2)
importar_banco_mensal_kpi3(excel_score_mensal_kpi3)
importar_banco_mensal_kpi4(excel_score_mensal_kpi4)
importar_banco_mensal_kpi5(excel_score_mensal_kpi5)
importar_duracao_mensal(excel_duracao_mensal)
importar_duracao_anual(excel_duracao_anual)
importar_banco_categoria(excel_base_categoria)
importar_banco_categoria4(excel_base_categoria4)
importar_banco_periodo_mensal(excel_base_periodo_mensal2)
importar_banco_monitoria(excel_base_avaliacao)
importar_banco_periodo_anual(excel_base_periodo_anual)
importar_banco_geral_processado(excel_base_geral)
print('*** Tabelas criadas e importadas com sucesso!!!')
