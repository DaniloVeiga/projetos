import pandas as pd
import dash
from dash import dcc, html, Input, Output, State
from dash.exceptions import PreventUpdate
import plotly.io as pio
import tempfile
from datetime import datetime
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import plotly.express as px
import sqlite3
import openpyxl
import kaleido
import threading
import webbrowser
from dash import dash_table
from docx import Document
from docx.shared import Inches
import os

# ==========================================
# LEITURA
# ==========================================
# ==========================================
# LEITURA - STATUS POR TIPO DE LIBERAÇÃO
# ==========================================

#--------------------------------------
#CONFIGURAÇÕES
#BASE_DIR = r'\\10.142.201.59\Pecas_e_Acessorios_Vinhedo\Dashboard P&A\Tickets (Danilo)'
#USUARIOS_DB = os.path.join(BASE_DIR, "usuarios.db")
#DEMANDAS_DB = os.path.join(BASE_DIR, "demandas.db")
#CARDS_DB = os.path.join(BASE_DIR, "cards.db")
#DEVOLUTIVAS_DB = os.path.join(BASE_DIR, "devolutivas.db")

#BASE_DIR = r'\\10.142.201.59\Pecas_e_Acessorios_Vinhedo\Dashboard P&A\Tickets (Danilo)'
BASE_DIR = r'.\base_sql'
BANCO1 = os.path.join(BASE_DIR,'base_distribuicoes.db')
#BANCO1 = os.path.join(BASE_DIR,'base_distribuicoes.db')
BANCO2 = os.path.join(BASE_DIR,'auto_arquivado.db')
#BANCO2 = os.path.join(BASE_DIR,'auto_arquivado.db')
BANCO3 = os.path.join(BASE_DIR,'base_geral_processada.db')
#BANCO3 = os.path.join(BASE_DIR,'base_geral_processada.db')

conexao = sqlite3.connect(BANCO1)
df = pd.read_sql_query("""SELECT Mensal, Evaluation, Anual, Evaluation_Mensal FROM distr_mensal_kpi""",conexao)
df2 = pd.read_sql_query("""SELECT Mensal, Avaliacao, Anual, Avaliacao_Mensal FROM distr_monitoria""",conexao)
df3 = pd.read_sql_query("""SELECT Mensal,Avaliacao,Anual,Avaliacao_Mensal, Mensal_tickets, Avaliacao_Mensal_percent AS AV_PERCENT FROM distr_mensal_kpi2""",conexao)
df4 = pd.read_sql_query("""SELECT Mensal,Anual,Evaluation,Media_Mensal,Media_Mensal_Consolidada FROM distr_mensal_kpi3""",conexao)
df5 = pd.read_sql_query("""SELECT Mensal,Anual, Media_Mensal_Consolidada, Media_Anual FROM distr_mensal_kpi5""",conexao)
conexao.close()
df.columns = df.columns.str.strip()

meses = {
    'janeiro': '01',
    'fevereiro': '02',
    'março': '03',
    'abril': '04',
    'maio': '05',
    'junho': '06',
    'julho': '07',
    'agosto': '08',
    'setembro': '09',
    'outubro': '10',
    'novembro': '11',
    'dezembro': '12'
}

df["Data_Mensal"] = pd.to_datetime(
    df["Mensal"].apply(
        lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
    )
)

df3 = df3.sort_values(
    by="Mensal",
    key=lambda s: pd.to_datetime(
        s.apply(
            lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
        )
    )
)

df3["Data_Mensal"] = pd.to_datetime(
    df3["Mensal"].apply(
        lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
    )
)

df4["Data_Mensal"] = pd.to_datetime(
    df4["Mensal"].apply(
        lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
    )
)

df5["Data_Mensal"] = pd.to_datetime(
    df5["Mensal"].apply(
        lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
    )
)

# ==========================================
# LEITURA - STATUS DA PÁGINA
# ==========================================

conexao = sqlite3.connect(BANCO1)
df_grupo1 = pd.read_sql_query("""SELECT * FROM distr_duracao_mensal""",conexao)
df_grupo1_2 = pd.read_sql_query("""SELECT * FROM distr_duracao_anual""",conexao)
conexao.close()

meses = {
    'janeiro': '01',
    'fevereiro': '02',
    'março': '03',
    'abril': '04',
    'maio': '05',
    'junho': '06',
    'julho': '07',
    'agosto': '08',
    'setembro': '09',
    'outubro': '10',
    'novembro': '11',
    'dezembro': '12'
}

df_grupo1["Data_Mensal"] = pd.to_datetime(
    df_grupo1["Mensal"].apply(
        lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
    )
)
df_grupo1["Anual"] = (
    df_grupo1["Data_Mensal"]
    .dt.year
    .astype(str)
)

df_grupo1_2["Data_Anual"] = pd.to_datetime(
    df_grupo1_2["Anual"].astype(str) + "-01-01"
)

# ==========================================
# GRUPO 2
# ==========================================

# ==========================================
# LEITURA - STATUS NÚMERO DE ILUSTRAÇÕES
# ==========================================

conexao = sqlite3.connect(BANCO1)
df_grupo2 = pd.read_sql_query("""SELECT * FROM distr_categoria""",conexao)
df_grupo2b = pd.read_sql_query("""SELECT * FROM distr_categoria4""",conexao)
df_grupo2b["Anual"] = pd.to_numeric(
    df_grupo2b["Anual"],
    errors="coerce"
)
conexao.close()

# ==========================================
# GRUPO 3
# ==========================================
# ==========================================
# LEITURA - STATUS DA DATA DE DIGITALIZAÇÃO
# ==========================================

conexao = sqlite3.connect(BANCO1)
df_grupo3 = pd.read_sql_query("""SELECT * FROM distr_periodo_mensal""",conexao)
df_grupo3b = pd.read_sql_query("""SELECT * FROM distr_periodo_anual""",conexao)
conexao.close()

# ==========================================
# GRUPO 4
# ==========================================
# ==========================================
# LEITURA - STATUS POR TIPO DE LIBERAÇÃO
# ==========================================

conexao = sqlite3.connect(BANCO2)
df_grupo4 = pd.read_sql_query("""SELECT * FROM geral_tabela""",conexao)
conexao.close()

conexao = sqlite3.connect(BANCO3)
df_grupo5 = pd.read_sql_query("""SELECT * FROM tabela_mes_ano_compilado""",conexao)
conexao.close()

# ==========================================
# FUNÇÃO PARA GERAR FIGURA
# ==========================================
def criar_figura(
    evaluation="Todos",
    anual="Todos",
    mensal="Todos",
    start_date=None,
    end_date=None
):

    df_filtrado = df.copy()

    # ==========================
    # FILTRO EVALUATION
    # ==========================
    if evaluation != "Todos":
        df_filtrado = df_filtrado[
            df_filtrado["Evaluation"].astype(str) == str(evaluation)
        ]

    # ==========================
    # FILTRO ANUAL
    # ==========================
    if anual != "Todos":
        df_filtrado = df_filtrado[
            df_filtrado["Anual"].astype(str) == str(anual)
        ]

    # ==========================
    # FILTRO MENSAL
    # ==========================
    if mensal != "Todos":
        df_filtrado = df_filtrado[
            df_filtrado["Mensal"].astype(str) == str(mensal)
        ]

    # ==========================
    # FILTRO DATE PICKER
    # ==========================
    if start_date and end_date:

        start_date = pd.to_datetime(start_date)
        end_date = pd.to_datetime(end_date)

        df_filtrado = df_filtrado[
            (df_filtrado["Data_Mensal"] >= start_date) &
            (df_filtrado["Data_Mensal"] <= end_date)
        ]

    # ==========================
    # FIGURA
    # ==========================
    fig = make_subplots(
        rows=1,
        cols=2,
        specs=[[{"type": "table"}, {"type": "domain"}]],
        subplot_titles=("Tabela", "Distribuição")
    )

    # ==========================
    # TABELA
    # ==========================
    colunas_tabela = [
        col for col in df_filtrado.columns
        if col != "Data_Mensal"
    ]

    fig.add_trace(
        go.Table(
            header=dict(
                values=colunas_tabela,
                fill_color="#2C3E50",
                font=dict(
                    color="white",
                    size=12
                )
            ),
            cells=dict(
                values=[
                    df_filtrado[col]
                    for col in colunas_tabela
                ]
            )
        ),
        row=1,
        col=1
    )

    # ==========================
    # PIZZA
    # ==========================
    fig.add_trace(
        go.Pie(
            labels=df_filtrado["Evaluation"],
            values=df_filtrado["Evaluation_Mensal"],
            textinfo="percent+label"
        ),
        row=1,
        col=2
    )

    # ==========================
    # LAYOUT
    # ==========================
    fig.update_layout(
        title_text=(
            f"Evaluation: {evaluation} | "
            f"Ano: {anual} | "
            f"Mês: {mensal}"
        ),
        title_x=0.5,
        height=700
    )

    return fig

df2["Data_Mensal"] = pd.to_datetime(
    df2["Mensal"].apply(
        lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
    )
)
def criar_figura2(
    avaliacao="Todos",
    anual="Todos",
    mensal="Todos",
    start_date=None,
    end_date=None
):

    df_filtrado2 = df2.copy()

    # ==================================
    # FILTRO AVALIAÇÃO
    # ==================================
    if avaliacao != "Todos":
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Avaliacao"].astype(str)
            == str(avaliacao)
        ]

    # ==================================
    # FILTRO ANUAL
    # ==================================
    if anual != "Todos":
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Anual"].astype(str)
            == str(anual)
        ]

    # ==================================
    # FILTRO MENSAL
    # ==================================
    if mensal != "Todos":
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Mensal"].astype(str)
            == str(mensal)
        ]

    # ==================================
    # FILTRO DATE PICKER
    # ==================================
    if start_date and end_date:

        start_date = pd.to_datetime(start_date)
        end_date = pd.to_datetime(end_date)

        df_filtrado2 = df_filtrado2[
            (df_filtrado2["Data_Mensal"] >= start_date)
            &
            (df_filtrado2["Data_Mensal"] <= end_date)
        ]

    # ==================================
    # SUBPLOTS
    # ==================================
    fig2 = make_subplots(
        rows=1,
        cols=2,
        specs=[[{"type": "table"}, {"type": "domain"}]],
        subplot_titles=("Tabela", "Distribuição")
    )

    # ==================================
    # TABELA
    # ==================================
    colunas_tabela = [
        col
        for col in df_filtrado2.columns
        if col != "Data_Mensal"
    ]

    fig2.add_trace(
        go.Table(
            header=dict(
                values=colunas_tabela,
                fill_color="#2C3E50",
                font=dict(
                    color="white",
                    size=12
                )
            ),
            cells=dict(
                values=[
                    df_filtrado2[col]
                    for col in colunas_tabela
                ]
            )
        ),
        row=1,
        col=1
    )

    # ==================================
    # GRÁFICO PIZZA
    # ==================================
    fig2.add_trace(
        go.Pie(
            labels=df_filtrado2["Avaliacao"],
            values=df_filtrado2["Avaliacao_Mensal"],
            textinfo="percent+label",
            #hole=0.3
            marker=dict(
            colors=df_filtrado2["Avaliacao"].map({
                "AVALIADO": "#636EFA",
                "NÃO AVALIADO": "#EF553B"
            })
        )
        ),
        row=1,
        col=2
    )

    # ==================================
    # LAYOUT
    # ==================================
    fig2.update_layout(
        title_text=(
            f"Avaliação: {avaliacao} | "
            f"Ano: {anual} | "
            f"Mês: {mensal}"
        ),
        title_x=0.5,
        height=700
    )

    return fig2

def criar_figura3(
    avaliacao="Todos",
    anual="Todos",
    mensal="Todos",
    anos_selecionados=None
):

    # =====================================
    # CÓPIA DOS DADOS
    # =====================================
    df_filtrado3 = df3.copy()

    # =====================================
    # FILTRO AVALIAÇÃO
    # =====================================
    if avaliacao != "Todos":
        df_filtrado3 = df_filtrado3[
            df_filtrado3["Avaliacao"].astype(str) == str(avaliacao)
        ]

    # =====================================
    # FILTRO ANUAL
    # =====================================
    if anual != "Todos":
        df_filtrado3 = df_filtrado3[
            df_filtrado3["Anual"].astype(str) == str(anual)
        ]

    # =====================================
    # FILTRO MENSAL
    # =====================================
    if mensal != "Todos":
        df_filtrado3 = df_filtrado3[
            df_filtrado3["Mensal"].astype(str) == str(mensal)
        ]

    # =====================================
    # FILTRO PERÍODO
    # =====================================
    if anos_selecionados:

        df_filtrado3 = df_filtrado3[
            df_filtrado3["Anual"].astype(str).isin(
                [str(x) for x in anos_selecionados]
            )
        ]

    # =====================================
    # ORDENAÇÃO CRONOLÓGICA
    # =====================================
    meses = {
        "janeiro": "01",
        "fevereiro": "02",
        "março": "03",
        "abril": "04",
        "maio": "05",
        "junho": "06",
        "julho": "07",
        "agosto": "08",
        "setembro": "09",
        "outubro": "10",
        "novembro": "11",
        "dezembro": "12"
    }

    df_filtrado3 = df_filtrado3.sort_values(
        by="Mensal",
        key=lambda s: pd.to_datetime(
            s.apply(
                lambda x: (
                    f"{x.split('.')[1]}-"
                    f"{meses[x.split('.')[0].lower()]}-01"
                )
            )
        )
    )

    # =====================================
    # SUBPLOTS
    # =====================================
    fig3 = make_subplots(
        rows=1,
        cols=2,
        specs=[[{"type": "table"}, {"type": "xy"}]],
        column_widths=[0.45, 0.55]
    )

    # =====================================
    # TABELA
    # =====================================
    colunas_tabela = [
        col
        for col in df_filtrado3.columns
        if col != "Data_Mensal"
    ]

    fig3.add_trace(
        go.Table(
            header=dict(
                values=colunas_tabela,
                fill_color="#2C3E50",
                font=dict(
                    color="white",
                    size=12
                ),
                align="center"
            ),
            cells=dict(
                values=[
                    df_filtrado3[col]
                    for col in colunas_tabela
                ],
                align="center"
            )
        ),
        row=1,
        col=1
    )

    # =====================================
    # BARRAS EMPILHADAS
    # =====================================
    fig_bar = px.bar(
        df_filtrado3,
        x="Mensal",
        y="Avaliacao_Mensal",
        color="Avaliacao",
        barmode="stack",
        category_orders={
            "Avaliacao": [
                "AVALIADO",
                "NÃO AVALIADO"
            ]
        },
        color_discrete_map={
            "AVALIADO": "#636EFA",
            "NÃO AVALIADO": "#EF553B"
        }
    )

    for trace in fig_bar.data:

        trace.textposition = "inside"
        trace.insidetextanchor = "middle"

        fig3.add_trace(
            trace,
            row=1,
            col=2
        )

    # =====================================
    # TOTAL DE TICKETS
    # =====================================
    fig3.add_trace(
        go.Scatter(
            x=df_filtrado3["Mensal"],
            y=df_filtrado3["Mensal_tickets"],
            mode="markers+text",
            marker=dict(
                size=12,
                color="black",
                symbol="diamond"
            ),
            text=df_filtrado3["Mensal_tickets"],
            textposition="top center",
            name="Total Tickets"
        ),
        row=1,
        col=2
    )

    # =====================================
    # LAYOUT
    # =====================================
    fig3.update_layout(
        title_text=(
            f"Avaliação: {avaliacao} | "
            f"Ano: {anual} | "
            f"Mês: {mensal}"
        ),
        title_x=0.5,
        height=700,
        barmode="stack",
        legend=dict(
            traceorder="reversed"
        ),
        plot_bgcolor="white",
        paper_bgcolor="white"
    )

    fig3.update_xaxes(
        tickangle=90,
        row=1,
        col=2
    )

    fig3.update_yaxes(
        showgrid=True,
        gridcolor="lightgray",
        row=1,
        col=2
    )

    return fig3

def criar_figura4(
    evaluation="Todos",
    anual="Todos",
    mensal="Todos",
    anos_selecionados=None
):

    # =====================================
    # CÓPIA DOS DADOS
    # =====================================
    df_filtrado4 = df4.copy()

    # =====================================
    # FILTRO EVALUATION
    # =====================================
    if evaluation != "Todos":
        df_filtrado4 = df_filtrado4[
            df_filtrado4["Evaluation"].astype(str) == str(evaluation)
        ]

    # =====================================
    # FILTRO ANUAL
    # =====================================
    if anual != "Todos":
        df_filtrado4 = df_filtrado4[
            df_filtrado4["Anual"].astype(str) == str(anual)
        ]

    # =====================================
    # FILTRO MENSAL
    # =====================================
    if mensal != "Todos":
        df_filtrado4 = df_filtrado4[
            df_filtrado4["Mensal"].astype(str) == str(mensal)
        ]

    # =====================================
    # FILTRO ANOS SELECIONADOS
    # =====================================
    if anos_selecionados:
        df_filtrado4 = df_filtrado4[
            df_filtrado4["Anual"].astype(str).isin(
                [str(x) for x in anos_selecionados]
            )
        ]

    # =====================================
    # ORDENAÇÃO
    # =====================================
    df_filtrado4 = df_filtrado4.sort_values("Data_Mensal")

    # =====================================
    # CONVERSÕES
    # =====================================
    df_filtrado4["Media_Mensal"] = pd.to_numeric(
        df_filtrado4["Media_Mensal"],
        errors="coerce"
    )

    df_filtrado4["Media_Mensal_Consolidada"] = pd.to_numeric(
        df_filtrado4["Media_Mensal_Consolidada"],
        errors="coerce"
    )

    # =====================================
    # DADOS CONSOLIDADOS
    # UMA BARRA POR MÊS
    # =====================================
    df_media = (
        df_filtrado4
        .groupby("Mensal", as_index=False)
        ["Media_Mensal_Consolidada"]
        .mean()
    )

    # =====================================
    # SUBPLOTS
    # =====================================
    fig4 = make_subplots(
        rows=1,
        cols=2,
        specs=[[{"type": "table"}, {"type": "xy"}]],
        column_widths=[0.40, 0.60]
    )

    # =====================================
    # TABELA
    # =====================================
    colunas = [
        c for c in df_filtrado4.columns
        if c != "Data_Mensal"
    ]

    fig4.add_trace(
        go.Table(
            header=dict(
                values=colunas,
                fill_color="#2C3E50",
                font=dict(
                    color="white",
                    size=12
                ),
                align="center"
            ),
            cells=dict(
                values=[
                    df_filtrado4[c]
                    for c in colunas
                ],
                align="center"
            )
        ),
        row=1,
        col=1
    )

    # =====================================
    # BARRAS
    # =====================================
    df_media = (
    df_filtrado4
    .groupby(
        ["Mensal", "Data_Mensal"],
        as_index=False
    )["Media_Mensal_Consolidada"]
    .mean()
    .sort_values("Data_Mensal")
)
    fig4.add_trace(
        go.Bar(
            x=df_media["Mensal"],
            y=df_media["Media_Mensal_Consolidada"],
            text=df_media["Media_Mensal_Consolidada"].round(2),
            textposition="outside",
            name="Média Consolidada",
            marker=dict(
                color=df_media["Media_Mensal_Consolidada"],
                colorscale=[
                    [0.00, "black"],
                    [0.22, "grey"],
                    [0.44, "lightgrey"],
                    [0.66, "blue"],
                    [1.00, "lightblue"]
                ],
                cmin=0,
                cmax=100,
                showscale=True,
                colorbar=dict(
                    title="Média",
                    tickvals=[0, 25, 50, 75, 100]
                )
            )
        ),
        row=1,
        col=2
    )

    # =====================================
    # TARGET
    # =====================================
    target = 90

    fig4.add_trace(
        go.Scatter(
            x=df_media["Mensal"],
            y=[target] * len(df_media),
            mode="lines",
            name=f"Target {target}%",
            line=dict(
                color="red",
                width=3,
                dash="dash"
            )
        ),
        row=1,
        col=2
    )

    # =====================================
    # LAYOUT
    # =====================================
    fig4.update_layout(
        title_text=(
            f"Evaluation: {evaluation} | "
            f"Ano: {anual} | "
            f"Mês: {mensal}"
        ),
        title_x=0.5,
        height=700,
        plot_bgcolor="white",
        paper_bgcolor="white",
        legend=dict(
            orientation="h",
            y=1.10,
            x=0.5,
            xanchor="center"
        )
    )

    # =====================================
    # EIXO X
    # =====================================
    fig4.update_xaxes(
        tickangle=90,
        row=1,
        col=2
    )

    # =====================================
    # EIXO Y
    # =====================================
    fig4.update_yaxes(
        range=[0, 100],
        showgrid=True,
        gridcolor="lightgray",
        row=1,
        col=2
    )

    return fig4

def criar_figura5(
    anual="Todos",
    mensal="Todos",
    anos_selecionados=None
):

    df_filtrado5 = df5.copy()

    # ==========================
    # FILTRO ANUAL
    # ==========================
    if anual != "Todos":

        df_filtrado5 = df_filtrado5[
            df_filtrado5["Anual"].astype(str)
            == str(anual)
        ]

    # ==========================
    # FILTRO MENSAL
    # ==========================
    if mensal != "Todos":

        df_filtrado5 = df_filtrado5[
            df_filtrado5["Mensal"].astype(str)
            == str(mensal)
        ]

    # ==========================
    # FILTRO DE PERÍODO
    # ==========================
    # FILTRO ANOS CHECKLIST
    if anos_selecionados:
        df_filtrado5 = df_filtrado5[
            df_filtrado5["Anual"].astype(str).isin(
                [str(x) for x in anos_selecionados]
            )
        ]

    # ==========================
    # ORDENAÇÃO
    # ==========================
    df_filtrado5 = df_filtrado5.sort_values(
        by="Data_Mensal"
    )

    # ==========================
    # CONVERSÕES
    # ==========================
    df_filtrado5["Media_Mensal_Consolidada"] = pd.to_numeric(
        df_filtrado5["Media_Mensal_Consolidada"],
        errors="coerce"
    )

    df_filtrado5["Media_Anual"] = pd.to_numeric(
        df_filtrado5["Media_Anual"],
        errors="coerce"
    )

    # ==========================
    # CÁLCULO MÉDIA ANUAL
    # ==========================
    df_media = (
    df_filtrado5
    .groupby("Anual", as_index=False)
    .agg(
        Media_Anual=("Media_Anual", "mean"),
        Topo_Barra=("Media_Mensal_Consolidada", "sum")
    )
)

    df_media["Y_Scatter"] = df_media["Topo_Barra"] + 10
        # ==========================
    # SUBPLOTS
    # ==========================
    fig5 = make_subplots(
        rows=1,
        cols=2,
        specs=[
            [
                {"type": "table"},
                {"type": "xy"}
            ]
        ],
        column_widths=[0.40, 0.60]
    )

    # ==========================
    # TABELA
    # ==========================
    colunas = [
        c
        for c in df_filtrado5.columns
        if c != "Data_Mensal"
    ]

    fig5.add_trace(
        go.Table(
            header=dict(
                values=colunas,
                fill_color="#2C3E50",
                font=dict(
                    color="white",
                    size=12
                ),
                align="center"
            ),
            cells=dict(
                values=[
                    df_filtrado5[c]
                    for c in colunas
                ],
                align="center"
            )
        ),
        row=1,
        col=1
    )
    # =====================================
    # BARRAS COM ESCALA DE CORES
    # =====================================
    fig5.add_trace(
    go.Bar(
    #x=df_media["Anual"],
    #x=df_media["Anual"].astype(int),
    x=df_media["Anual"].astype(str),
    y=df_media["Media_Anual"],
    text=df_media["Media_Anual"].round(2),
    texttemplate="%{text}",
    textposition="outside",
    marker=dict(
        color=df_media["Media_Anual"],
        colorscale=[
            [0.00, "black"],
            [0.22, "grey"],
            [0.44, "lightgrey"],
            [0.66, "blue"],
            [1.00, "lightblue"]
        ],
        showscale=True,
    ),
    name=""
),
    row=1,
    col=2
)
    # =====================================
    # SCATTER DA MÉDIA ANUAL
    # =====================================
    target = 90

    fig5.add_trace(
    go.Scatter(
        x=df_media["Anual"],
        y=[target] * len(df_media),
        mode="lines",
        name="",
        line=dict(
            color="red",
            width=3,
            dash="dash"
        )
    )
),


    # =====================================
    # LAYOUT
    # =====================================
    fig5.update_layout(
    yaxis=dict(
        range=[0, 100]
    )
)
    fig5.update_layout(
        title_text=f"Distribuição de Tickets por Avaliação .:{anual}",
        title_x=0.5,
        height=700
    )

    fig5.update_xaxes(
        tickangle=90,
        row=1,
        col=2
    )

    fig5.update_xaxes(
    type="category",
    categoryorder="array",
    categoryarray=df_media["Anual"].astype(str).tolist(),
    tickmode="array",
    tickvals=df_media["Anual"].astype(str).tolist(),
    ticktext=df_media["Anual"].astype(str).tolist(),
    row=1,
    col=2
)

    return fig5
# ==========================================
# APP
# ==========================================
#app = dash.Dash(__name__)
app = dash.Dash(__name__,suppress_callback_exceptions=True)
app.layout = html.Div([
    html.H2("Controle de Tickets",style={"textAlign": "center"}),
    html.Hr(style={'width':'100%'}),dcc.Tabs([
        # ==================================
        # GUIA PRINCIPAL COM FILTRO
        # ==================================
        dcc.Tab(label="Avaliação",children=[
            html.H3('Gestão Qualitafiva de Tickets',style={'textAlign':'Center'}),
            html.Hr(style={'width':'100%'}),
            dcc.Tabs([
                dcc.Tab(
    label="Evaluation",
    children=[

        html.Br(),

        html.Div(

            [

                html.Div(
                    [
                        html.Label(
                            "Selecione a Classificação do Evaluation:",
                            style={"fontWeight": "bold"}
                        ),

                        dcc.Dropdown(
                            id="filtro-grupo",
                            options=[
                                {"label": "Todos", "value": "Todos"}
                            ] + [
                                {"label": str(g), "value": str(g)}
                                for g in sorted(
                                    df["Evaluation"]
                                    .astype(str)
                                    .unique()
                                )
                            ],
                            value="Todos",
                            clearable=False
                        )
                    ],
                    style={"width": "300px"}
                ),

                html.Div(
                    [
                        html.Label(
                            "Selecione o Período Anual:",
                            style={"fontWeight": "bold"}
                        ),

                        dcc.Dropdown(
                            id="filtro-grupob",
                            options=[
                                {"label": "Todos", "value": "Todos"}
                            ] + [
                                {"label": str(g), "value": str(g)}
                                for g in sorted(
                                    df["Anual"]
                                    .astype(str)
                                    .unique()
                                )
                            ],
                            value="Todos",
                            clearable=False
                        )
                    ],
                    style={"width": "300px"}
                ),
            html.Div(
                                [
                                    html.Label(
                                        "Selecione o Período Mensal:",
                                        style={"fontWeight": "bold"}
                                    ),
            
                                    dcc.Dropdown(
                                        id="filtro-grupoc",
                                        options=[
                                            {"label": "Todos", "value": "Todos"}
                                        ] + [
                                            {"label": str(g), "value": str(g)}
                                            for g in sorted(
                                                df["Mensal"]
                                                .astype(str)
                                                .unique()
                                            )
                                        ],
                                        value="Todos",
                                        clearable=False
                                    )
                                ],
                                style={"width": "300px"}
                            ),
                            html.Div(
    [
        html.Label(
            "Selecione um Período:",
            style={"fontWeight": "bold"}
        ),

        dcc.DatePickerRange(
            id="filtro-periodod",
            display_format="DD/MM/YYYY",
            start_date_placeholder_text="Data inicial",
            end_date_placeholder_text="Data final"
        )
    ],
    style={"width": "350px"}
)

            ],

            style={
                "display": "flex",
                "gap": "20px",
                "alignItems": "end",
                "marginBottom": "20px"
            }

        ),

        html.Div(
            [
                html.Button(
                    "Exportar XLSX [SCORE]",
                    id="btn-exportar-tipo-liberacao",
                    #-------------------------------------------------------------------------
                    style={
                        "backgroundColor": "#27AE60",
                        "color": "white",
                        "border": "none",
                        "padding": "6px 12px",
                        "fontWeight": "bold",
                        "cursor": "pointer"
                    }
                ),

                dcc.Download(
                    id="download-tipo-liberacao-xlsx"
                )

            ],

            style={
                "display": "flex",
                "gap": "10px",
                "marginBottom": "15px"
            }

        ),

        dcc.Graph(
            id="grafico-grupo",
            figure=criar_figura("Todos", "Todos")
        )

    ]
),
                dcc.Tab(label='Monitoria - Consolidado', children=[

    html.Br(),

    html.Div(

        [

            html.Div(

                [

                    html.Label(
                        "Selecione a Classificação da Monitoria:",
                        style={"fontWeight": "bold"}
                    ),

                    dcc.Dropdown(
                        id="filtro-grupo2-avaliacao",
                        options=[
                            {"label": "Todos", "value": "Todos"}
                        ] + [
                            {"label": str(g), "value": str(g)}
                            for g in sorted(
                                df2["Avaliacao"].astype(str).unique()
                            )
                        ],
                        value="Todos",
                        clearable=False
                    )

                ],

                style={"width": "300px"}

            ),

            html.Div(

                [

                    html.Label(
                        "Selecione o Período Anual:",
                        style={"fontWeight": "bold"}
                    ),

                    dcc.Dropdown(
                        id="filtro-grupo2-anual",
                        options=[
                            {"label": "Todos", "value": "Todos"}
                        ] + [
                            {"label": str(g), "value": str(g)}
                            for g in sorted(
                                df2["Anual"].astype(str).unique()
                            )
                        ],
                        value="Todos",
                        clearable=False
                    )

                ],

                style={"width": "300px"}

            ),

            html.Div(

                [

                    html.Label(
                        "Selecione o Período Mensal:",
                        style={"fontWeight": "bold"}
                    ),

                    dcc.Dropdown(
                        id="filtro-grupo2-mensal",
                        options=[
                            {"label": "Todos", "value": "Todos"}
                        ] + [
                            {"label": str(g), "value": str(g)}
                            for g in sorted(
                                df2["Mensal"].astype(str).unique()
                            )
                        ],
                        value="Todos",
                        clearable=False
                    )

                ],

                style={"width": "300px"}

            ),
            html.Div(
                [
                    html.Label(
                        "Selecione um Período:",
                        style={"fontWeight": "bold"}
                    ),
            
                    dcc.DatePickerRange(
                        id="filtro-grupo2-date_picker",
                        display_format="DD/MM/YYYY",
                        start_date_placeholder_text="Data inicial",
                        end_date_placeholder_text="Data final"
                    )
                ],
                style={"width": "350px"}
            )

        ],

        style={
            "display": "flex",
            "gap": "20px",
            "alignItems": "end",
            "marginBottom": "20px"
        }

    ),

    html.Div(
        [
            html.Button(
                "Exportar XLSX [SCORE]",
                id="btn-exportar-tipo-liberacao2",
                #-------------------------------------------------------------------------
                style={
                    "backgroundColor": "#27AE60",
                    "color": "white",
                    "border": "none",
                    "padding": "6px 12px",
                    "fontWeight": "bold",
                    "cursor": "pointer"
                }
            ),
            dcc.Download(id="download-tipo-liberacao-xlsx2")
        ],
        style={
            "display": "flex",
            "gap": "10px",
            "marginBottom": "15px"
        }
    ),

    dcc.Graph(
        id="grafico-grupo2",
        figure=criar_figura2(
            "Todos",
            "Todos",
            "Todos"
        )
    ),

]),
                dcc.Tab(label='Monitoria - Mensal', children=[

    html.Br(),

    html.Div(

        [

            html.Div(

                [

                    html.Label(
                        "Selecione a Classificação:",
                        style={"fontWeight": "bold"}
                    ),

                    dcc.Dropdown(
                        id="filtro-grupo3-avaliacao",
                        options=[
                            {"label": "Todos", "value": "Todos"}
                        ] + [
                            {"label": str(g), "value": str(g)}
                            for g in sorted(
                                df3["Avaliacao"].astype(str).unique()
                            )
                        ],
                        value="Todos",
                        clearable=False
                    )

                ],

                style={"width": "300px"}

            ),

            html.Div(

                [

                    html.Label(
                        "Selecione o Período Anual:",
                        style={"fontWeight": "bold"}
                    ),

                    dcc.Dropdown(
                        id="filtro-grupo3-anual",
                        options=[
                            {"label": "Todos", "value": "Todos"}
                        ] + [
                            {"label": str(g), "value": str(g)}
                            for g in sorted(
                                df3["Anual"].astype(str).unique()
                            )
                        ],
                        value="Todos",
                        clearable=False
                    )

                ],

                style={"width": "300px"}

            ),

            html.Div(

                [

                    html.Label(
                        "Selecione o Período Mensal:",
                        style={"fontWeight": "bold"}
                    ),

                    dcc.Dropdown(
                        id="filtro-grupo3-mensal",
                        options=[
                            {"label": "Todos", "value": "Todos"}
                        ] + [
                            {"label": str(g), "value": str(g)}
                            for g in sorted(
                                df3["Mensal"].astype(str).unique()
                            )
                        ],
                        value="Todos",
                        clearable=False
                    )

                ],

                style={"width": "300px"}

            ),
            html.Div(
    [
        html.Label(
            "Selecione o Período:",
            style={"fontWeight": "bold"}
        ),

        dcc.Checklist(
            id="filtro-grupo3-anos",
            options=[
                {
                    "label": str(ano),
                    "value": str(ano)
                }
                for ano in sorted(
                    df3["Anual"].astype(str).unique()
                )
            ],
           #value=list(
           #     sorted(
           #         df3["Anual"].astype(str).unique()
           #     )
           # ),
           value=['2026'],
            inline=True
        )
    ],
    #style={"width": "400px"}
    style={
    "display": "flex",
    "gap": "20px",
    "alignItems": "end",   # ou "flex-end"
    "marginBottom": "1px"
}
)

        ],

        style={
            "display": "flex",
            "gap": "20px",
            "alignItems": "end",
            "marginBottom": "20px"
        }

    ),

    html.Div([
        html.Button(
            "Exportar XLSX [SCORE]",
            id="btn-exportar-tipo-liberacao3",
            #-----------------------------------------------------------
            style={
                "backgroundColor": "#27AE60",
                "color": "white",
                "border": "none",
                "padding": "6px 12px",
                "fontWeight": "bold",
                "cursor": "pointer"
            }
        ),
        dcc.Download(id="download-tipo-liberacao-xlsx3")
    ],
    style={
        "display": "flex",
        "gap": "10px",
        "marginBottom": "15px"
    }),

    dcc.Graph(
        id="grafico-grupo3",
        figure=criar_figura3(
            "Todos",
            "Todos",
            "Todos"
        )
    ),

]),
                dcc.Tab(label='Avaliação - Média Mensal', children=[

    html.Br(),

    html.Div(

        [

            html.Div(

                [

                    html.Label(
                        "Selecione o Evaluation:",
                        style={"fontWeight": "bold"}
                    ),

                    dcc.Dropdown(
                        id="filtro-grupo4-evaluation",
                        options=[
                            {"label": "Todos", "value": "Todos"}
                        ] + [
                            {"label": str(g), "value": str(g)}
                            for g in sorted(
                                df4["Evaluation"].astype(str).unique()
                            )
                        ],
                        value="Todos",
                        clearable=False
                    )

                ],

                style={"width": "300px"}

            ),

            html.Div(

                [

                    html.Label(
                        "Selecione o Período Anual:",
                        style={"fontWeight": "bold"}
                    ),

                    dcc.Dropdown(
                        id="filtro-grupo4-anual",
                        options=[
                            {"label": "Todos", "value": "Todos"}
                        ] + [
                            {"label": str(g), "value": str(g)}
                            for g in sorted(
                                df4["Anual"].astype(str).unique()
                            )
                        ],
                        value="Todos",
                        clearable=False
                    )

                ],

                style={"width": "300px"}

            ),

            html.Div(

                [

                    html.Label(
                        "Selecione o Período Mensal:",
                        style={"fontWeight": "bold"}
                    ),

                    dcc.Dropdown(
                        id="filtro-grupo4-mensal",
                        options=[
                            {"label": "Todos", "value": "Todos"}
                        ] + [
                            {"label": str(g), "value": str(g)}
                            for g in sorted(
                                df4["Mensal"].astype(str).unique()
                            )
                        ],
                        value="Todos",
                        clearable=False
                    )

                ],

                style={"width": "300px"}

            ),
            html.Div(
    [
        html.Label(
            "Selecione os Anos:",
            style={"fontWeight": "bold"}
        ),

        dcc.Checklist(
            id="filtro-grupo4-anos",
            options=[
                {
                    "label": str(ano),
                    "value": str(ano)
                }
                for ano in sorted(
                    df4["Anual"].astype(str).unique()
                )
            ],
            value=["2026"],
            inline=True
        )
    ],
    style={
        "display": "flex",
        "gap": "20px",
        "alignItems": "end",   # ou "flex-end"
        "marginBottom": "1px"
    }
    #style={
    #    "width": "450px"
    #}
)

        ],

        style={
            "display": "flex",
            "gap": "20px",
            "alignItems": "end",
            "marginBottom": "20px"
        }

    ),

    html.Div(

        [

            html.Button(
                "Exportar XLSX [SCORE]",
                id="btn-exportar-tipo-liberacao4",
                style={
                    "backgroundColor": "#27AE60",
                    "color": "white",
                    "border": "none",
                    "padding": "6px 12px",
                    "fontWeight": "bold",
                    "cursor": "pointer"
                }
            ),

            dcc.Download(
                id="download-tipo-liberacao-xlsx4"
            )

        ],

        style={
            "display": "flex",
            "gap": "10px",
            "marginBottom": "15px"
        }

    ),

    dcc.Graph(
        id="grafico-grupo4",
        figure=criar_figura4(
            "Todos",
            "Todos",
            "Todos"
        )
    ),

]),
                dcc.Tab(
    label='Avaliação - Média Anual',
    children=[

        html.Br(),

        html.Div(

            [

                html.Div(

                    [

                        html.Label(
                            "Selecione o Período Anual:",
                            style={"fontWeight": "bold"}
                        ),

                        dcc.Dropdown(
                            id="filtro-grupo5-anual",
                            options=[
                                {"label": "Todos", "value": "Todos"}
                            ] + [
                                {"label": str(g), "value": str(g)}
                                for g in sorted(
                                    df5["Anual"].astype(str).unique()
                                )
                            ],
                            value="Todos",
                            clearable=False
                        )

                    ],

                    style={"width": "300px"}

                ),

                html.Div(

                    [

                        html.Label(
                            "Selecione o Período Mensal:",
                            style={"fontWeight": "bold"}
                        ),

                        dcc.Dropdown(
                            id="filtro-grupo5-mensal",
                            options=[
                                {"label": "Todos", "value": "Todos"}
                            ] + [
                                {"label": str(g), "value": str(g)}
                                for g in sorted(
                                    df5["Mensal"].astype(str).unique()
                                )
                            ],
                            value="Todos",
                            clearable=False
                        )

                    ],

                    style={"width": "300px"}

                ),
                html.Div(
                                                        [
                                                            html.Label(
                                                                "Selecione um Período:",
                                                                style={"fontWeight": "bold"}
                                                            ),
                                                    
                                                            dcc.Checklist(
    id="filtro-grupo5-anos",
    options=[
        {
            "label": str(ano),
            "value": str(ano)
        }
        for ano in sorted(
            df5["Anual"].astype(str).unique()
        )
    ],
    value=["2026"],
    inline=True
)
                                                        ],
                                                        style={
                                                            'width':'850px',
                                                            "display": "flex",
                                                                "gap": "20px",
                                                                "alignItems": "end",   # ou "flex-end"
                                                                "marginBottom": "1px"}
                                                    )

            ],
            style={
                "display": "flex",
                "gap": "20px",
                "alignItems": "end",
                "marginBottom": "20px"
            }

        ),

        html.Div(

            [

                html.Button(
                    "Exportar XLSX [SCORE]",
                    id="btn-exportar-tipo-liberacao5",
                    style={
                        "backgroundColor": "#27AE60",
                        "color": "white",
                        "border": "none",
                        "padding": "6px 12px",
                        "fontWeight": "bold",
                        "cursor": "pointer"
                    }
                ),

                dcc.Download(
                    id="download-tipo-liberacao-xlsx5"
                )

            ],

            style={
                "display": "flex",
                "gap": "10px",
                "marginBottom": "15px"
            }

        ),

        dcc.Graph(
            id="grafico-grupo5",
            figure=criar_figura5(
                "Todos",
                "Todos"
            )
        )

    ]
)
            ])
            ]),
                    
        # ==================================
        # DEMAIS GUIAS
        # ==================================
        dcc.Tab(label="Tempo de Resposta",children=[
        #dcc.Tab(label="Status da Página",children=[
        html.H3('Gestão de Tempo',style={'textAlign':'Center'}),
                    html.Hr(style={'width':'100%'}),
        dcc.Tabs([
            dcc.Tab(label='Duração Mensal', children=[
            html.Br(),html.Div(

    [

        html.Div(
            [
                html.Label("Mensal"),
                dcc.Dropdown(
                    id="grupo1_filtro_grupo",
                    options=[
                        {"label": "Todos", "value": "Todos"}
                    ] + [
                        {"label": grupo, "value": grupo}
                        for grupo in sorted(
                            df_grupo1["Mensal"].unique()
                        )
                    ],
                    value="Todos",
                    clearable=False
                )
            ],
            style={"width": "300px"}
        ),

        html.Div(
            [
                html.Label("Duração Mensal - Média"),
                dcc.Dropdown(
                    id="grupo1_filtro_status",
                    value="Todos",
                    clearable=False
                )
            ],
            style={"width": "300px"}
        ),

        html.Div(
    [
        html.Label("Selecione os Anos"),
        dcc.Checklist(
            id="grupo1_anos",
            options=[
                {
                    "label": str(ano),
                    "value": str(ano)
                }
                for ano in sorted(
                    df_grupo1["Anual"].astype(str).unique()
                )
            ],
            value=["2026"],
            inline=True
        )
    ],
    style={
           'width':'850px',
           "display": "flex",
           "gap": "20px",
           "alignItems": "end",   # ou "flex-end"
           "marginBottom": "1px"}
)

    ],

    style={
        "display": "flex",
        "gap": "20px",
        "alignItems": "end",
        "marginBottom": "20px"
    }

),
                                html.Div([html.Button("Exportar XLSX [SCORE]",id="btn-exportar-grupo1",style={"backgroundColor": "#27AE60","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                                            #html.Button("Exportar PNG",id="btn-exportar-png-grupo1",style={"backgroundColor": "#3498DB","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                                            dcc.Download(id="download-grupo1-xlsx")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                                            #dcc.Download(id="download-png-grupo1")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                                        dcc.Graph(id="grupo1_grafico"),
                                            #config={"displaylogo": False,"modeBarButtonsToRemove": ["toImage"]}),
                                html.H3("Detalhamento",style={"marginTop": "20px","color": "#2C3E50"}),
                                html.Div(id="grupo1_tabela")
        ]),
                  dcc.Tab(label='Duração Anual', children=[
                      html.Br(),html.Div([html.Div([html.Label("Período Anual"),
                                              dcc.Dropdown(id="grupo1b_filtro_grupo",options=[{"label": "Todos","value": "Todos"}] + [{"label": grupo,"value": grupo}
                                                  for grupo in sorted(df_grupo1_2["Anual"].unique())],value="Todos",clearable=False)],style={"width": "45%"}),
                                                  #for grupo in sorted(df_grupo1["grupo_principal"].unique())],value="Todos",clearable=False)],style={"width": "45%"}),
                                                      html.Div([html.Label("Duração Anual - Média"),
                                                                dcc.Dropdown(id="grupo1b_filtro_status",value="Todos",clearable=False)],style={"width": "45%"}),
                                                                html.Div(
    [
        html.Label("Selecione um Período"),
        dcc.RangeSlider(
    id="grupo1b_anos_slider",
    min=int(df_grupo1_2["Anual"].min()),
    max=int(df_grupo1_2["Anual"].max()),
    value=[
        int(df_grupo1_2["Anual"].min()),
        int(df_grupo1_2["Anual"].max())
    ],
    marks={
        int(i): str(i)
        for i in sorted(df_grupo1_2["Anual"].unique())
        if int(i) % 5 == 0
    },
    step=1,
    allowCross=False
)
    ],
    style={"width": "350px"}
),],style={"display": "flex","justifyContent": "space-around","marginBottom": "20px"}),
                                                      html.Div([html.Button("Exportar XLSX [SCORE]",id="btn-exportar-grupo1b",style={"backgroundColor": "#27AE60","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                                                                  #html.Button("Exportar PNG",id="btn-exportar-png-grupo1",style={"backgroundColor": "#3498DB","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                                                                  dcc.Download(id="download-grupo1b-xlsx")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                                                                  #dcc.Download(id="download-png-grupo1")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                                                              dcc.Graph(id="grupo1b_grafico"),
                                                                  #config={"displaylogo": False,"modeBarButtonsToRemove": ["toImage"]}),
                                                      html.H3("Detalhamento",style={"marginTop": "20px","color": "#2C3E50"}),
                                                      html.Div(id="grupo1b_tabela")
                  ])])
                    ]),

        dcc.Tab(label="Consolidação Tickets",children=[html.Br(),
        html.H3('Volumetria',style={'textAlign':'Center'}),
        html.Hr(style={'width':'100%'}),
        dcc.Tabs([
            dcc.Tab(
    label="Mensal",
    children=[
        html.Br(),
        html.Div(

            [
                html.Div(
                    [
                        html.Label("Anual"),
                        dcc.Dropdown(
                            id="grupo2_filtro_grupo",
                            options=[
                                {"label": "Todos", "value": "Todos"}
                            ] + [
                                {"label": grupo, "value": grupo}
                                for grupo in sorted(df_grupo2["Anual"].unique())
                            ],
                            value="Todos",
                            clearable=False
                        )
                    ],
                    style={"width": "30%"}
                ),

                html.Div(
                    [
                        html.Label("Mensal"),
                        dcc.Dropdown(
                            id="grupo2_filtro_ilustracao",
                            value="Todos",
                            clearable=False
                        )
                    ],
                    style={"width": "30%"}
                ),

                html.Div(
    [
        html.Label(
            "Selecione os Anos:",
            style={"fontWeight": "bold"}
        ),
        dcc.Checklist(
            id="grupo2_anos",
            options=[
                {
                    "label": str(ano),
                    "value": str(ano)
                }
                for ano in sorted(
                    df_grupo2["Anual"].astype(str).unique()
                )
            ],
            value=["2026"],
            inline=True
        )
    ],
    #style={"width": "40%"}
    style={
                    'width':'850px',
                    "display": "flex",
                    "gap": "20px",
                    #"justifyContent": "space-around",
                    "alignItems": "end",
                    "marginBottom": "1px"
                }
),
            ],
            style={
                "display": "flex",
                "gap": "20px",
                #"justifyContent": "space-around",
                "alignItems": "end",
                "marginBottom": "20px"
            }
        ),

        html.Div(
            [
                html.Button(
                    "Exportar XLSX [SCORE]",
                    id="btn-exportar-grupo2",
                    style={
                        "backgroundColor": "#27AE60",
                        "color": "white",
                        "border": "none",
                        "padding": "6px 12px",
                        "fontWeight": "bold",
                        "cursor": "pointer"
                    }
                ),

                dcc.Download(id="download-grupo2-xlsx")
            ],
            style={
                "display": "flex",
                "gap": "15px",
                "marginBottom": "15px"
            }
        ),

        dcc.Graph(id="grupo2_grafico"),

        html.H3(
            "Detalhamento",
            style={
                "marginTop": "20px",
                "color": "#2C3E50"
            }
        ),

        html.Div(id="grupo2_tabela")
    ]
),
                 dcc.Tab(label='Anual', children=[
                     html.Div([html.Div([html.Label("Anual"),dcc.Dropdown(id="grupo2b_filtro_grupo",options=[{"label": "Todos","value": "Todos"}] + [{"label": grupo,"value": grupo}
                                             for grupo in sorted(df_grupo2b["Anual"].unique())],value="Todos",clearable=False)],style={"width": "45%"}),
                                             #for grupo in sorted(df_grupo2["grupo_principal"].unique())],value="Todos",clearable=False)],style={"width": "45%"}),
                                                 html.Div([
    html.Label("Selecione o Período.:"),
    dcc.RangeSlider(
        id="grupo2b_filtro_ilustracao",
        min=df_grupo2b["Anual"].min(),
        max=df_grupo2b["Anual"].max(),
        value=[
            df_grupo2b["Anual"].min(),
            df_grupo2b["Anual"].max()
        ],
        marks={
            int(v): str(int(v))
            for v in sorted(df_grupo2b["Anual"].unique())
                if int(v) % 5 == 0
        },
        tooltip={"placement": "bottom", "always_visible": True}
    )
], style={"width": "45%"})
                                                     ],style={"display": "flex","justifyContent": "space-around","marginBottom": "20px"}),
                                                 html.Div([html.Button("Exportar XLSX [SCORE]",id="btn-exportar-grupo2b",style={"backgroundColor": "#27AE60","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                                                             #html.Button("Exportar PNG",id="btn-exportar-png-grupo2",style={"backgroundColor": "#3498DB","color": "white","border": "none","padding": "6px 12px","fontWeight": "bold","cursor": "pointer"}),
                                                             dcc.Download(id="download-grupo2b-xlsx")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                                                             #dcc.Download(id="download-png-grupo2")],style={"display": "flex","gap": "15px","marginBottom": "15px"}),
                                                             dcc.Graph(id="grupo2b_grafico"),
                                                             #,config={"displaylogo": False,"modeBarButtonsToRemove": ["toImage"]}),
                                                     html.H3("Detalhamento",style={"marginTop": "20px","color": "#2C3E50"}),
                                                     html.Div(id="grupo2b_tabela")
                             
                 ])])    
            ]),              
       dcc.Tab(
    label="Categorização por Período",
    children=[
        html.Br(),
        html.H3('Extrato por Categoria',style={'textAlign':'Center'}),
                html.Hr(style={'width':'100%'}),
        dcc.Tabs(children=[
            dcc.Tab(label='Mensal',children=[
                html.Br(),
                html.Div([# Mensal
                        html.Div([html.Label("Mensal"),
                        dcc.Dropdown(id="grupo3_filtro_grupo",options=[{"label": "Todos", "value": "Todos"}] + [
                                    {"label": grupo, "value": grupo} for grupo in sorted(df_grupo3["Mensal"].unique())],
                                    value=["Todos"], multi=True,clearable=False),],style={"width": "30%"}),                
                                # Categorias Equivalentes
                                html.Div([
                                html.Label("Categorias Equivalentes"), dcc.Dropdown(id="grupo3_filtro_devolutiva",
                                value="Todos",multi=True,clearable=False),],style={"width": "30%"}),                
                                # Anual (Checklist)
                                html.Div([
                                html.Label("Anual"),dcc.Checklist(id="grupo3_filtro_anual",options=[{"label": str(ano),
                                "value": ano} for ano in sorted(df_grupo3["Anual"].unique())],
                                value=[2026],inline=True,style={"marginTop": "8px"}),],style={"width": "40%"}
                                ),
                
                            ],style={
                                "display": "flex",
                                "justifyContent": "space-between",
                                "gap": "20px",
                                "marginBottom": "20px",
                                "alignItems": "flex-start"
                            }),
                        #RADIOS
                        html.Hr(style={'textAlign':'Center', 'width':'80%'}),
                        html.Div([
    html.Div(
    [
        html.H2(
            'Deseja exibir um quadro comparativo?',
            style={'marginRight': '20px', 'marginBottom': '1'}
        ),
        dcc.RadioItems(
            ['Sim'],
            '',
            id='escolha',
            inline=True
        ),
        #dcc.RadioItems(
        #            ['Não'],
        #            '',
        #            id='escolhab',
        #            inline=True
        #        ),
    ],
    style={
        'display': 'flex',
        'alignItems': 'center',
        'justifyContent': 'center', 'marginBottom': '1'
    }
),
html.Br(),

html.Div(
    [
        html.Div(
            [
                html.Button(
                    "Exportar XLSX [SCORE]",
                    id="btn-exportar-grupo3",
                    style={
                        "backgroundColor": "#27AE60",
                        "color": "white",
                        "border": "none",
                        "padding": "6px 12px",
                        "fontWeight": "bold",
                        "cursor": "pointer",
                    },
                ),

                dcc.Download(id="download-grupo3-xlsx"),

                html.Button(
                    "Desabilitar 2 FRAMES.",
                    id="btn-limpa-sim",
                    style={
                        "backgroundColor": "#000000",
                        "color": "white",
                        "border": "none",
                        "padding": "6px 12px",
                        "fontWeight": "bold",
                        "cursor": "pointer",
                    },
                ),
            ],
            style={
                "display": "flex",
                "justifyContent": "center",
                "alignItems": "center",
                "gap": "15px",
                "marginBottom": "30px",
            },
        )
    ]
),
    html.Hr(style={'textAlign':'Center', 'width':'80%'}),
    html.Div(id='saida'),
#---------------- DIV_OCULTO
html.Div(
    id="saidac",
    children=[
        html.Div(
            id="comparativo-container",
            style={"display": "none"},
            children=[
                dcc.Dropdown(id="grupo3c_filtro_grupo"),
                dcc.Dropdown(id="grupo3c_filtro_devolutiva"),
                dcc.Checklist(id="grupo3c_filtro_anual")
            ]
        )
    ]
),        
#---------------- DIV_OCULTO
]),
html.Br(),
                
                        #html.Div([
                        #html.Button("Exportar XLSX [SCORE]",id="btn-exportar-grupo3",style={
                        #                "backgroundColor": "#27AE60",
                        #                "color": "white",
                        #                "border": "none",
                        #                "padding": "6px 12px",
                        #                "fontWeight": "bold",
                        #                "cursor": "pointer"}),
                
                        #dcc.Download(id="download-grupo3-xlsx")],
                        #    style={
                        #        "display": "flex",
                        #        "gap": "15px",
                        #        "marginBottom": "15px"}
                        #),                
                        dcc.Graph(id="grupo3_grafico"),
                        html.H3("Detalhamento", style={
                                "marginTop": "20px",
                                "color": "#2C3E50"}),                
                        html.Div(id="grupo3_tabela"),
            ]),
            dcc.Tab(label='Anual',children=[
                #-------------------------------------ANUAL
                html.Div([
                                        html.Div([
                                            html.Label("Anual"),
                                        dcc.Dropdown(id="grupo3b_filtro_grupo",options=[{"label": "Todos", "value": "Todos"}] + [
                                                    {"label": grupo, "value": grupo} for grupo in sorted(df_grupo3b["Anual"].unique())],
                                                    value="Todos",clearable=False),],style={"width": "30%"}),                
                                                # Categorias Equivalentes
                                                html.Div([
                                                html.Label("Categorias Equivalentes"), dcc.Dropdown(id="grupo3b_filtro_devolutiva",
                                                value="Todos",clearable=False),],style={"width": "30%"}),                
                                                # Anual (Checklist)
                                                html.Div([
                                                html.Label("Anual"),dcc.Checklist(id="grupo3b_filtro_anual",options=[{"label": str(ano),
                                                "value": ano} for ano in sorted(df_grupo3b["Anual"].unique())],
                                                value=[2026],inline=True,style={"marginTop": "8px"}),],style={"width": "40%"}
                                                ),
                                
                                            ],style={
                                                "display": "flex",
                                                "justifyContent": "space-between",
                                                "gap": "20px",
                                                "marginBottom": "20px",
                                                "alignItems": "flex-start"
                                            }),
                                
                                        html.Div([
                                        html.Button("Exportar XLSX [SCORE]",id="btn-exportar-grupo3b",style={
                                                        "backgroundColor": "#27AE60",
                                                        "color": "white",
                                                        "border": "none",
                                                        "padding": "6px 12px",
                                                        "fontWeight": "bold",
                                                        "cursor": "pointer"}),
                                
                                        dcc.Download(id="download-grupo3b-xlsx")],
                                            style={
                                                "display": "flex",
                                                "gap": "15px",
                                                "marginBottom": "15px"}
                                        ),                
                                        dcc.Graph(id="grupo3b_grafico"),
                                        html.H3("Detalhamento", style={
                                                "marginTop": "20px",
                                                "color": "#2C3E50"}),                
                                        html.Div(id="grupo3b_tabela"),
                #-------------------------------------ANUAL
            ])
        ]),
    ]
),      
        dcc.Tab(
    label="Memória de Cálculo",
    children=[

        html.Br(),
        html.H3('Overview - Customização da Tabela.:', style={'textAlign':'center'}),
        html.Hr(style={'width':'100%'}),
        html.Div(
    [
        dcc.Checklist(
            id="check-colunas",
            options=[
                {"label": col, "value": col}
                for col in df_grupo5.columns
            ],
            value=[
                "id",
                "Ticket_ID",
                "Archive_date",
                "Evaluation",
                "Editor_category",
                "Net_Time"
            ],
            inline=True
        ),
    ],
    style={
        "border": "1px solid #ccc",
        "borderRadius": "8px",
        "padding": "10px",
        "marginBottom": "10px",
        "backgroundColor": "#f8f9fa"
    }
),
#--------------------------
html.Div(
    [
        html.Label(
            "Buscar Ticket ID:",
            style={"fontWeight": "bold"}
        ),
        dcc.Input(
            id="busca-ticket-id",
            type="text",
            placeholder="Digite o Ticket ID...",
            debounce=True,
            style={"width": "250px", "marginRight": "20px"}
        ),

        html.Label(
            "Buscar Archive Date:",
            style={"fontWeight": "bold"}
        ),
        dcc.Input(
            id="busca-archive-date",
            type="text",
            placeholder="Digite a data...",
            debounce=True,
            style={"width": "250px"}
        ),
        html.Button(
                            "Exportar DOCX [METODOLOGIAS]",
                            id="btn-exportar-memoria",
                            #-------------------------------------------------------------------------
                            style={
                                "backgroundColor": "#2514DA",
                                "color": "white",
                                "border": "none",
                                "padding": "6px 12px",
                                "fontWeight": "bold",
                                "cursor": "pointer"
                            }
                        ),
        
                        dcc.Download(
                            id="download-memoria-docx"
                        )
    ],
    style={
        "display": "flex",
        "alignItems": "center",
        "gap": "20px",
        "marginBottom": "15px"
    }
),
#--------------------------
html.Hr(style={"width": "100%"}),
        html.Div(
            id="container-tabela-memoria"
        )

    ]
)])])

# ==========================================
# CALLBACK
# ==========================================
@app.callback(
    Output("grafico-grupo", "figure"),
    Input("filtro-grupo", "value"),            # evaluation
    Input("filtro-grupob", "value"),           # anual
    Input("filtro-grupoc", "value"),           # mensal
    Input("filtro-periodod", "start_date"),     # data inicial
    Input("filtro-periodod", "end_date")        # data final
)
def atualizar_grafico(
    evaluation,
    anual,
    mensal,
    start_date,
    end_date
):

    return criar_figura(
        evaluation,
        anual,
        mensal,
        start_date,
        end_date
    )

@app.callback(
    Output("grafico-grupo2", "figure"),
    Input("filtro-grupo2-avaliacao", "value"),
    Input("filtro-grupo2-anual", "value"),
    Input("filtro-grupo2-mensal", "value"),
    Input("filtro-grupo2-date_picker", "start_date"),     # data inicial
    Input("filtro-grupo2-date_picker", "end_date")        # data final
)
def atualizar_grafico2(avaliacao, anual, mensal, start_date,end_date):

    return criar_figura2(
        avaliacao,
        anual,
        mensal,
        start_date,
        end_date
    )

@app.callback(
    Output("grafico-grupo3", "figure"),
    Input("filtro-grupo3-avaliacao", "value"),
    Input("filtro-grupo3-anual", "value"),
    Input("filtro-grupo3-mensal", "value"),
    Input("filtro-grupo3-anos", "value")
)
def atualizar_grafico3(
    avaliacao,
    anual,
    mensal,
    anos_selecionados
):

    return criar_figura3(
        avaliacao,
        anual,
        mensal,
        anos_selecionados
    )

@app.callback(
    Output("grafico-grupo4", "figure"),
    Input("filtro-grupo4-evaluation", "value"),
    Input("filtro-grupo4-anual", "value"),
    Input("filtro-grupo4-mensal", "value"),
    Input("filtro-grupo4-anos", "value")
)
def atualizar_grafico4(
    evaluation,
    anual,
    mensal,
    anos_selecionados
):

    return criar_figura4(
    evaluation,
    anual,
    mensal,
    anos_selecionados
)

@app.callback(
    Output("grafico-grupo5", "figure"),
    Input("filtro-grupo5-anual", "value"),
    Input("filtro-grupo5-mensal", "value"),
    Input("filtro-grupo5-anos", "value")
)
def atualizar_grafico5(
    anual,
    mensal,
    anos_selecionados
):
    return criar_figura5(
        anual,
        mensal,
        anos_selecionados
    )
@app.callback(
    Output("grupo1_filtro_status", "options"),
    Output("grupo1_filtro_status", "value"),
    Input("grupo1_filtro_grupo", "value")
)
def atualizar_status_grupo1(grupo):

    if grupo == "Todos":

        status_disponiveis = sorted(
            df_grupo1["Duracao_Mensal_Media"].unique()
        )

    else:

        status_disponiveis = sorted(
            df_grupo1.loc[
                df_grupo1["Mensal"] == grupo,
                #df_grupo1["grupo_principal"] == grupo,
                "Duracao_Mensal_Media"
            ].unique()
        )

    options = [
        {
            "label": "Todos",
            "value": "Todos"
        }
    ] + [
        {
            "label": status,
            "value": status
        }
        for status in status_disponiveis
    ]

    return options, "Todos"

@app.callback(
    Output("grupo1_grafico", "figure"),
    Output("grupo1_tabela", "children"),
    Input("grupo1_filtro_grupo", "value"),
    Input("grupo1_filtro_status", "value"),
    Input("grupo1_anos", "value")
)
def atualizar_visualizacao_grupo1(
    grupo,
    status,
    anos_selecionados
):
    dados = df_grupo1.copy()

    dados["Anual"] = (
    dados["Data_Mensal"].dt.year.astype(str)
)

    if anos_selecionados:
        dados = dados[
            dados["Anual"].isin(
                [str(x) for x in anos_selecionados]
            )
        ]

    if grupo != "Todos":
        dados = dados[
            dados["Mensal"] == grupo
            #dados["grupo_principal"] == grupo
        ]

    if status != "Todos":
        dados = dados[
            dados["Duracao_Mensal_Media"] == status
        ]

    dados_agrupados = (
        dados
        .groupby(
            ["Mensal", "Duracao_Mensal_Media"],
            #["grupo_principal", "status_da_pagina_de_texto"],
            as_index=False
        )["Mensal"]
        .sum()
    )

    dados["Duracao_Texto"] = dados["Duracao_Mensal_Media"]

    dados["Duracao_Horas"] = (
        pd.to_timedelta(dados["Duracao_Mensal_Media"])
        .dt.total_seconds() / 3600
    )

    if dados_agrupados.empty:
        return go.Figure(), html.Div("Nenhum dado encontrado.")

    meses = {
    'janeiro': '01',
    'fevereiro': '02',
    'março': '03',
    'abril': '04',
    'maio': '05',
    'junho': '06',
    'julho': '07',
    'agosto': '08',
    'setembro': '09',
    'outubro': '10',
    'novembro': '11',
    'dezembro': '12'
}

    dados["Data_Ordem"] = pd.to_datetime(
        dados["Mensal"].apply(
            lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
        )
    )

    dados = dados.sort_values("Data_Ordem")

    fig = px.bar(
    dados,
    x="Mensal",
    y="Duracao_Horas",
    color="Duracao_Horas",
    text="Duracao_Texto", 
    color_continuous_scale=['black','grey','lightgrey','blue','lightblue',]
    )

    fig.update_traces(
    width=0.8,
    textposition="inside",
    textfont_color="white"
)

    max_horas = max(
    6,
    int(dados["Duracao_Horas"].max()) + 1
)

    fig.update_coloraxes(
        cmin=0,
        cmax=max_horas,

        colorbar=dict(
            title="Tempo",

            tickmode="array",

            tickvals=list(range(0, max_horas + 1)),

            ticktext=[
                f"{h:02d}:00"
                for h in range(0, max_horas + 1)
            ],

            len=0.90
        )
    )


    fig.update_traces(
        width=0.8,
        textposition="inside",
        textfont_color="white"
    )

    fig.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",
        legend_title="Status",
    )

    ticks_horas = [0, 1, 2, 3, 4, 5, 6]
    fig.update_yaxes(
    title_text="Tempo Médio",
    range=[0, 6],
    tickvals=ticks_horas,
    ticktext=[
    "00:00",
    "01:00",
    "02:00",
    "03:00",
    "04:00",
    "05:00",
    "06:00"
    ],
    showgrid=True,
    gridcolor="#E5E5E5"
    )
    fig.add_hline(
    y=3,
    line_dash="dash",
    line_color="red",
    line_width=3,
    annotation_text="Target 03:00:00",
    annotation_position="top right"
    )

    tabela = html.Table(

    [

        html.Thead(

            html.Tr(

                [

                    html.Th(
                        coluna,
                        style={
                            "backgroundColor": "#2C3E50",
                            "color": "white",
                            "border": "1px solid black",
                            "padding": "8px",
                            "textAlign": "center",
                            "fontWeight": "bold"
                        }
                    )

                    for coluna in dados_agrupados.columns

                ]

            )

        ),

        html.Tbody(

            [

                html.Tr(

                    [

                        html.Td(
                            dados_agrupados.iloc[i][coluna],
                            style={
                                "border": "1px solid #D3D3D3",
                                "padding": "8px",
                                "textAlign": "center"
                            }
                        )

                        for coluna in dados_agrupados.columns

                    ],

                    style={
                        "backgroundColor":
                            "#F2F2F2"
                            if i % 2 == 0
                            else "white"
                    }

                )

                for i in range(
                    len(dados_agrupados)
                )

            ]

        )

    ],

    style={
        "width": "100%",
        "borderCollapse": "collapse",
        "fontFamily": "Arial",
        "marginTop": "10px"
    }

)


    ticks_horas = [0, 1, 2, 3, 4, 5, 6]

    ticks_texto = [
        "00:00",
        "01:00",
        "02:00",
        "03:00",
        "04:00",
        "05:00",
        "06:00"
    ]
    return fig, tabela

# tempo de resposta anual
# -------------------------------

from plotly.subplots import make_subplots
import plotly.graph_objects as go

@app.callback(
    Output("grupo1b_filtro_status", "options"),
    Output("grupo1b_filtro_status", "value"),
    Input("grupo1b_filtro_grupo", "value")
)
def atualizar_status_grupo1b(grupo):

    if grupo == "Todos":

        status_disponiveis = sorted(
            df_grupo1_2["Duracao_Anual_Media"]
            .dropna()
            .unique()
        )

    else:

        status_disponiveis = sorted(
            df_grupo1_2.loc[
                df_grupo1_2["Anual"] == grupo,
                "Duracao_Anual_Media"
            ]
            .dropna()
            .unique()
        )

    options = [
        {
            "label": "Todos",
            "value": "Todos"
        }
    ] + [
        {
            "label": str(status),
            "value": status
        }
        for status in status_disponiveis
    ]

    return options, "Todos"


@app.callback(
    Output("grupo1b_grafico", "figure"),
    Output("grupo1b_tabela", "children"),
    Input("grupo1b_filtro_grupo", "value"),
    Input("grupo1b_filtro_status", "value"),
    Input("grupo1b_anos_slider", "value")
)
def atualizar_visualizacao_grupo1b(
    grupo,
    status,
    anos
):

    dados = df_grupo1_2.copy()

    dados["Anual"] = pd.to_numeric(
    dados["Anual"],
    errors="coerce"
)

    ano_inicial, ano_final = anos

    dados = dados[
        (dados["Anual"] >= ano_inicial) &
        (dados["Anual"] <= ano_final)
    ]

    if grupo != "Todos":

        dados = dados[
            dados["Anual"] == grupo
        ]

    if status != "Todos":

        dados = dados[
            dados["Duracao_Anual_Media"] == status
        ]

    dados_agrupados = (
        dados[
            [
                "Duracao_Anual_Media",
                "Anual"
            ]
        ]
        .drop_duplicates()
    )

    if dados_agrupados.empty:
        return go.Figure(), html.Div("Nenhum dado encontrado.")

    dados = dados.dropna(
        subset=[
            "Duracao_Mensal_Media",
            "Duracao_Anual_Media"
        ]
    ).copy()

    # Texto original para exibição
    dados["Duracao_Texto"] = dados["Duracao_Mensal_Media"]

    # Conversão mensal para horas
    dados["Duracao_Horas"] = (
        pd.to_timedelta(
            dados["Duracao_Mensal_Media"]
        )
        .dt.total_seconds() / 3600
    )

    # Conversão anual para horas
    dados["Duracao_Anual_Horas"] = (
        pd.to_timedelta(
            dados["Duracao_Anual_Media"]
        )
        .dt.total_seconds() / 3600
    )

    meses = {
        "janeiro": "01",
        "fevereiro": "02",
        "março": "03",
        "abril": "04",
        "maio": "05",
        "junho": "06",
        "julho": "07",
        "agosto": "08",
        "setembro": "09",
        "outubro": "10",
        "novembro": "11",
        "dezembro": "12"
    }

    if "Mensal" in dados.columns:

        dados["Data_Ordem"] = pd.to_datetime(
            dados["Mensal"].apply(
                lambda x:
                f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
            )
        )

        dados = dados.sort_values("Data_Ordem")

    # ==================================================
    # GRÁFICO
    # ==================================================

    fig = make_subplots(
        specs=[[{"secondary_y": True}]]
    )

    # Barras em segundo plano
    fig.add_trace(
        go.Bar(
            x=dados["Anual"],
            y=dados["Duracao_Horas"],
            name="Tempo Mensal Médio",
            marker_color="#5B9BD5",
            opacity=0.45,
            text=dados["Duracao_Texto"],
            textposition="inside"
        ),
        secondary_y=False
    )

    # Dispersão em primeiro plano
    fig.add_trace(
        go.Scatter(
            x=dados["Anual"],
            y=dados["Duracao_Anual_Horas"],
            mode="markers+lines+text",
            name="Tempo Anual Médio",

            marker=dict(
                size=12,
                color="#E74C3C",
                line=dict(
                    color="white",
                    width=2
                )
            ),

            line=dict(
                color="#E74C3C",
                width=3
            ),

            text=dados["Duracao_Anual_Media"],
            textposition="top center"
        ),
        secondary_y=True
    )

    target_horas = 3

    fig.add_hline(
        y=target_horas,
        line_dash="dash",
        line_color="red",
        line_width=3,
        annotation_text="Target 03:00:00",
        annotation_position="top right"
    )

    fig.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",

        bargap=0.30,

        legend=dict(
            orientation="h",
            y=1.10,
            x=0.5,
            xanchor="center"
        ),

        margin=dict(
            t=80,
            l=50,
            r=50,
            b=50
        )
    )

    fig.update_xaxes(
        title_text="Ano",
        showgrid=False
    )

    fig.update_yaxes(
        title_text="Tempo Mensal Médio (Horas)",
        secondary_y=False,
        showgrid=True,
        gridcolor="#E5E5E5"
    )

    fig.update_yaxes(
        title_text="Tempo Anual Médio (Horas)",
        secondary_y=True,
        showgrid=False
    )

    ticks_horas = [0, 1, 2, 3, 4, 5, 6]

    ## EIXO Y PRIMÁRIO (barras)
    fig.update_yaxes(
    title_text="Tempo Mensal Médio",
    range=[0, 6],
    tickvals=[0,1,2,3,4,5,6],
    ticktext=[
        "00:00",
        "01:00",
        "02:00",
        "03:00",
        "04:00",
        "05:00",
        "06:00"
    ],
    secondary_y=False
)

    # EIXO Y SECUNDÁRIO (scatter)
    fig.update_yaxes(
    title_text="Tempo Anual Médio",
    range=[0, 6],
    tickvals=[0,1,2,3,4,5,6],
    ticktext=[
        "00:00",
        "01:00",
        "02:00",
        "03:00",
        "04:00",
        "05:00",
        "06:00"
    ],
    secondary_y=True
)



    # ==================================================
    # TABELA
    # ==================================================

    tabela = html.Table(
        [
            html.Thead(
                html.Tr(
                    [
                        html.Th(
                            coluna,
                            style={
                                "backgroundColor": "#2C3E50",
                                "color": "white",
                                "border": "1px solid black",
                                "padding": "8px",
                                "textAlign": "center",
                                "fontWeight": "bold"
                            }
                        )
                        for coluna in dados_agrupados.columns
                    ]
                )
            ),

            html.Tbody(
                [
                    html.Tr(
                        [
                            html.Td(
                                dados_agrupados.iloc[i][coluna],
                                style={
                                    "border": "1px solid #D3D3D3",
                                    "padding": "8px",
                                    "textAlign": "center"
                                }
                            )
                            for coluna in dados_agrupados.columns
                        ],
                        style={
                            "backgroundColor":
                            "#F2F2F2"
                            if i % 2 == 0
                            else "white"
                        }
                    )
                    for i in range(
                        len(dados_agrupados)
                    )
                ]
            )
        ],

        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "fontFamily": "Arial",
            "marginTop": "10px"
        }
    )

    return fig, tabela


# -------------------------------
# -------------------------------
@app.callback(
    Output("grupo2_filtro_ilustracao","options"),
    Output("grupo2_filtro_ilustracao","value"),
    Input("grupo2_filtro_grupo","value"))

def atualizar_ilustracao_grupo2(grupo):
    if grupo == "Todos":
        ilustracoes = sorted(df_grupo2["Mensal"].unique())
    else:
        ilustracoes = sorted(df_grupo2.loc[df_grupo2["Anual"] == grupo,"Mensal"].unique())
    options = [{"label": "Todos","value": "Todos"}] + [{"label": item,"value": item} for item in ilustracoes]
    return options, "Todos"

@app.callback(
    Output("grupo2_grafico","figure"),
    Output("grupo2_tabela","children"),
    Input("grupo2_filtro_grupo","value"),
    Input("grupo2_filtro_ilustracao","value"),
    Input("grupo2_anos","value")
)

def atualizar_visualizacao_grupo2(
    grupo,
    ilustracao,
    anos_selecionados
):

    dados = df_grupo2.copy()

    dados["Mensal_tickets"] = pd.to_numeric(
        dados["Mensal_tickets"],
        errors="coerce"
    )

    meses = {
        "janeiro": "01",
        "fevereiro": "02",
        "março": "03",
        "abril": "04",
        "maio": "05",
        "junho": "06",
        "julho": "07",
        "agosto": "08",
        "setembro": "09",
        "outubro": "10",
        "novembro": "11",
        "dezembro": "12"
    }

    dados["Data_Mensal"] = pd.to_datetime(
        dados["Mensal"].apply(
            lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
        )
    )

    dados["Anual"] = dados["Anual"].astype(str)

    if anos_selecionados:
        dados = dados[
            dados["Anual"].isin(
                [str(x) for x in anos_selecionados]
            )
        ]

    if grupo != "Todos":
        dados = dados[dados["Anual"] == grupo]

    if ilustracao != "Todos":
        dados = dados[dados["Mensal"] == ilustracao]

    dados_agrupados = (
        dados.groupby(
            ["Mensal"],
            as_index=False
        )["Mensal_tickets"]
        .first()
    )

    dados_agrupados = dados_agrupados.merge(
        dados[["Mensal", "Data_Mensal"]].drop_duplicates(),
        on="Mensal",
        how="left"
    )

    dados_agrupados = dados_agrupados.sort_values(
        "Data_Mensal"
    )

    dados_agrupados = dados_agrupados.drop(
        columns=["Data_Mensal"]
    )

    fig = px.bar(
        dados_agrupados,
        x="Mensal",
        y="Mensal_tickets",
        text="Mensal_tickets",
        barmode="group"
    )

    fig.update_traces(
        textposition="inside",
        textfont_color="white"
    )

    fig.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",
        legend_title="Categoria"
    )

    tabela = html.Table(
        [
            html.Thead(
                html.Tr(
                    [
                        html.Th(
                            coluna,
                            style={
                                "backgroundColor": "#2C3E50",
                                "color": "white",
                                "border": "1px solid black",
                                "padding": "8px",
                                "textAlign": "center",
                                "fontWeight": "bold"
                            }
                        )
                        for coluna in dados_agrupados.columns
                    ]
                )
            ),
            html.Tbody(
                [
                    html.Tr(
                        [
                            html.Td(
                                dados_agrupados.iloc[i][coluna],
                                style={
                                    "border": "1px solid #D3D3D3",
                                    "padding": "8px",
                                    "textAlign": "center"
                                }
                            )
                            for coluna in dados_agrupados.columns
                        ],
                        style={
                            "backgroundColor": "#F2F2F2"
                            if i % 2 == 0 else "white"
                        }
                    )
                    for i in range(len(dados_agrupados))
                ]
            )
        ],
        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "fontFamily": "Arial",
            "marginTop": "10px"
        }
    )

    return fig, tabela
# -------------------------------

@app.callback(
    Output("grupo2b_grafico", "figure"),
    Output("grupo2b_tabela", "children"),
    Input("grupo2b_filtro_grupo", "value"),
    Input("grupo2b_filtro_ilustracao", "value")
)

def atualizar_visualizacao_grupo2b(grupo, anos):

    dados = df_grupo2b.copy()

    # =========================
    # Tratamento de dados
    # =========================

    dados["Anual"] = pd.to_numeric(
        dados["Anual"],
        errors="coerce"
    )

    dados["anual_tickets"] = pd.to_numeric(
        dados["anual_tickets"],
        errors="coerce"
    )

    dados["Volume_Medio"] = pd.to_numeric(
        dados["Volume_Medio"],
        errors="coerce"
    )

    # =========================
    # Filtro do grupo
    # =========================

    if grupo != "Todos":
        dados = dados[
            dados["Anual"] == int(grupo)
        ]

    # =========================
    # Filtro do período
    # =========================

    ano_inicial, ano_final = map(int, anos)

    dados = dados[
        (dados["Anual"] >= ano_inicial) &
        (dados["Anual"] <= ano_final)
    ]

    # =========================
    # Agrupamento
    # =========================

    dados_agrupados = (
        dados.groupby(
            "Anual",
            as_index=False
        )
        .agg(
            {
                "anual_tickets": "first",
                "n_periodo_anual": "first",
                "Volume_Medio": "first"
            }
        )
    )

    dados_agrupados = dados_agrupados.sort_values(
        "Anual"
    )

    dados_agrupados["Anual"] = (
        dados_agrupados["Anual"]
        .astype(int)
        .astype(str)
    )

    # Normaliza o Volume_Medio para a escala das barras

    max_tickets = dados_agrupados["anual_tickets"].max()
    max_volume = dados_agrupados["Volume_Medio"].max()

    dados_agrupados["Volume_Medio_Escala"] = (
        dados_agrupados["Volume_Medio"] / max_volume
    ) * max_tickets

    # =========================
    # Gráfico
    # =========================
    fig = make_subplots(
        specs=[[{"secondary_y": True}]]
    )

    # BARRAS
    fig.add_trace(
        go.Bar(
            x=dados_agrupados["Anual"],
            y=dados_agrupados["anual_tickets"],
            text=dados_agrupados["anual_tickets"],
            textposition="inside",
            insidetextanchor="middle",
            name="Tickets",
            marker_color="#1F77B4"
        ),
        secondary_y=False
    )

    # LINHA + DISPERSÃO
    fig.add_trace(
        go.Scatter(
            x=dados_agrupados["Anual"],
            y=dados_agrupados["Volume_Medio"],
            mode="lines+markers+text",
            name="Volume Médio",
            line=dict(
                color="red",
                width=3
            ),
            marker=dict(
                size=12,
                color="red",
                symbol="circle"
            ),
            text=dados_agrupados["Volume_Medio"].round(2),
            textposition="top center",
            textfont=dict(
                size=11,
                color="black"
            )
        ),
        secondary_y=True
    )

    fig.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",
        legend_title="Indicadores",
        barmode="group"
    )

    fig.update_xaxes(
        type="category",
        categoryorder="array",
        categoryarray=dados_agrupados["Anual"].tolist()
    )

    fig.update_yaxes(
        title_text="Tickets - Volume Anual",
        secondary_y=False
    )

    fig.update_yaxes(
        title_text="Volume Médio",
        secondary_y=True
    )


    # =========================
    # Tabela
    # =========================

    colunas_exibidas = [
        "Anual",
        "anual_tickets",
        "n_periodo_anual",
        "Volume_Medio"
    ]

    tabela = html.Table(
        [
            html.Thead(
                html.Tr(
                    [
                        html.Th(
                            coluna,
                            style={
                                "backgroundColor": "#2C3E50",
                                "color": "white",
                                "border": "1px solid black",
                                "padding": "8px",
                                "textAlign": "center",
                                "fontWeight": "bold"
                            }
                        )
                        for coluna in colunas_exibidas
                    ]
                )
            ),
            html.Tbody(
                [
                    html.Tr(
                        [
                            html.Td(
                                dados_agrupados.iloc[i][coluna],
                                style={
                                    "border": "1px solid #D3D3D3",
                                    "padding": "8px",
                                    "textAlign": "center"
                                }
                            )
                            for coluna in colunas_exibidas
                        ],
                        style={
                            "backgroundColor":
                            "#F2F2F2" if i % 2 == 0 else "white"
                        }
                    )
                    for i in range(len(dados_agrupados))
                ]
            )
        ],
        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "fontFamily": "Arial",
            "marginTop": "10px"
        }
    )

    return fig, tabela

#****************************************************************************************
#26/10/2026 - parte 2
#--------------------
@app.callback(
    Output('saida', 'children'),
    Input('escolha', 'value')
)
def atualizar_comparativo(valor):
    dados = df_grupo3.copy()
    
    devolutivas = sorted(
            dados["Equivalencia_Categoria"]
            .dropna()
            .unique()
        )
    
    if valor == 'Sim':
        return [
            html.H4('Plot com 2(dois) Frames, Habilitado, com sucesso!!!',style={'textAlign':'center'}),
            html.Br(),
                            html.Div([# Mensal
                                    html.Div([html.Label("Mensal"),
                                    dcc.Dropdown(id="grupo3c_filtro_grupo",options=[{"label": "Todos", "value": "Todos"}] + [
                                                {"label": grupo, "value": grupo} for grupo in sorted(df_grupo3["Mensal"].unique())],
                                                value=["Todos"], multi=True,clearable=False),],style={"width": "30%"}),                
                                            # Categorias Equivalentes
                                            #html.Div([
                                            #html.Label("Categorias Equivalentes"), dcc.Dropdown(id="grupo3_filtro_devolutivab",
                                            #value="Todos",clearable=False),],style={"width": "30%"}),                
                                            html.Div([
                                                html.Label("Categorias Equivalentes"),
                                                dcc.Dropdown(
                                                    id="grupo3c_filtro_devolutiva",
                                                    options=[
                                                        {"label": "Todos", "value": "Todos"}
                                                    ] + [
                                                        {"label": devolutiva, "value": devolutiva}
                                                        for devolutiva in devolutivas
                                                    ],
                                                    value="Todos",
                                                    multi=True,
                                                    clearable=False
                                                ),
                                            ], style={"width": "30%"}),
                                            
                                            
                                            # Anual (Checklist)
                                            html.Div([
                                            html.Label("Anual"),dcc.Checklist(id="grupo3c_filtro_anual",options=[{"label": str(ano),
                                            "value": ano} for ano in sorted(df_grupo3["Anual"].unique())],
                                            value=[2026],inline=True,style={"marginTop": "8px"}),],style={"width": "40%"}
                                            ),
                            
                                        ],style={
                                            "display": "flex",
                                            "justifyContent": "space-between",
                                            "gap": "20px",
                                            "marginBottom": "20px",
                                            "alignItems": "flex-start"
                                        }),
                                        html.Hr(style={'textAlign':'Center', 'width':'80%'}),
                            
        ]
    #--------------------
    #elif valor =='Não':
    #    return html.H4('Plot com 1(um) Frame, Habilitado, com sucesso!!!')  # ou None, se não quiser mostrar nada
    #else:
    #    return ''  # ou None, se não quiser mostrar nada

#@app.callback(
#    Output('saida', 'children', allow_duplicate=True),
#    Input('escolhab', 'value'),
#    prevent_initial_call=True
#)
#def atualizar_comparativo_nao(valorb):
#    if valorb == 'Não':
#        return html.H4('Plot com 1(um) Frame, Habilitado, com sucesso!!!',style={'textAlign':'center'}) 
#
#    return html.Div()



#26/10/2026
@app.callback(
    Output("grupo3c_filtro_grupo", "options"),
    Output("grupo3c_filtro_grupo", "value"),
    Input("grupo3c_filtro_anual", "value")
)
def atualizar_mensal_comparativo(anos_selecionados):
    if anos_selecionados is None:
        anos_selecionados = sorted(df_grupo3["Anual"].dropna().unique())

    df_filtrado = df_grupo3[
        df_grupo3["Anual"].isin(anos_selecionados)
    ]

    meses = sorted(df_filtrado["Mensal"].dropna().unique())

    opcoes = [{"label": "Todos", "value": "Todos"}] + [
        {"label": mes, "value": mes}
        for mes in meses
    ]

    return opcoes, ["Todos"]


#GRÁFICO 1 - opção SIM

#****************************************************************************************

#26/10/2026 - principal
@app.callback(
    Output("grupo3_filtro_devolutiva","options"),
    Output("grupo3_filtro_devolutiva","value"),
    Input("grupo3_filtro_grupo","value"),
    Input("grupo3_filtro_anual","value"),
)
def atualizar_devolutiva_grupo3(grupo, anual):
#Objetivo
#Atualizar automaticamente as opções do filtro Devolutiva conforme os filtros de Mês e Ano selecionados.

    dados = df_grupo3.copy()
    #Cria uma cópia do DataFrame original para evitar alterações indesejadas nos dados de origem.

    if grupo and "Todos" not in grupo:
        dados = dados[
            dados["Mensal"].isin(grupo)
        ]
    #Filtra os registros apenas para os meses selecionados.

    if anual:
        dados = dados[
            dados["Anual"].isin(anual)
        ]
    #Aplica o filtro de ano

    devolutivas = sorted(
        dados["Equivalencia_Categoria"]
        .dropna()
        .unique()
    )
    #Obtém todas as categorias existentes após os filtros.

    options = (
        [{"label": "Todos", "value": "Todos"}]
        +
        [{"label": item, "value": item}
         for item in devolutivas]
    )
    #Cria a lista de opções do dropdown.

    return options, ["Todos"]
    #Retorna: lista de opções e seleção padrão = "Todos"

#callback gráfico categorização
#Callback Principal do Gráfico
#Responsável por: gerar gráfico, gerar tabela, gerar comparativo (quando ativado)
@app.callback(
    Output("grupo3_grafico","figure"),
    Output("grupo3_tabela","children"),

    Input("grupo3_filtro_grupo","value"),
    Input("grupo3_filtro_anual","value"),
    Input("grupo3_filtro_devolutiva","value"),

    Input("escolha","value"),

    Input("grupo3c_filtro_grupo","value"),
    Input("grupo3c_filtro_anual","value"),
    Input("grupo3c_filtro_devolutiva","value")
)
def atualizar_visualizacao_grupo3(
    grupo,
    anual,
    devolutiva,

    escolha,

    grupob,
    anualb,
    devolutivab
):

    dados = df_grupo3.copy()
    #1. Filtros da seleção principal
    #Cria cópia dos dados.

    if grupo and "Todos" not in grupo:
    #Aplica filtro de mês.
        dados = dados[
            dados["Mensal"].isin(grupo)
        ]

    if anual:
    #Aplica filtro de ano.
        dados = dados[
            dados["Anual"].isin(anual)
        ]

    if devolutiva and "Todos" not in devolutiva:
    #Aplica filtro de categoria
        dados = dados[
            dados["Equivalencia_Categoria"].isin(devolutiva)
        ]

    dados_agrupados_a = (dados.groupby(["Mensal","Anual","Equivalencia_Categoria",'Mensal_tickets','Equivalencia_efetiva'],as_index=False
        )["Equivalencia_Categoria_tickets_MENSAL"].sum())
    #2. Agrupamento dos dados
    #Agrupa registros iguais e soma a quantidade de tickets.

    if escolha == "Sim":
    #3. Construção do comparativo
    #Só executa se usuário habilitou o modo comparativo.
        dados_b = df_grupo3.copy()
    #Cria conjunto de dados independente da seleção principal.
        if grupob and "Todos" not in grupob:
    #Filtra meses do comparativo.
            dados_b = dados_b[
                dados_b["Mensal"].isin(grupob)
            ]

        if anualb:
    #Filtra anos do comparativo.
            dados_b = dados_b[
                dados_b["Anual"].isin(anualb)
            ]

        if devolutivab and "Todos" not in devolutivab:
    #Filtra categorias do comparativo.
            dados_b = dados_b[
                dados_b["Equivalencia_Categoria"].isin(
                    devolutivab
                )
            ]

        dados_agrupados_b = (
    #Agrupa os dados do comparativo.
            dados_b
            .groupby(
                [
                    "Mensal",
                    "Anual",
                    "Equivalencia_Categoria",
                    "Mensal_tickets",
                    "Equivalencia_efetiva"
                ],
                as_index=False
            )["Equivalencia_Categoria_tickets_MENSAL"]
            .sum()
        )

    meses = {
    'janeiro': '01',
    'fevereiro': '02',
    'março': '03',
    'abril': '04',
    'maio': '05',
    'junho': '06',
    'julho': '07',
    'agosto': '08',
    'setembro': '09',
    'outubro': '10',
    'novembro': '11',
    'dezembro': '12'
}
#4. Dicionário de meses
#Serve para converter: em data numérica e permitir ordenação cronológica correta.
#**********************
# PRINCIPAL
# *********************    
    dados_agrupados_a = dados_agrupados_a.sort_values(
    by="Mensal",
    key=lambda s: pd.to_datetime(
        s.apply(
            lambda x: f"{x.split('.')[1]}-{meses[x.split('.')[0].lower()]}-01"
        )
    )
)
    #5. Ordenação dos dados principais
    #Ordena os meses cronologicamente.

    dados_agrupados_a = dados_agrupados_a.sort_values(
    by=[
        "Anual",
        "Mensal",
        "Equivalencia_Categoria_tickets_MENSAL"
    ],
    ascending=[
        True,
        True,
        False
    ]
)
    #6. Ordenação para ranking
    #Ordena: Ano, Mês, Quantidade de tickets (maior → menor)
   
    dados_agrupados_a["ordem_categoria"] = (
    dados_agrupados_a
    .groupby(["Anual", "Mensal"])
    ["Equivalencia_Categoria_tickets_MENSAL"]
    .rank(method="first", ascending=False)
)
    #7. Ranking mensal
    #Este é um dos trechos mais importantes do código.  
    #Ele cria uma classificação independente para cada mês.
    
    cores_evaluation = {
        "SUBSTITUIÇÃO DE PEÇA": "#636EFA",       # verde
        "SVE - COM INFORMAÇÃO": "#304D90",            # azul
        "INFORMAÇÃO DE CONTEÚDO DO ETKA": "#00CC96",    # laranja
        "SVE – Sem Info": "#AB63FA",      # vermelho
        "TIQUETE INVÁLIDO": "#FFA15A",  # roxo
        "INFORMAÇÕES ADICIONAIS PERTINENTES": "#178C0A",  # roxo
        "ERRO DE CATÁLOGO": "#B7320D",  # roxo
        "RESPONSABILIDADE DE OUTRAS ÁREAS": "#AAD4F1",  # roxo
        "ILUSTRAÇÃO": "#B1A90B",  # roxo
        "Não classificado": "#FF0303"  # roxo
    }
    #8. Dicionário de cores
    #Associa cada categoria a uma cor fixa.
 
    if escolha == "Sim":
        #9. Construção da figura
        #Cláusula IF Modo comparativo.

        fig = make_subplots(
            rows=1,
            cols=2,
            subplot_titles=[
                "Seleção Principal",
                "Comparativo"
            ]
        )
        #Cria dois gráficos lado a lado.
        fig.update_yaxes(matches='y')
        #Força mesma escala nos dois gráficos.
        # Muito importante para comparações visuais corretas.

    else:

        fig = go.Figure()
        #Modo simples.

#*******************
    legendas_principal = set()
    for _, linha in dados_agrupados_a.iterrows():
        #10. Criação das barras do gráfico principal
        #Percorre cada linha agrupada.

        if escolha == "Sim":
            fig.add_trace(
                go.Bar(
                    x=[linha["Mensal"]],
                    y=[linha["Equivalencia_Categoria_tickets_MENSAL"]],
                    offsetgroup=str(int(linha["ordem_categoria"])),
                    #Segredo do gráfico atual.
                    #Faz com que:
                    #posição 1 receba sempre a categoria líder daquele mês
                    #posição 2 receba sempre a segunda colocada
                    #posição 3 receba sempre a terceira colocada
                    #Independentemente da categoria.
                    #Foi a solução para o ranking mensal.
                    width=0.08,
                    #Controla largura das barras.
                    name=linha["Equivalencia_Categoria"],
                    marker_color=cores_evaluation.get(
                        linha["Equivalencia_Categoria"],
                        "#636EFA"
                    ),
                    text=[
                        f'{round(linha["Equivalencia_efetiva"] * 100)}% - '
                        f'{int(linha["Equivalencia_Categoria_tickets_MENSAL"])}'
                    ],
                    #Texto exibido acima da barra:
                    textposition="outside",
                    showlegend=(
    linha["Equivalencia_Categoria"]
    not in legendas_principal
)
                ),
                row=1,
                col=1
            )

        else:

            fig.add_trace(
                go.Bar(
                    x=[linha["Mensal"]],
                    y=[linha["Equivalencia_Categoria_tickets_MENSAL"]],
                    offsetgroup=str(int(linha["ordem_categoria"])),
                    width=0.08,
                    name=linha["Equivalencia_Categoria"],
                    marker_color=cores_evaluation.get(
                        linha["Equivalencia_Categoria"],
                        "#636EFA"
                    ),
                    text=[
                        f'{round(linha["Equivalencia_efetiva"] * 100)}% - '
                        f'{int(linha["Equivalencia_Categoria_tickets_MENSAL"])}'
                    ],
                    textposition="outside",
                    showlegend=(
    linha["Equivalencia_Categoria"]
    not in legendas_principal
)
                )
            )
        legendas_principal.add(
    linha["Equivalencia_Categoria"]
)

#**********************
# COMPARATIVO
# *********************      
    if escolha == "Sim":
        dados_agrupados_b_ordenado = dados_agrupados_b.sort_values(
                by=[
                    "Anual",
                    "Mensal",
                    "Equivalencia_Categoria_tickets_MENSAL"
                ],
                ascending=[
                    True,
                    True,
                    False
                ]
            )
        dados_agrupados_b_ordenado["ordem_categoria"] = (
            dados_agrupados_b_ordenado
            .groupby(["Anual", "Mensal"])
            ["Equivalencia_Categoria_tickets_MENSAL"]
            .rank(method="first", ascending=False)
        )
        cores_evaluation = {
                "SUBSTITUIÇÃO DE PEÇA": "#636EFA",       # verde
                "SVE - COM INFORMAÇÃO": "#304D90",            # azul
                "INFORMAÇÃO DE CONTEÚDO DO ETKA": "#00CC96",    # laranja
                "SVE – Sem Info": "#AB63FA",      # vermelho
                "TIQUETE INVÁLIDO": "#FFA15A",  # roxo
                "INFORMAÇÕES ADICIONAIS PERTINENTES": "#178C0A",  # roxo
                "ERRO DE CATÁLOGO": "#B7320D",  # roxo
                "RESPONSABILIDADE DE OUTRAS ÁREAS": "#AAD4F1",  # roxo
                "ILUSTRAÇÃO": "#B1A90B",  # roxo
                "Não classificado": "#FF0303"  # roxo
            }
            #7. Ranking mensal
            #Este é um dos trechos mais importantes do código.  
            #Ele cria uma classificação independente para cada mês.
            
        #11. Construção do gráfico comparativo
        #Ordena categorias do comparativo.
        for _, linha in dados_agrupados_b_ordenado.iterrows():
        #Percorre cada categoria encontrada.

                #df_cat = dados_agrupados_b[
                #    dados_agrupados_b[
                #        "Equivalencia_Categoria"
                #    ] == linha
                #]
        #Filtra somente aquela categoria.

                fig.add_trace(
        #Adiciona a barra correspondente ao gráfico comparativo.

                    go.Bar(

                        x=[linha["Mensal"]],
                        y=[linha["Equivalencia_Categoria_tickets_MENSAL"]],
                        offsetgroup=str(int(linha["ordem_categoria"])),
                        width=0.08,
                        #Controla largura das barras.
                        name=linha["Equivalencia_Categoria"],
                        marker_color=cores_evaluation.get(
                        linha["Equivalencia_Categoria"],
                        "#636EFA"
                                   ),         
                        text=[
                            f'{round(linha["Equivalencia_efetiva"] * 100)}% - '
                            f'{int(linha["Equivalencia_Categoria_tickets_MENSAL"])}'
                            ],
                        textposition="outside",
                        showlegend=False

                    ),

                    row=1,
                    col=2

                )
    
    # ------------------------------------------------------------------
    # LAYOUT
    # ------------------------------------------------------------------
    #12. Layout do gráfico
    #Configura:
    #título
    #altura
    #fundo branco
    #wlegenda
    #espaçamento das barras
    
    fig.update_layout(
    title=dict(
    text="Distribuição por Data da Categorização",
    x=0.5,
    xanchor="center",
    y=0.85
),

    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.20,
        xanchor="center",
        x=0.5
    ),

    plot_bgcolor="white",
    paper_bgcolor="white",
    legend_title="Equivalencia_Categoria",
    barmode="group",
    bargap=0.01,
    bargroupgap=0,
    height=800,

    yaxis=dict(
        title="Tickets por Categoria",
        showgrid=True,
        gridcolor="lightgray",
        showline=True,
        linewidth=1,
        linecolor="lightgray",
        mirror=True
    )
)
#-----------------------
    # antes do fig.update_xaxes()
    mapa_meses = {
        "janeiro": 1,
        "fevereiro": 2,
        "março": 3,
        "abril": 4,
        "maio": 5,
        "junho": 6,
        "julho": 7,
        "agosto": 8,
        "setembro": 9,
        "outubro": 10,
        "novembro": 11,
        "dezembro": 12,
    }
    #13. Ordenação do eixo X
    #Transforma: MÊS EM DATA NUMÉRICA
    dados_agrupados_a["ordem_data"] = (
        dados_agrupados_a["Mensal"]
        .apply(lambda x: (
            int(x.split(".")[1]) * 100 +
            mapa_meses[x.split(".")[0]]
        ))
    )

    meses_ordenados = (
        dados_agrupados_a
        .sort_values("ordem_data")
        ["Mensal"]
        .drop_duplicates()
        .tolist()
    )
    #Obtém meses na ordem correta.
    fig.update_xaxes(
        
        categoryorder="array",
        categoryarray=(
            dados_agrupados_a["Mensal"]
            .drop_duplicates()
            .tolist()
        ),
        showgrid=False,
        showline=True,
        linewidth=1,
        linecolor="lightgray",
        mirror=True
    )
    fig.update_xaxes(
    categoryorder="array",
    categoryarray=meses_ordenados,
    #Força Plotly a respeitar a ordem cronológica.
    showgrid=False,
    showline=True,
    linewidth=1,
    linecolor="lightgray",
    mirror=True
)

    fig.update_yaxes(
        showgrid=True,
        gridcolor="lightgray",
        showline=True,
        linewidth=1,
        linecolor="lightgray",
        mirror=True
    )
    #14. Construção da tabela
    #Monta a tabela HTML exibida abaixo do gráfico.
    tabela = html.Table(

        [

            html.Thead(
                #Cabeçalho.
                html.Tr([html.Th(coluna,style={
                                "backgroundColor": "#2C3E50",
                                "color": "white",
                                "border": "1px solid black",
                                "padding": "8px",
                                "textAlign": "center",
                                "fontWeight": "bold"
                            }

                        )

                        for coluna in dados_agrupados_a.columns

                    ]

                )

            ),

            html.Tbody(
                #Linhas.
                [

                    html.Tr(

                        [

                            html.Td(

                                dados_agrupados_a.iloc[i][coluna],

                                style={
                                    "border": "1px solid #D3D3D3",
                                    "padding": "8px",
                                    "textAlign": "center"
                                }

                            )

                            for coluna in dados_agrupados_a.columns

                        ],

                        style={
                            "backgroundColor":
                                "#F2F2F2"
                                if i % 2 == 0
                                else "white"
                        }
                        #Cria efeito zebrado: linha cinza, linha branca, linha cinza, linha branca

                    )

                    for i in range(
                        len(dados_agrupados_a)
                    )
                    #Percorre todas as linhas do DataFrame

                ]

            )

        ],

        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "fontFamily": "Arial",
            "marginTop": "10px"
        }

    )

    return fig, tabela

#-----------------------------------------ANUAL
@app.callback(
    Output("grupo3b_filtro_devolutiva","options"),
    Output("grupo3b_filtro_devolutiva","value"),
    Input("grupo3b_filtro_anual", "value")
)
def atualizar_devolutiva_grupo3b(anual):

    dados = df_grupo3b.copy()

    if anual:
        dados = dados[
            dados["Anual"].isin(anual)
        ]

    devolutivas = sorted(
        dados["Equivalencia_Categoria"]
        .dropna()
        .unique()
    )

    options = [
        {"label": "Todos", "value": "Todos"}
    ] + [
        {"label": item, "value": item}
        for item in devolutivas
    ]

    return options, "Todos"

@app.callback(
    Output("grupo3b_grafico","figure"),
    Output("grupo3b_tabela","children"),
    Input("grupo3b_filtro_anual","value"),
    Input("grupo3b_filtro_devolutiva","value")
)
def atualizar_visualizacao_grupo3b(
    anual,
    devolutiva
):

    dados = df_grupo3b.copy()

    # ----------------------------------------------------------
    # FILTROS
    # ----------------------------------------------------------

    if anual:
        dados = dados[
            dados["Anual"].isin(anual)
        ]

    if devolutiva != "Todos":
        dados = dados[
            dados["Equivalencia_Categoria"] == devolutiva
        ]

    # ----------------------------------------------------------
    # AGRUPAMENTO PARA A PIZZA
    # ----------------------------------------------------------

    dados_agrupados = (
    dados
    .groupby(
        ["Anual", "Equivalencia_Categoria"],
        as_index=False
    )
    .agg(
        {
            "Equivalencia_Categoria_tickets_ANUAL": "sum",
            "anual_tickets": "first"
        }
    )
    .sort_values(
        by=[
            "Anual",
            "Equivalencia_Categoria_tickets_ANUAL",
            "anual_tickets"
        ],
        ascending=[False, False, False]
    )
)

    # ----------------------------------------------------------
    # CORES
    # ----------------------------------------------------------

    cores_evaluation = {
        "SUBSTITUIÇÃO DE PEÇA": "#636EFA",
        "SVE - COM INFORMAÇÃO": "#304D90",
        "INFORMAÇÃO DE CONTEÚDO DO ETKA": "#00CC96",
        "SVE – Sem Info": "#AB63FA",
        "TIQUETE INVÁLIDO": "#FFA15A",
        "INFORMAÇÕES ADICIONAIS PERTINENTES": "#178C0A",
        "ERRO DE CATÁLOGO": "#B7320D",
        "RESPONSABILIDADE DE OUTRAS ÁREAS": "#AAD4F1",
        "ILUSTRAÇÃO": "#B1A90B",
        "Não classificado": "#FF0303"
    }
    total_consolidado = (
    dados_agrupados["Equivalencia_Categoria_tickets_ANUAL"]
    .sum()
)
    # ----------------------------------------------------------
    # GRÁFICO DE PIZZA
    # ----------------------------------------------------------

    fig = go.Figure()

    fig.add_trace(
        go.Pie(
            labels=dados_agrupados["Equivalencia_Categoria"],
            values=dados_agrupados[
                "Equivalencia_Categoria_tickets_ANUAL"
            ],
            hole=0.35,
            marker=dict(
                colors=[
                    cores_evaluation.get(
                        categoria,
                        "#636EFA"
                    )
                    for categoria in dados_agrupados[
                        "Equivalencia_Categoria"
                    ]
                ]
            ),
            #texttemplate="%{label}<br>%{percent}<br>%{value}",
            texttemplate="%{percent}<br>%{value}",
            textposition="inside",
            hovertemplate=
                "<b>%{label}</b><br>" +
                "Tickets: %{value}<br>" +
                "Percentual: %{percent}<extra></extra>"
        )
    )

    fig.update_layout(
    annotations=[
        dict(
            text=(
                f"<b>Consolidado Anual</b><br>"
                f"{total_consolidado:,}".replace(",", ".")
            ),
            x=0.5,
            y=0.5,
            font=dict(
                size=15,
                color="black"
            ),
            showarrow=False
        )
    ]
)

    fig.update_layout(
        title="Distribuição Anual por Categoria",
        plot_bgcolor="white",
        paper_bgcolor="white",
        height=800,
        legend_title="Categoria"
    )

    # ----------------------------------------------------------
    # TABELA
    # ----------------------------------------------------------

    tabela = html.Table(

        [
            html.Thead(
                html.Tr(
                    [
                        html.Th(
                            coluna,
                            style={
                                "backgroundColor": "#2C3E50",
                                "color": "white",
                                "border": "1px solid black",
                                "padding": "8px",
                                "textAlign": "center",
                                "fontWeight": "bold"
                            }
                        )
                        for coluna in dados_agrupados.columns
                    ]
                )
            ),

            html.Tbody(
                [
                    html.Tr(
                        [
                            html.Td(
                                dados_agrupados.iloc[i][coluna],
                                style={
                                    "border": "1px solid #D3D3D3",
                                    "padding": "8px",
                                    "textAlign": "center"
                                }
                            )
                            for coluna in dados_agrupados.columns
                        ],
                        style={
                            "backgroundColor":
                            "#F2F2F2"
                            if i % 2 == 0
                            else "white"
                        }
                    )
                    for i in range(len(dados_agrupados))
                ]
            )
        ],

        style={
            "width": "100%",
            "borderCollapse": "collapse",
            "fontFamily": "Arial",
            "marginTop": "10px"
        }

    )

    return fig, tabela
#-----------------------------------------ANUAL

@app.callback(
    Output("grupo3_filtro_grupo", "options"),
    Output("grupo3_filtro_grupo", "value"),
    Input("grupo3_filtro_anual", "value")
)
def atualizar_meses_grupo3(anos_selecionados):

    dados = df_grupo3.copy()

    if anos_selecionados:
        dados = dados[
            dados["Anual"].isin(anos_selecionados)
        ]

    meses_disponiveis = sorted(
        dados["Mensal"].dropna().unique()
    )

    options = (
        [{"label": "Todos", "value": "Todos"}]
        +
        [
            {"label": mes, "value": mes}
            for mes in meses_disponiveis
        ]
    )

    return options, ["Todos"]

@app.callback(
    Output("container-tabela-memoria", "children"),
    Input("check-colunas", "value"),
    Input("busca-ticket-id", "value"),
    Input("busca-archive-date", "value")
)
def atualizar_colunas(
    colunas_selecionadas,
    ticket_busca,
    archive_date_busca
):

    if not colunas_selecionadas:
        return html.Div(
            "Nenhuma coluna selecionada.",
            style={
                "padding": "20px",
                "fontWeight": "bold",
                "color": "red"
            }
        )

    df_filtrado = df_grupo5.copy()

    # filtro Ticket ID
    if ticket_busca:
        df_filtrado = df_filtrado[
            df_filtrado["Ticket_ID"]
            .astype(str)
            .str.contains(
                str(ticket_busca),
                case=False,
                na=False
            )
        ]
    # Filtro Archive Date
    if archive_date_busca:
        df_filtrado = df_filtrado[
        df_filtrado["Archive_date"]
        .astype(str)
        .str.contains(
        str(archive_date_busca),
        case=False,
        na=False)]

    df_filtrado = df_filtrado[colunas_selecionadas]

    return dash_table.DataTable(
        columns=[
            {
                "name": c,
                "id": c
            }
            for c in colunas_selecionadas
        ],
        data=df_filtrado.to_dict("records"),
        style_table={
            "overflowX": "auto"
        },
        style_header={
            "backgroundColor": "#2C3E50",
            "color": "white",
            "fontWeight": "bold"
        },
        style_cell={
            "textAlign": "left",
            "padding": "5px",
            "minWidth": "120px"
        },
        page_size=20
    )
#-botões_exportação
#-btn-1
#tipo_ilustracoes
@app.callback(
    Output("download-tipo-liberacao-xlsx","data"),
    Input("btn-exportar-tipo-liberacao","n_clicks"),
    State("filtro-grupo","value"),
    prevent_initial_call=True
)
def exportar_tipo_liberacao(n_clicks, grupo):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)
    
    if grupo == "Todos":
        query = """
            SELECT Mensal, Evaluation, Anual, Evaluation_Mensal FROM distr_mensal_kpi
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
                    SELECT * FROM distr_mensal_kpi
                """
        dados = pd.read_sql_query(
            query,
            conn,
            params=[str(grupo)]
        )

    conn.close()

    nome_arquivo = (
        f"Avavalicao_Evaluation_{grupo}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-tipo-liberacao-xlsx2","data"),
    Input("btn-exportar-tipo-liberacao2","n_clicks"),
    State("filtro-grupo","value"),
    prevent_initial_call=True
)
def exportar_tipo_liberacao2(n_clicks, grupo):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)
    
    if grupo == "Todos":
        query = """
            SELECT Mensal, Avaliacao, Anual, Avaliacao_Mensal FROM distr_monitoria
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
                    SELECT * FROM distr_monitoria
                """
        dados = pd.read_sql_query(
            query,
            conn,
            params=[str(grupo)]
        )

    conn.close()

    nome_arquivo = (
        f"Avavalicao_Monitoria_Consolidado_{grupo}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-tipo-liberacao-xlsx3","data"),
    Input("btn-exportar-tipo-liberacao3","n_clicks"),
    State("filtro-grupo3-anual","value"),
    prevent_initial_call=True
)
def exportar_tipo_liberacao3(n_clicks, grupo):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)
    
    if grupo == "Todos":
        query = """
            SELECT Mensal,Avaliacao,Anual,Avaliacao_Mensal, Mensal_tickets, Avaliacao_Mensal_percent AS AV_PERCENT FROM distr_mensal_kpi2

        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
                    SELECT * FROM distr_mensal_kpi2
                """
        dados = pd.read_sql_query(
            query,
            conn,
            params=[str(grupo)]
        )

    conn.close()

    nome_arquivo = (
        f"Avaliacao_Monitoria_Mensal_{grupo}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-tipo-liberacao-xlsx4","data"),
    Input("btn-exportar-tipo-liberacao4","n_clicks"),
    State("filtro-grupo4-anual","value"),
    prevent_initial_call=True
)
def exportar_tipo_liberacao4(n_clicks, grupo):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)
    
    if grupo == "Todos":
        query = """
            SELECT Mensal,Anual,Evaluation,Media_Mensal,Media_Mensal_Consolidada FROM distr_mensal_kpi3
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
                    SELECT * FROM distr_mensal_kpi3
                """
        dados = pd.read_sql_query(
            query,
            conn,
            params=[str(grupo)]
        )

    conn.close()

    nome_arquivo = (
        f"Avaliacao_Media__Mensal_{grupo}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-tipo-liberacao-xlsx5","data"),
    Input("btn-exportar-tipo-liberacao5","n_clicks"),
    State("filtro-grupo5-anual","value"),
    prevent_initial_call=True
)
def exportar_tipo_liberacao5(n_clicks, grupo):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)
    
    if grupo == "Todos":
        query = """
            SELECT Mensal,Anual, Media_Mensal_Consolidada, Media_Anual FROM distr_mensal_kpi5
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
                    SELECT * FROM distr_mensal_kpi5
                """
        dados = pd.read_sql_query(
            query,
            conn,
            params=[str(grupo)]
        )

    conn.close()

    nome_arquivo = (
        f"Avaliacao_Media__Anual_{grupo}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )


#-btn-2
#status_ilustracoes
@app.callback(
    Output("download-grupo1-xlsx", "data"),
    Input("btn-exportar-grupo1", "n_clicks"),
    State("grupo1_filtro_grupo", "value"),
    State("grupo1_filtro_status", "value"),
    prevent_initial_call=True
)
def exportar_grupo1_xlsx(n_clicks, grupo, status):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)

    if grupo == "Todos" and status == "Todos":
        query = """
            SELECT * FROM distr_duracao_mensal
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
            SELECT * FROM distr_duracao_mensal
        """
        dados = pd.read_sql_query(query, conn, params=[grupo, status])

    conn.close()

    nome_arquivo = (
        f"Tempo_de_Resposta_Duracao_Mensal_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-grupo1b-xlsx", "data"),
    Input("btn-exportar-grupo1b", "n_clicks"),
    State("grupo1b_filtro_grupo", "value"),
    State("grupo1b_filtro_status", "value"),
    prevent_initial_call=True
)
def exportar_grupo1_2_xlsx(n_clicks, grupo, status):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)

    if grupo == "Todos" and status == "Todos":
        query = """
            SELECT * FROM distr_duracao_anual
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
            SELECT * FROM distr_duracao_anual
        """
        dados = pd.read_sql_query(query, conn, params=[grupo, status])

    conn.close()

    nome_arquivo = (
        f"Tempo_de_Resposta_Duracao_Anual_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-grupo2-xlsx", "data"),
    Input("btn-exportar-grupo2", "n_clicks"),
    State("grupo2_filtro_grupo", "value"),
    State("grupo2_filtro_ilustracao", "value"),
    prevent_initial_call=True
)
def exportar_grupo2_xlsx(n_clicks, grupo, status):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)

    if grupo == "Todos" and status == "Todos":
        query = """
            SELECT * FROM distr_categoria
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
            SELECT * FROM distr_categoria
        """
        dados = pd.read_sql_query(query, conn, params=[grupo, status])

    conn.close()

    nome_arquivo = (
        f"Volumetria_Mensal_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-grupo2b-xlsx", "data"),
    Input("btn-exportar-grupo2b", "n_clicks"),
    State("grupo2b_filtro_grupo", "value"),
    State("grupo2b_filtro_ilustracao", "value"),
    prevent_initial_call=True
)
def exportar_grupo2b_xlsx(n_clicks, grupo, status):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)

    if grupo == "Todos" and status == "Todos":
        query = """
            SELECT * FROM distr_categoria4
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
            SELECT * FROM distr_categoria4
        """
        dados = pd.read_sql_query(query, conn)

    conn.close()

    nome_arquivo = (
        f"Volumetria_Anual_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-grupo3-xlsx", "data"),
    Input("btn-exportar-grupo3", "n_clicks"),
    State("grupo3_filtro_grupo", "value"),
    State("grupo3_filtro_anual", "value"),
    prevent_initial_call=True
)
def exportar_categorizacaoM_xlsx(n_clicks, grupo, status):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)

    if grupo == "Todos" and status == "Todos":
        query = """
            SELECT * FROM distr_periodo_mensal
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
            SELECT * FROM distr_periodo_mensal
        """
        dados = pd.read_sql_query(query, conn)

    conn.close()

    nome_arquivo = (
        f"Categorizacao_Mensal_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-grupo3b-xlsx", "data"),
    Input("btn-exportar-grupo3b", "n_clicks"),
    State("grupo3b_filtro_grupo", "value"),
    State("grupo3b_filtro_anual", "value"),
    prevent_initial_call=True
)
def exportar_categorizacaoA_xlsx(n_clicks, grupo, status):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO1)

    if grupo == "Todos" and status == "Todos":
        query = """
            SELECT * FROM distr_periodo_anual
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
            SELECT * FROM distr_periodo_anual
        """
        dados = pd.read_sql_query(query, conn)

    conn.close()

    nome_arquivo = (
        f"Categorizacao_Anual_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-memoria-docx", "data"),
    Input("btn-exportar-memoria", "n_clicks"),
    prevent_initial_call=True
)
def manual_docx(n_clicks):
    os.makedirs('tempfile', exist_ok=True)
    documento = Document()
    documento.add_heading('Metodologias utilizadas para Cálculo dos Indicadores.:', level=1)
    documento.add_heading('Glossário.:', level=2)
    tabela = documento.add_table(rows=18, cols=2)
    tabela.style = 'Table Grid'
    cabecalho = tabela.rows[0].cells
    linha1 = tabela.rows[1].cells
    linha2 = tabela.rows[2].cells
    linha3 = tabela.rows[3].cells
    linha4 = tabela.rows[4].cells
    linha5 = tabela.rows[5].cells
    linha6 = tabela.rows[6].cells
    linha7 = tabela.rows[7].cells
    linha8 = tabela.rows[8].cells
    linha9 = tabela.rows[9].cells
    linha10 = tabela.rows[10].cells
    linha11 = tabela.rows[11].cells
    linha12 = tabela.rows[12].cells
    linha13 = tabela.rows[13].cells
    linha14 = tabela.rows[14].cells
    linha15 = tabela.rows[15].cells
    linha16 = tabela.rows[16].cells
    linha17 = tabela.rows[17].cells
    linha18 = tabela.rows[17].cells
    cabecalho[0].text = 'Termo'
    cabecalho[1].text = 'Conceito'
    linha1[0].text = 'Ticket ID'
    linha1[1].text = 'ID do bilhete'
    linha2[0].text = 'Brand to which this ticket pertains'
    linha2[1].text = 'Marca à qual este tíquete pertence'
    linha3[0].text = 'Date, on which the ticket was archived (format: dd.mm.yyyy).'
    linha3[1].text = 'Data em que o tíquete foi arquivado (formato: dd.mm.aaaa).'
    linha4[0].text = 'Catalogue'
    linha4[1].text = 'Catálogo'
    linha5[0].text = 'Main group'
    linha5[1].text = 'Grupo principal'
    linha6[0].text = 'Illustration text page'
    linha6[1].text = 'Página de texto de ilustração'
    linha7[0].text = 'GPH'
    linha7[1].text = 'GPH'
    linha8[0].text = 'Evaluation by the ticket creator when archived'
    linha8[1].text = 'Avaliação pelo criador do tíquete quando arquivado'
    linha9[0].text = 'Tipo de produto'
    linha9[1].text = 'Tipo de produto'
    linha10[0].text = 'Ticket category'
    linha10[1].text = 'Categoria de ingresso'
    linha11[0].text = 'Editor category'
    linha11[1].text = 'Categoria de editor'
    linha12[0].text = 'Commodity'
    linha12[1].text = 'Mercadoria'
    linha13[0].text = 'Responsible party for catalogue'
    linha13[1].text = 'Parte responsável pelo catálogo'
    linha14[0].text = 'Company which carries out processing'
    linha14[1].text = 'Empresa que realiza o processamento'
    linha15[0].text = 'Gross duration of edit event in seconds'
    linha15[1].text = 'Duração bruta do evento de edição em segundos'
    linha16[0].text = 'Net duration of edit event in seconds'
    linha16[1].text = 'Duração líquida do evento de edição em segundos'
    linha17[0].text = 'Ticket internal event ID'
    linha17[1].text = 'ID do evento interno do bilhete'
    linha18[0].text = 'Creation date (format: yyyymmdd) do arquivo de dados'
    linha18[1].text = 'Data de criação (formato: aaaammdd) do arquivo de dados'
    documento.add_heading('Note 1.:', level=3)
    documento.add_paragraph('Here the word "edit" refers to either the forwarding or replying to an myETKA info support ticket.')
    documento.add_heading('Note 2.:', level=3)
    documento.add_paragraph('Only tickets which correspond to the current selection can be accounted for in the statistics.')
    documento.add_heading('Current selection.:', level=3)
    documento.add_paragraph('(No restrictions)')
    documento.add_heading('Colunas utilizadas da base original.:', level=2)
    documento.add_paragraph('Ticket ID', style='List Number')
    documento.add_paragraph('Archive date', style='List Number')
    documento.add_paragraph('Evaluation', style='List Number')
    documento.add_paragraph('Editor category', style='List Number')
    documento.add_paragraph('Net Time', style='List Number')
    documento.add_paragraph('Ticket internal event ID *** ATENÇÃO - SOMENTE SE A ANÁLISE FOR PARA PROJETAR AS INTERAÇÕES DE TICKETS, ' \
    'RECOMENDA-SE UTILIZAR ESTA COLUNA, DO CONTRÁRIO, DESCONSIDERE. PARA TRATATIVA DE EXCLUSIVIDADE É SUGERIDO UTILIZAR APENAS OS TICKETS DE EVENTO 1. TÃO LOGO, PARA EXCLUSIVADADE RECOMENDA-SE A BUSCA DE VALOR EXATO(PRIMEIRA OCORRÊNCIA)' \
    ', VIA DE REGRA EM CONTRA PONTO, PARA  MENSURAÇÃO DE INTERAÇÕES RECOMENDA-SE A BUSCA DE VALORES APROXIMADOS. ***', style='List Number')
    documento.add_heading('Checklist para Atualização do relatório.:', level=2)
    documento.add_picture('Imagem1.jpg', width=Inches(6))
    documento.add_paragraph('fazer o dowload do arquivo CSV - ETKA',style='List Bullet')
    documento.add_paragraph(r'salvar apenas o arquivo CSV - com o nome: relatorio_ETKA >>> pasta>>> "\\VWTBJBSHFSCO\Pecas_e_Acessorios_Vinhedo\Tecnica de Peças\Tulio\TIQUETE\base importada do ETKA\Arquivo csv"',style='List Bullet')
    documento.add_paragraph('atualizar a query - ARQUIVO CSV - NÃO FUNCIONA, DEVE COPIAR E COLAR O CONTEÚDO',style='List Bullet')
    documento.add_paragraph('Rodar a macro - "Atualizar_lista_tiquetes"',style='List Bullet')
    documento.add_paragraph('Atualizar totas as tabelas dinamicas e Query "calculo de Time"',style='List Bullet')
    documento.add_heading('Projeções de Indicadores.:', level=2)
    tabela2 = documento.add_table(rows=42, cols=2)
    tabela2.style = 'Table Grid'
    cabecalho2 = tabela2.rows[0].cells
    linha1b = tabela2.rows[1].cells
    linha2b = tabela2.rows[2].cells
    linha3b= tabela2.rows[3].cells
    linha4b = tabela2.rows[4].cells
    linha5b = tabela2.rows[5].cells
    linha6b = tabela2.rows[6].cells
    linha7b = tabela2.rows[7].cells
    linha8b = tabela2.rows[8].cells
    linha9b = tabela2.rows[9].cells
    linha10b = tabela2.rows[10].cells
    linha11b = tabela2.rows[11].cells
    linha12b = tabela2.rows[12].cells
    linha13b = tabela2.rows[13].cells
    linha14b = tabela2.rows[14].cells
    linha15b = tabela2.rows[15].cells
    linha16b = tabela2.rows[16].cells
    linha17b = tabela2.rows[17].cells
    linha18b = tabela2.rows[18].cells
    linha19b = tabela2.rows[19].cells
    linha20b = tabela2.rows[20].cells
    linha21b = tabela2.rows[21].cells
    linha22b = tabela2.rows[22].cells
    linha23b = tabela2.rows[23].cells
    linha24b = tabela2.rows[24].cells
    linha25b = tabela2.rows[25].cells
    linha26b = tabela2.rows[26].cells
    linha27b = tabela2.rows[27].cells
    linha28b = tabela2.rows[28].cells
    linha29b = tabela2.rows[29].cells
    linha30b = tabela2.rows[30].cells
    linha31b = tabela2.rows[31].cells
    linha32b = tabela2.rows[32].cells
    linha33b = tabela2.rows[33].cells
    linha34b = tabela2.rows[34].cells
    linha35b = tabela2.rows[35].cells
    linha36b = tabela2.rows[36].cells
    linha37b = tabela2.rows[37].cells
    linha38b = tabela2.rows[38].cells
    linha39b = tabela2.rows[39].cells
    linha40b = tabela2.rows[40].cells
    linha41b = tabela2.rows[41].cells
    cabecalho2[0].text = 'Coluna'
    cabecalho2[1].text = 'Cálculo'
    linha1b[0].text = "['Net Time - Ticket']"
    linha1b[1].text = '=SOMASE(COLUNA."Ticket ID";LINHA."Ticket ID";COLUNA."Net Time")'
    linha2b[0].text = "['Diario']"
    linha2b[1].text = 'Converte os valores da coluna ["Archive date"] de texto para data, substitua "." por "/", aplique o fortmato formato dd.mm.aaaa.'
    linha3b[0].text = "['Net Time - Diario']"
    linha3b[1].text = '=SOMASE(COLUNA."Diario";LINHA."Diario";COLUNA."Net Time")'
    linha4b[0].text = "['Evaluation_Diario_tickets']"
    linha4b[1].text = '=CONT.SE(COLUNA."Archive date";LINHA."Archive date";COLUNA."Evaluation")'
    linha5b[0].text = "['Diario_tickets']"
    linha5b[1].text = '=CONT.SE(COLUNA."Diario";LINHA."Diario";COLUNA."Ticket ID")'
    linha6b[0].text = "['Mensal']"
    linha6b[1].text = '=TEXTO(LINHA."Diario";"MMMM.AAAA")'
    linha7b[0].text = '["Net Time - Mensal"]'
    linha7b[1].text = '=SOMASE(COLUNA."Mensal";LINHA."Mensal";COLUNA."Net Time")'
    linha8b[0].text = '["Evaluation_Mensal_tickets"]'
    linha8b[1].text = '=CONT.SE(COLUNA."Mensal";LINHA."Mensal";COLUNA."Evaluation")'
    linha9b[0].text = '["Mensal_tickets"]'
    linha9b[1].text = '=CONT.SE(COLUNA."Mensal";LINHA."Mensal";COLUNA."Ticket ID")'
    linha10b[0].text = '["Net Time - Média Mensal"]'
    linha10b[1].text = '=LINHA."Net Time - Mensal"/LINHA."Mensal_tickets"'
    linha11b[0].text = '["Duração Mensal - Média"]'
    linha11b[1].text = '=LINHA."Net Time - Média Mensal"/(60*60*24)'
    linha12b[0].text = '["Duração Mensal - Consolidada"]'
    linha12b[1].text = '=LINHA."Net Time - Mensal"/(60*60*24)'
    linha13b[0].text = '["Anual"]'
    linha13b[1].text = '=TEXTO(LINHA."Diario";"AAAA")'
    linha14b[0].text = '["Net Time - Anual"]'
    linha14b[1].text = '=SOMASE(COLUNA."Anual";LINHA."Anual";COLUNA."Net Time")'
    linha15b[0].text = '["anual_tickets"]'
    linha15b[1].text = '=CONT.SE(COLUNA."Anual";LINHA."Anual";COLUNA."Ticket ID")'
    linha16b[0].text = '["Net Time - Média Anual"] '
    linha16b[1].text = 'LINHA."Net Time - Anual"/LINHA."anual_tickets"'
    linha17b[0].text = '["Duração Anual - Média"] '
    linha17b[1].text = '=LINHA."Net Time - Média Anual"/(60*60*24)'
    linha18b[0].text = '["Duração Anual - Consolidada"]'
    linha18b[1].text = '=LINHA."Net Time - Anual"/(60*60*24)'
    linha19b[0].text = '["IO"]'
    linha19b[1].text = '=SE(LLINHA."Ticket ID"<>"";1;0); LOGO, COMO TODO TIKET ID REPRESENTA UMA ENTRADA/EMISSÃO DE TICKET, TODA LINHA É IGUAL A 1.'
    linha20b[0].text = '["Base_historica_consolidado"] '
    linha20b[1].text = '=SOMA(COLUNA."IO")'
    linha21b[0].text = '["Diario_tickets_percent"]'
    linha21b[1].text = '=LINHA."Diario_tickets"/LINHA."anual_tickets"'
    linha22b[0].text = '["Mensal_tickets_percent"]'
    linha22b[1].text = '=LINHA."Mensal_tickets"/LINHA."anual_tickets"'
    linha23b[0].text = '["anual_tickets_percent"]'
    linha23b[1].text = '=LINHA."anual_tickets"/LINHA."Base_historica_consolidado"'
    linha24b[0].text = '["Evaluation_Diario"]'
    linha24b[1].text = '=CONT.SE(COLUNA."Diario";LINHA."Diario";COLUNA."Evaluation")'
    linha25b[0].text = '["Category_Diario"]'
    linha25b[1].text = '=CONT.SE(COLUNA."Diario";LINHA."Diario";COLUNA."Editor category")'
    linha26b[0].text = '["Evaluation_Mensal"]'
    linha26b[1].text = '=CONT.SE(COLUNA."Mensal";LINHA."Mensal";COLUNA."Evaluation")'
    linha27b[0].text = '["Category_Mensal"]'
    linha27b[1].text = '=CONT.SE(COLUNA."Mensal";LINHA."Mensal";COLUNA."Editor category")'
    linha28b[0].text = '["Evaluation_anual"]'
    linha28b[1].text = '=CONT.SE(COLUNA."Anual";LINHA."Anual";COLUNA."Evaluation")'
    linha29b[0].text = '["Category_anual"]'
    linha29b[1].text = '=CONT.SE(COLUNA."Anual";LINHA."Anual";COLUNA."Editor category")'
    linha30b[0].text = '["Avaliacao"]'
    linha30b[1].text = '=SE(LINHA."Evaluation"="(AUTO_ARCHIVED)";"NÃO AVALIADO";"AVALIADO")'
    linha31b[0].text = '["Avaliacao_Mensal"]'
    linha31b[1].text = '=CONT.SE(COLUNA."Mensal";LINHA."Mensal";COLUNA."Avaliacao")'
    linha32b[0].text = '["Avaliacao_Anual"]'
    linha32b[1].text = '=CONT.SE(COLUNA."Anual";LINHA."Anual";COLUNA."Avaliacao")'
    linha33b[0].text = '["Equivalencia_Categoria"]'
    linha33b[1].text = '=SE(LINHA."Editor category" = "Availabilty / alternatives";"SVE – Sem Info";' \
    'SE(LINHA."Editor category" = "Carport data";"ERRO DE CATÁLOGO";' \
    'SE(LINHA."Editor category" = "Fitting Parts";"SUBSTITUIÇÃO DE PEÇA";' \
    'SE(LINHA."Editor category" = "None (inquiry is justified)";"ILUSTRAÇÃO";' \
    'SE(LINHA."Editor category" = "Price";"RESPONSABILIDADE DE OUTRAS ÁREAS;' \
    'SE(LINHA."Editor category" = "Repair support";"INFORMAÇÕES ADICIONAIS PERTINENTES";' \
    'SE(LINHA."Editor category" = "Retrofit";"TIQUETE INVÁLIDO";' \
    'SE(LINHA."Editor category" = "Verification";"SVE - COM INFORMAÇÃO";' \
    'SE(LINHA."Editor category" = "Wrong delivery";"INFORMAÇÃO DE CONTEÚDO DO ETKA";"Não classificado")))))))))'
    linha34b[0].text = '["Equivalencia_Categoria_tickets_MENSAL"]'
    linha34b[1].text = '=CONT.SE(COLUNA."Mensal";LINHA."Mensal";COLUNA."Equivalencia_Categoria")'
    linha35b[0].text = '["Equivalencia_efetiva"]'
    linha35b[1].text = "=ARRED((LINHA.'Equivalencia_Categoria_tickets_MENSAL'/LINHA.'Mensal_tickets');2)"
    linha36b[0].text = '["Evaluation_elegibilidade"]'
    linha36b[1].text = '=SE(LINHA."Evaluation"="(AUTO_ARCHIVED)";"NÃO ELEGÍVEL PARA O CÁLCULO.";"ELEGÍVEL")'
    linha37b[0].text = '["Peso_Media_Mensal"]'
    linha37b[1].text = '=SE(LINHA.''="VERY GOOD";"100";' \
    'SE(LINHA.''="GOOD";"84";' \
    'SE(LINHA.''="SATISFACTORY";"67";' \
    'SE(LINHA.''="SUFFICIENT";"50";"0"))))'
    linha38b[0].text = '["Evaluation_Mensal_tickets_elegiveis"]'
    linha38b[1].text = '=SE(LINHA."Evaluation_elegibilidade" = "ELEGÍVEL";' \
    '"CONT.SE(COLUNA."Mensal";LINHA."Mensal";COLUNA."Evaluation_elegibilidade")";"0")'
    linha39b[0].text = '["Media_Mensal"]'
    linha39b[1].text = 'SE(LINHA."Evaluation_elegibilidade"="ELEGÍVEL";' \
    '"LINHA."Evaluation_Mensal"*LINHA."Peso_Media_Mensal"/LINHA."Evaluation_Mensal_tickets_elegiveis"";"")'
    linha40b[0].text = '["Equivalencia_Categoria_tickets_ANUAL"]'
    linha40b[1].text = '=CONT.SE(COLUNA."Anual";LINHA."Anual";COLUNA."Equivalencia_Categoria")'
    linha41b[0].text = '["Equivalencia_efetiva_ANUAL"]'
    linha41b[1].text = "=ARRED((LINHA.'Equivalencia_Categoria_tickets_ANUAL'/LINHA.'anual_tickets');2)"    
    documento.add_page_break()
    documento.save(r'.\tempfile\Metodologias.docx')
    return dcc.send_file(r'.\tempfile\Metodologias.docx')


@app.callback(
    Output("escolha", "value"),
    Input("btn-limpa-sim", "n_clicks"),
    prevent_initial_call=True
)
def limpar_sim(n):
    return None

# ==========================================
# EXECUÇÃO
# ==========================================
def abrir_navegador():
    webbrowser.open_new("http://127.0.0.1:8053")

if __name__ == "__main__":
    threading.Timer(1, abrir_navegador).start()
    app.run(debug=True,use_reloader=False,port=8053)