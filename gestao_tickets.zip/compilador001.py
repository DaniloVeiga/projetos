import glob
import pandas as pd

def pacote_consulta():
    lista_arquivo = []
    arquivos = glob.glob(r'.\csv\*.csv')
    n_arquivos = len(arquivos)

    for i in range(n_arquivos):
        lista_arquivo.append(arquivos[i])

        #print(arquivos[i][15:])

    print('Total de arquivo(s) capturado(s).: {} arquivo(s) txt.'.format(n_arquivos))
    tabela = {'Ilustações Capuradas':lista_arquivo}
    df_tabela = pd.DataFrame(tabela)
    df_tabela.to_excel(r'indice_tickets_csv.xlsx', index=False)

def importador():
    lista_dfs = []
    leitor = pd.read_excel(r'indice_tickets_csv.xlsx')
    n_linhas = len(leitor)

    for i in range(n_linhas):
        nome_arquivo = leitor.iloc[i, 0]
        print(f'Base {nome_arquivo} convertida com sucesso.')
        df = pd.read_csv(nome_arquivo, encoding='latin-1', sep=';')
        df['base'] = nome_arquivo
        lista_dfs.append(df)
    # Junta todos os DataFrames
    df_final = pd.concat(lista_dfs, ignore_index=True)
    df_final2 = df_final.drop_duplicates(subset=['Ticket ID', 'Ticket internal event ID'])
    # Gera um único arquivo Excel
    df_final2.to_csv('relatorio_ETKA.csv', sep=';', encoding='utf-8-sig', index=False)
    print('Arquivo base_consolidada.xlsx gerado com sucesso.')
        
pacote_consulta()
importador()
