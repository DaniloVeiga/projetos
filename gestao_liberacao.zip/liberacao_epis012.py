import pandas as pd
import dash
from dash import dcc, html, Input, Output, State
from dash.exceptions import PreventUpdate
import plotly.io as pio
import tempfile
from datetime import datetime
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import plotly.express as px
import sqlite3
import openpyxl
import kaleido
import threading
import webbrowser
from dash import dash_table
from docx import Document
from docx.shared import Inches
import os
# ==========================================
# LEITURA
# ==========================================
pasta = os.path.dirname(__file__)
pasta_base_sql = os.path.join(pasta, r'base_sql')
BANCO1 = os.path.join(pasta_base_sql,'relatorio_geral.db')
BANCO2 = os.path.join(pasta_base_sql,'extrato_mensal.db')
BANCO3 = os.path.join(pasta_base_sql,'extrato_anual.db')

#***
conexao = sqlite3.connect(BANCO1)
df = pd.read_sql_query("""SELECT * FROM geral_tabela""",conexao)

#***
conexao = sqlite3.connect(BANCO2)
df2 = pd.read_sql_query("""SELECT * FROM tabela_extrato_mensal""",conexao)


#***
conexao = sqlite3.connect(BANCO3)
df3 = pd.read_sql_query("""SELECT * FROM tabela_extrato_anual""",conexao)

#------------------------------------------
#FUNÇÕES
#------------------------------------------
#CATALOGO_MENSAL
def catalogo_mensal(
        Periodo_Nome='Todos',
        Anual=None
        ):
    df_filtrado2 = df2.copy()

# =====================================
# FILTRO PERÍODO_NOME
# =====================================
    if Periodo_Nome != "Todos":
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Periodo_Nome"].astype(str) == str(Periodo_Nome)
        ]

    if Anual:
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Ano"].astype(str).isin(Anual)
        ]
# =====================================
# ORDENAÇÃO
# =====================================
    df_filtrado2['Monat'] = df_filtrado2['Monat'].astype(float)
    df_filtrado2['Consolidado_Catalogo_Periodo'] = df_filtrado2['Consolidado_Catalogo_Periodo'].astype(int)
    df_filtrado2['Consolidado_Historico_Periodo'] = df_filtrado2['Consolidado_Historico_Periodo'].astype(int)
    df_filtrado2['Consolidado_Pagina_Periodo'] = df_filtrado2['Consolidado_Pagina_Periodo'].astype(int)
    df_filtrado2['Consolidado_N_Paginadas_Periodo'] = df_filtrado2['Consolidado_N_Paginadas_Periodo'].astype(int)
    df_filtrado2 = df_filtrado2.sort_values("Monat")

    figura_catalogo = go.Figure()

    
    #Consolidado_Historico_Periodo
    #Historico_Periodo
    figura_catalogo.add_trace(
    go.Scatter(
    
        x=df_filtrado2["Periodo_Nome"],
        y=df_filtrado2["Consolidado_Historico_Periodo"],
        #visible='legendonly',
        showlegend=True,
        mode='lines+markers+text',
        text=df_filtrado2["Consolidado_Historico_Periodo"],
        textposition='top center',
        marker=dict(
            symbol='triangle-up',
            size=10
        ),
        name='Histórico Período (Linha)'
    ))

    figura_catalogo.add_trace(
            go.Scatter(
                x=df_filtrado2["Periodo_Nome"],
                y=df_filtrado2["Consolidado_Pagina_Periodo"],
                #visible='legendonly',
                showlegend=True,
                mode='lines+markers+text',
                text=df_filtrado2["Consolidado_Pagina_Periodo"],
                textposition='top center',
                marker=dict(
                    symbol='triangle-up',
                    size=10
                ),
                name='Consolidado_Pagina_Periodo'
            ))
        
   
    figura_catalogo.update_layout(
    template="plotly_white"
)
    max_y = df_filtrado2["Consolidado_Historico_Periodo"].max()

    figura_catalogo.update_yaxes(
        range=[0, max_y * 2]
    )

    figura_catalogo.update_layout(
    updatemenus=[
        dict(
            x=0.00,
            y=1.15,
            buttons=[
                dict(
                    label="Mostrar Apenas Texto",
                    method="restyle",
                    args=[{"mode": "text"}]
                ),
                dict(
                    label="Mostrar Apenas Pontos de Disperção",
                    method="restyle",
                    args=[{"mode": "markers"}]
                ),
                dict(
                    label="Mostrar Apenas Linhas de Tendência",
                    method="restyle",
                    args=[{"mode": "lines"}]
                    ),
                dict(
                    label="Mostrar Pontos de Disperção & Texto",
                    method="restyle",
                    args=[{"mode": "markers+text"}]
                    ),
                dict(
                    label="Mostrar Imagem Padrão",
                    method="restyle",
                    args=[{"mode": "markers+text+lines"}]
                    ),
            ]
        )
    ]
)    
    figura_catalogo.update_layout(
    title={
        'text': 'Disperção Histórica por Período - Workload Mensal',
        'x': 0.5,
        'xanchor': 'center'
    }
)
    return figura_catalogo

#CONSOLIDADO_MENSAL
def consolidado_mensal(
        Periodo_Nome='Todos',
        Anual=None
        ):
    df_filtrado2 = df2.copy()

# =====================================
# FILTRO PERÍODO_NOME
# =====================================
    if Periodo_Nome != "Todos":
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Periodo_Nome"].astype(str) == str(Periodo_Nome)
        ]

    if Anual:
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Ano"].astype(str).isin(Anual)
        ]
# =====================================
# ORDENAÇÃO
# =====================================
    df_filtrado2['Monat'] = df_filtrado2['Monat'].astype(float)
    df_filtrado2 = df_filtrado2.sort_values("Monat")

    figura_consolidado = go.Figure()

    df_grafico = (
    df_filtrado2[
        [
            'Periodo_Nome',
            'Consolidado_Modificacao_Periodo',
            'Consolidado_liberacao_Periodo',
            'Monat'
        ]
    ]
    .drop_duplicates()
)

    figura_consolidado.add_trace(    
    go.Bar(
        x=df_grafico["Periodo_Nome"],
        y=df_grafico["Consolidado_Modificacao_Periodo"],
        text=df_grafico["Consolidado_Modificacao_Periodo"],
        texttemplate='%{text}',
        textposition='inside',
        textfont=dict(color='white', size=12),
        name='Modificação (Linha)'
    )    
)
    figura_consolidado.add_trace(
    go.Bar(
        x=df_grafico["Periodo_Nome"],
        y=df_grafico["Consolidado_liberacao_Periodo"],
        text=df_grafico["Consolidado_liberacao_Periodo"],
        texttemplate='%{text}',
        textposition='inside',
        textfont=dict(color='white', size=12),
        name='Liberação (Linha)'
    )
)
#----------------------
#Consolidado_N_Paginadas_Periodo
    figura_consolidado.add_trace(
        go.Scatter(
            x=df_filtrado2["Periodo_Nome"],
            y=df_filtrado2["Consolidado_N_Paginadas_Periodo"],
            #visible='legendonly',
            showlegend=True,
            mode='markers+text',
            text=df_filtrado2["Consolidado_N_Paginadas_Periodo"],
            textposition='top center',
            marker=dict(
                symbol='triangle-up',
                size=10
            ),
            name='Consolidado_N_Paginadas_Periodo'
        ))

#----------------------
    figura_consolidado.update_layout(
        barmode='stack'
    )

    figura_consolidado.update_layout(
    template="plotly_white"
)
    max_y = df_filtrado2["Consolidado_Modificacao_Periodo"].max()

    figura_consolidado.update_yaxes(
        range=[0, max_y * 2]
    )

    figura_consolidado.update_layout(
    updatemenus=[
        dict(
            buttons=[
                dict(
                    label="Mostrar Apenas Pontos de Dispersão",
                    method="restyle",
                    args=[
                        {
                            "visible": [False, False, True],
                            "mode": [None, None, "markers"]
                        }
                    ]
                ),
                dict(
                    label="Mostrar Linha de Tendência & Pontos de Dispersão",
                    method="restyle",
                    args=[
                        {
                            "visible": [False, False, True],
                            "mode": [None, None, "lines+markers"]
                        }
                    ]
                ),
                dict(
                    label="Imagem Padrão de Dispersão",
                    method="restyle",
                    args=[
                         {
                         "visible": [False, False, True],
                         "mode": [None, None, "lines+markers+text"],
                         'textposition':'top center'
                          }
                          ]
                          ),                
                dict(
                    label="Imagem Padrão Liberação",
                    method="restyle",
                    args=[
                         {
                         "visible": ['legendonly', True,'legendonly'],
                         "mode": [None, None, "lines+markers+text"],
                         #'textposition':['','','']
                         #'text':[None,'',None],
                          }
                          ]
                          ),                
                dict(
                        label="Imagem Padrão Modificação",
                        method="restyle",
                        args=[
                        {
                        "visible": [True, 'legendonly','legendonly'],
                        "mode": [None, None, "lines+markers+text"],
                                          }
                                          ]
                                          ),                
               dict(
                    label="Imagem Padrão",
                    method="restyle",
                    args=[
                                       {
                                       "visible": [True,True,True],
                                       "mode": [None, None, "markers+text"],
                                                         }
                                                         ]
                                                         ),                
                                               
                dict(
                    label="Mostrar Rótulos",
                    method="restyle",
                    args=[{
                        "textposition": [
                            "inside",
                            "inside",
                            "top center"
                        ],
                        "mode": [
                            None,
                            None,
                            "markers+text"
                        ]
                    }]
                ),
                dict(
                    label="Ocultar Rótulos",
                    method="restyle",
                    args=[{
                        "textposition": [
                            "none",
                            "none",
                            "top center"
                        ],
                        "mode": [
                            None,
                            None,
                            "markers"
                        ]
                    }]
                )
            ]
        )
    ]
)
    figura_consolidado.update_layout(
    title={
        'text': 'Volumetria por Período',
        'x': 0.5,
        'xanchor': 'center'
    }
)
    return figura_consolidado

#CATALOGO_ANUAL
def catalogo_anual(
        #Periodo_Nome='Todos',
        Anual=None
        ):
    df_filtrado3 = df3.copy()

# =====================================
# FILTRO PERÍODO_NOME
# =====================================
    #if Periodo_Nome != "Todos":
    #    df_filtrado3 = df_filtrado3[
    #        df_filtrado3["Periodo_Nome"].astype(str) == str(Periodo_Nome)
    #    ]

    if Anual:
        df_filtrado3 = df_filtrado3[
            df_filtrado3["Ano"].astype(str).isin(Anual)
        ]
# =====================================
# ORDENAÇÃO
# =====================================
    df_filtrado3['Monat'] = df_filtrado3['Monat'].astype(float)
    df_filtrado3["N_Paginadas_Ano"] = df_filtrado3["N_Paginadas_Ano"].astype(int)
    df_filtrado3 = df_filtrado3.sort_values("Monat")

    figura_catalogo = go.Figure()

    figura_catalogo.add_trace(
        go.Scatter(
            x=df_filtrado3["Ano"],
            y=df_filtrado3["Consolidado_Historico_Ano"],
            mode='lines+markers+text',
            #visible='legendonly',
            showlegend=True,
            text=df_filtrado3["Consolidado_Historico_Ano"],
            textposition='top center',
            marker=dict(
                symbol='triangle-up',
                size=10
            ),
            name='Historico_Ano (Linha)'
        )
    )
    figura_catalogo.add_trace(
                go.Scatter(
                    x=df_filtrado3["Ano"],
                    y=df_filtrado3["Consolidado_Pagina_Ano"],
                    mode='lines+markers+text',
                    #visible='legendonly',
                    showlegend=True,
                    text=df_filtrado3["Consolidado_Pagina_Ano"],
                    textposition='top center',
                    marker=dict(
                        symbol='triangle-up',
                        size=10
                    ),
                    name='Consolidado_Pagina_Ano'
                )
            )
    

    figura_catalogo.update_layout(
    template="plotly_white"
)
    max_y = df_filtrado3["Consolidado_Catalogo_Ano"].max()

    figura_catalogo.update_yaxes(
        range=[0, max_y * 1.50]
    )
    figura_catalogo.update_layout(
        updatemenus=[
            dict(
                x=0.00,
                y=1.15,
                buttons=[
                    dict(
                        label="Mostrar Apenas Texto",
                        method="restyle",
                        args=[{"mode": "text"}]
                    ),
                    dict(
                        label="Mostrar Apenas Pontos de Disperção",
                        method="restyle",
                        args=[{"mode": "markers"}]
                    ),
                    dict(
                        label="Mostrar Apenas Linhas de Tendência",
                        method="restyle",
                        args=[{"mode": "lines"}]
                        ),
                    dict(
                        label="Mostrar Pontos de Disperção & Texto",
                        method="restyle",
                        args=[{"mode": "markers+text"}]
                        ),
                    dict(
                        label="Mostrar Imagem Padrão",
                        method="restyle",
                        args=[{"mode": "markers+text+lines"}]
                        ),
                ]
            )
        ]
    )

    
    return figura_catalogo

#CONSOLIDADO_ANUAL
def consolidado_anual(
        #Periodo_Nome='Todos',
        Anual=None
        ):
    df_filtrado3 = df3.copy()

# =====================================
# FILTRO PERÍODO_NOME
# =====================================
    if Anual:
        df_filtrado3 = df_filtrado3[
            df_filtrado3["Ano"].astype(str).isin(Anual)
        ]
# =====================================
# ORDENAÇÃO
# =====================================
    df_filtrado3['Monat'] = df_filtrado3['Monat'].astype(float)
    df_filtrado3 = df_filtrado3.sort_values("Monat")

    figura_consolidado = go.Figure()

    df_grafico = (
    df_filtrado3[
        [
            'Ano',
            'Consolidado_Modificacao_Ano',
            'Consolidado_liberacao_Ano',
        ]
    ]
    .drop_duplicates()
)

    figura_consolidado.add_trace(    
    go.Bar(
        x=df_grafico["Ano"],
        y=df_grafico["Consolidado_Modificacao_Ano"],
        text=df_grafico["Consolidado_Modificacao_Ano"],
        texttemplate='%{text}',
        textposition='inside',
        textfont=dict(color='white', size=12),
        name='Modificação (Linha)'
    )    
)
    figura_consolidado.add_trace(
    go.Bar(
        x=df_grafico["Ano"],
        y=df_grafico["Consolidado_liberacao_Ano"],
        text=df_grafico["Consolidado_liberacao_Ano"],
        texttemplate='%{text}',
        textposition='inside',
        textfont=dict(color='white', size=12),
        name='Liberação (Linha)'
    )
)
#----------------------
#Consolidado_N_Paginadas_Periodo
    figura_consolidado.add_trace(
        go.Scatter(
            x=df_filtrado3["Ano"],
            y=df_filtrado3["Consolidado_N_Paginadas_Ano"],
            #visible='legendonly',
            showlegend=True,
            mode='markers+text',
            text=df_filtrado3["Consolidado_N_Paginadas_Ano"],
            textposition='top center',
            marker=dict(
                symbol='triangle-up',
                size=10
            ),
            name='Consolidado_N_Paginadas_Ano'
        ))

#----------------------

    figura_consolidado.update_layout(
        barmode='stack'
    )

    figura_consolidado.update_layout(
    template="plotly_white"
)
    max_y = df_filtrado3["Consolidado_N_Paginadas_Ano"].max()

    figura_consolidado.update_yaxes(
        range=[0, max_y * 2]
    )

    figura_consolidado.update_layout(
        updatemenus=[
            dict(
                buttons=[
                    dict(
                        label="Mostrar Apenas Pontos de Dispersão",
                        method="restyle",
                        args=[
                            {
                                "visible": [False, False, True],
                                "mode": [None, None, "markers"]
                            }
                        ]
                    ),
                    dict(
                        label="Mostrar Linha de Tendência & Pontos de Dispersão",
                        method="restyle",
                        args=[
                            {
                                "visible": [False, False, True],
                                "mode": [None, None, "lines+markers"]
                            }
                        ]
                    ),
                    dict(
                        label="Imagem Padrão de Dispersão",
                        method="restyle",
                        args=[
                             {
                             "visible": [False, False, True],
                             "mode": [None, None, "lines+markers+text"],
                             'textposition':'top center'
                              }
                              ]
                              ),                
                    dict(
                        label="Imagem Padrão Liberação",
                        method="restyle",
                        args=[
                             {
                             "visible": ['legendonly', True,'legendonly'],
                             "mode": [None, None, "lines+markers+text"],
                             #'textposition':['','','']
                             #'text':[None,'',None],
                              }
                              ]
                              ),                
                    dict(
                            label="Imagem Padrão Modificação",
                            method="restyle",
                            args=[
                            {
                            "visible": [True, 'legendonly','legendonly'],
                            "mode": [None, None, "lines+markers+text"],
                                              }
                                              ]
                                              ),                
                   dict(
                        label="Imagem Padrão",
                        method="restyle",
                        args=[
                                           {
                                           "visible": [True,True,True],
                                           "mode": [None, None, "markers+text"],
                                                             }
                                                             ]
                                                             ),                
                                                   
                    dict(
                        label="Mostrar Rótulos",
                        method="restyle",
                        args=[{
                            "textposition": [
                                "inside",
                                "inside",
                                "top center"
                            ],
                            "mode": [
                                None,
                                None,
                                "markers+text"
                            ]
                        }]
                    ),
                    dict(
                        label="Ocultar Rótulos",
                        method="restyle",
                        args=[{
                            "textposition": [
                                "none",
                                "none",
                                "top center"
                            ],
                            "mode": [
                                None,
                                None,
                                "markers"
                            ]
                        }]
                    )
                ]
            )
        ]
    )
    
    return figura_consolidado


# ==========================================
# APP
# ==========================================
app = dash.Dash(__name__)
app.layout = html.Div([
    html.H2("Controle de Liberação de Peças - EPIS",style={"textAlign": "center"}),
    html.Hr(style={'width':'100%'}),
    dcc.Tabs([
        dcc.Tab(label='Amostragem Mensal',children=[
            html.H3('Gestão de Indicadores Mensais',style={'textAlign':'Center'}),
                        html.Hr(style={'width':'100%'}),
                        dcc.Tabs([
                            dcc.Tab(label='Catálogo', children=[
#ELEMENTOS GRÁFICOS.
#----------------------------
html.Div([
    html.Div([html.Label("Selecione o Período Mensal:", style={"fontWeight": "bold"}),
    dcc.Dropdown(
                                id="filtro-grupob",
                                options=[
                                    {"label": "Todos", "value": "Todos"}
                                ] + [
                                    {"label": str(g), "value": str(g)}
                                    for g in sorted(
                                        df2["Periodo_Nome"]
                                        .astype(str)
                                        .unique()
                                    )
                                ],
                                value="Todos",
                                clearable=False
                            )
                        ],
                        style={"width": "300px"}
                    ),
         html.Div([html.Label("Selecione o Período Anual.:", style={"fontWeight": "bold"}),
                   dcc.Checklist(
                               id="filtro-df2-ano",
                               options=[
                                   {
                                       "label": str(ano),
                                       "value": str(ano)
                                   }
                                   for ano in sorted(
                                       df2["Ano"].astype(str).unique()
                                   )
                               ],
                               value=['2026'],
                               inline=True
                           )]),
        #-------------------
        #BOTÃO XLSX
        #-------------------
        html.Div([
                                                html.Button("Exportar XLSX [SCORE]",id="btn-exportar-CATALOGO-MENSAL",style={
                                                                "backgroundColor": "#27AE60",
                                                                "color": "white",
                                                                "border": "none",
                                                                "padding": "6px 12px",
                                                                "fontWeight": "bold",
                                                                "cursor": "pointer"}),
                                        
                                                dcc.Download(id="download-CATALOGO-MENSAL-xlsx")],
                                                    style={
                                                        "display": "flex",
                                                        "gap": "15px",
                                                        "marginBottom": "2px"}
                                                ),      
                  
], style={
    "display": "flex",
    "gap": "20px",
    #"alignItems": "flex-start"
    "alignItems": "flex-end",
    "paddingBottom": "30px"
}),
dcc.Graph(id="grafico-mensal-catalogo", figure=catalogo_mensal()),
html.Div([
    dash_table.DataTable(
        id='tabela-df2',
        columns=[{"name": i, "id": i} for i in df2.columns],
        data=df2.to_dict('records'),

        page_size=20,
        filter_action='native',
        sort_action='native',

        style_table={'overflowX': 'auto'},
        style_cell={'textAlign': 'left'},
        style_header={'fontWeight': 'bold'}
    )
])
#----------------------------                                
                            ]),
                            dcc.Tab(label='Consolidado', children=[
#ELEMENTOS GRÁFICOS - CONSOLIDADO.
#----------------------------
html.Div([
    html.Div([html.Label("Selecione o Período Mensal:", style={"fontWeight": "bold"}),
    dcc.Dropdown(
                                id="filtro-grupo-consolidado",
                                options=[
                                    {"label": "Todos", "value": "Todos"}
                                ] + [
                                    {"label": str(g), "value": str(g)}
                                    for g in sorted(
                                        df2["Periodo_Nome"]
                                        .astype(str)
                                        .unique()
                                    )
                                ],
                                value="Todos",
                                clearable=False
                            )
                        ],
                        style={"width": "300px"}
                    ),
         html.Div([html.Label("Selecione o Período Anual.:", style={"fontWeight": "bold"}),
                   dcc.Checklist(
                               id="filtro-df2-ano-consolidado",
                               options=[
                                   {
                                       "label": str(ano),
                                       "value": str(ano)
                                   }
                                   for ano in sorted(
                                       df2["Ano"].astype(str).unique()
                                   )
                               ],
                               value=['2026'],
                               inline=True
                           )]),
        #-------------------
        #BOTÃO XLSX
        #-------------------
        html.Div([
                                                html.Button("Exportar XLSX [SCORE]",id="btn-exportar-CONSOLIDADO-MENSAL",style={
                                                                "backgroundColor": "#27AE60",
                                                                "color": "white",
                                                                "border": "none",
                                                                "padding": "6px 12px",
                                                                "fontWeight": "bold",
                                                                "cursor": "pointer"}),
                                        
                                                dcc.Download(id="download-CONSOLIDADO-MENSAL-xlsx")],
                                                    style={
                                                        "display": "flex",
                                                        "gap": "15px",
                                                        "marginBottom": "2px"}
                                                ),      
                  
], style={
    "display": "flex",
    "gap": "20px",
    #"alignItems": "flex-start"
    "alignItems": "flex-end",
    "paddingBottom": "30px"
}),
dcc.Graph(id="grafico-mensal-consolidado", figure=consolidado_mensal()),
html.Div([
    dash_table.DataTable(
        id='tabela-df2-consolidado',
        columns=[{"name": i, "id": i} for i in df2.columns],
        data=df2.to_dict('records'),

        page_size=20,
        filter_action='native',
        sort_action='native',

        style_table={'overflowX': 'auto'},
        style_cell={'textAlign': 'left'},
        style_header={'fontWeight': 'bold'}
    )
])
#----------------------------                                
                            ]),
                        ])
        ]),
        dcc.Tab(label='Amostragem Anual',children=[
            html.H3('Gestão de Indicadores Anuais',style={'textAlign':'Center'}),
                                    html.Hr(style={'width':'100%'}),
                                    dcc.Tabs([
                                        dcc.Tab(label='Catálogo', children=[
#ELEMENTOS GRÁFICOS - ANUAL.
#----------------------------
html.Div([
         html.Div([html.Label("Selecione o Período Anual.:", style={"fontWeight": "bold"}),
                   dcc.Checklist(
                               id="filtro-df3-ano",
                               options=[
                                   {
                                       "label": str(ano),
                                       "value": str(ano)
                                   }
                                   for ano in sorted(
                                       df3["Ano"].astype(str).unique()
                                   )
                               ],
                               value=['2021','2022','2023','2024','2025','2026'],
                               inline=True
                           )]),
        #-------------------
        #BOTÃO XLSX
        #-------------------
        html.Div([
                                                html.Button("Exportar XLSX [SCORE]",id="btn-exportar-CATALOGO-ANUAL",style={
                                                                "backgroundColor": "#27AE60",
                                                                "color": "white",
                                                                "border": "none",
                                                                "padding": "6px 12px",
                                                                "fontWeight": "bold",
                                                                "cursor": "pointer"}),
                                        
                                                dcc.Download(id="download-CATALOGO-ANUAL-xlsx")],
                                                    style={
                                                        "display": "flex",
                                                        "gap": "15px",
                                                        "marginBottom": "2px"}
                                                ),      
              
                  
], style={
    "display": "flex",
    "gap": "20px",
    #"alignItems": "flex-start"
    "alignItems": "flex-end",
    "paddingBottom": "30px"
}),
dcc.Graph(id="grafico-anual-catalogo-df3", figure=catalogo_anual()),
html.Div([
    dash_table.DataTable(
        id='tabela-df3',
        columns=[{"name": i, "id": i} for i in df3.columns],
        data=df3.to_dict('records'),

        page_size=20,
        filter_action='native',
        sort_action='native',

        style_table={'overflowX': 'auto'},
        style_cell={'textAlign': 'left'},
        style_header={'fontWeight': 'bold'}
    )
])
#----------------------------                                

                                        ]),
                                        dcc.Tab(label='Consolidado', children=[
#ELEMENTOS GRÁFICOS - CONSOLIDADO ANUAL.
#----------------------------
html.Div([
    
         html.Div([html.Label("Selecione o Período Anual.:", style={"fontWeight": "bold"}),
                   dcc.Checklist(
                               id="filtro-df3-ano-consolidado",
                               options=[
                                   {
                                       "label": str(ano),
                                       "value": str(ano)
                                   }
                                   for ano in sorted(
                                       df3["Ano"].astype(str).unique()
                                   )
                               ],
                               value=['2021','2022','2023','2024','2025','2026'],
                               inline=True
                           )]),
        #-------------------
        #BOTÃO XLSX
        #-------------------
        html.Div([
                                                html.Button("Exportar XLSX [SCORE]",id="btn-exportar-CONSOLIDADO-ANUAL",style={
                                                                "backgroundColor": "#27AE60",
                                                                "color": "white",
                                                                "border": "none",
                                                                "padding": "6px 12px",
                                                                "fontWeight": "bold",
                                                                "cursor": "pointer"}),
                                        
                                                dcc.Download(id="download-CONSOLIDADO-ANUAL-xlsx")],
                                                    style={
                                                        "display": "flex",
                                                        "gap": "15px",
                                                        "marginBottom": "2px"}
                                                ),      
              
                  
], style={
    "display": "flex",
    "gap": "20px",
    #"alignItems": "flex-start"
    "alignItems": "flex-end",
    "paddingBottom": "30px"
}),
dcc.Graph(id="grafico-anual-catalogo-df3-consolidado", figure=consolidado_anual()),
html.Div([
    dash_table.DataTable(
        id='tabela-df3-consolidado',
        columns=[{"name": i, "id": i} for i in df3.columns],
        data=df3.to_dict('records'),

        page_size=20,
        filter_action='native',
        sort_action='native',

        style_table={'overflowX': 'auto'},
        style_cell={'textAlign': 'left'},
        style_header={'fontWeight': 'bold'}
    )
])
#----------------------------                                

                                        ]),
                                    ])
        ]),
        dcc.Tab(label='Base Processada',children=[
# ELEMENTOS GRÁFICOS - BASE PROCESSADA.
# -------------------------------------
html.Br(),

html.H3(
    'Overview - Customização da Tabela',
    style={'textAlign': 'center'}
),

html.Hr(style={'width': '100%'}),

# Seleção de colunas
html.Div(
    [
        dcc.Checklist(
            id="check-colunas",
            options=[
                {"label": col, "value": col}
                for col in df.columns
            ],
            value=[
                "Benutzer_ID",
                "Statzart",
                "Teilenummer",
                "Kurztext",
                "EAY"
            ],
            inline=True
        )
    ],
    style={
        "border": "1px solid #ccc",
        "borderRadius": "8px",
        "padding": "10px",
        "marginBottom": "10px",
        "backgroundColor": "#f8f9fa"
    }
),

# Filtros
html.Div(
    [
        html.Label(
            "Benutzer-ID:",
            style={"fontWeight": "bold"}
        ),

        dcc.Input(
            id="busca-ticket-id",
            type="text",
            placeholder="Digite o Benutzer-ID...",
            debounce=True,
            style={
                "width": "250px",
                "marginRight": "20px"
            }
        ),

        html.Label(
            "Buscar Periodo_Nome:",
            style={"fontWeight": "bold"}
        ),

        dcc.Input(
            id="busca-archive-date",
            type="text",
            placeholder="Digite o período...",
            debounce=True,
            style={"width": "250px"}
        ),
#-----------------------------
#BOTÃO XLSX
#-----------------------------
html.Div([
                                        html.Button("Exportar XLSX [SCORE]",id="btn-exportar-tabela-geral",style={
                                                        "backgroundColor": "#27AE60",
                                                        "color": "white",
                                                        "border": "none",
                                                        "padding": "6px 12px",
                                                        "fontWeight": "bold",
                                                        "cursor": "pointer"}),
                                
                                        dcc.Download(id="download-tabela-geral-xlsx")],
                                            style={
                                                "display": "flex",
                                                "gap": "15px",
                                                "marginBottom": "1px"}
                                        ),
                                        html.Button(
                                                                    "Exportar DOCX [METODOLOGIAS]",
                                                                    id="btn-exportar-memoria",
                                                                    #-------------------------------------------------------------------------
                                                                    style={
                                                                        "backgroundColor": "#2514DA",
                                                                        "color": "white",
                                                                        "border": "none",
                                                                        "padding": "6px 12px",
                                                                        "fontWeight": "bold",
                                                                        "cursor": "pointer"
                                                                    }
                                                                ),
                                                
                                                                dcc.Download(
                                                                    id="download-memoria-docx"
                                                                )
    ],
    style={
        "display": "flex",
        "alignItems": "center",
        "gap": "20px",
        "marginBottom": "15px"
    }
),
# Tabela
dash_table.DataTable(
    id='tabela-processada',

    columns=[
        {"name": c, "id": c}
        for c in [
            "Benutzer_ID",
            "Statzart",
            "Teilenummer",
            "Kurztext",
            "EAY"
        ]
    ],

    data=[],

    page_size=20,

    filter_action='native',
    sort_action='native',

    style_table={
        'overflowX': 'auto'
    },

    style_cell={
        'textAlign': 'left'
    },

    style_header={
        'fontWeight': 'bold'
    }
)
        ])
    ])
])

#-----------------------------------
#CALLBACK
#-----------------------------------
#CATALOGO_MENSAL
@app.callback(
    Output("grafico-mensal-catalogo", "figure"),
    Input("filtro-grupob", "value"),
    Input("filtro-df2-ano", "value")
)
def atualizar_catalogo(periodo, anos):

    return catalogo_mensal(
        Periodo_Nome=periodo,
        Anual=anos
    )

@app.callback(
    Output("tabela-df2", "data"),
    Input("filtro-grupob", "value"),
    Input("filtro-df2-ano", "value")
)
#TABELA_MENSAL
def atualizar_tabela_catalogo(periodo, anos):

    df_filtrado2 = df2.copy()

    if periodo != "Todos":
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Periodo_Nome"].astype(str) == str(periodo)
        ]

    if anos:
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Ano"].astype(str).isin(anos)
        ]

    df_filtrado2["Monat"] = df_filtrado2["Monat"].astype(float)
    df_filtrado2 = df_filtrado2.sort_values("Monat")

    return df_filtrado2.to_dict("records")

#CONSOLIDADO_MENSAL
@app.callback(
    Output("grafico-mensal-consolidado", "figure"),
    Input("filtro-grupo-consolidado", "value"),
    Input("filtro-df2-ano-consolidado", "value")
)
def atualizar_consolidado(periodo, anos):

    return consolidado_mensal(
        Periodo_Nome=periodo,
        Anual=anos
    )

#TABELA MENSAL
@app.callback(
    Output("tabela-df2-consolidado", "data"),
    Input("filtro-grupo-consolidado", "value"),
    Input("filtro-df2-ano-consolidado", "value")
)
def atualizar_tabela(periodo, anos):

    df_filtrado2 = df2.copy()

    if periodo != "Todos":
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Periodo_Nome"].astype(str) == str(periodo)
        ]

    if anos:
        df_filtrado2 = df_filtrado2[
            df_filtrado2["Ano"].astype(str).isin(anos)
        ]

    df_filtrado2["Monat"] = df_filtrado2["Monat"].astype(float)
    df_filtrado2 = df_filtrado2.sort_values("Monat")

    return df_filtrado2.to_dict("records")

#CATALOGO_ANUAL
@app.callback(
    Output("grafico-anual-catalogo-df3", "figure"),
    Input("filtro-df3-ano", "value")
)
def atualizar_catalogo_anual(anos):

    return catalogo_anual(
        Anual=anos
    )

@app.callback(
    Output("tabela-df3", "data"),
    Input("filtro-df3-ano", "value")
)
#TABELA ANUAL
def atualizar_tabela_anual(anos):

    df_filtrado3 = df3.copy()

    if anos:
        df_filtrado3 = df_filtrado3[
            df_filtrado3["Ano"].astype(str).isin(anos)
        ]

    df_filtrado3["Monat"] = df_filtrado3["Monat"].astype(float)
    df_filtrado3 = df_filtrado3.sort_values("Monat")

    return df_filtrado3.to_dict("records")

#CONSOLIDADO_ANUAL
@app.callback(
    Output("grafico-anual-catalogo-df3-consolidado", "figure"),
    Input("filtro-df3-ano-consolidado", "value")
)
def atualizar_consolidado_anual(anos):

    return consolidado_anual(
        Anual=anos
    )

#TABELA ANUAL
@app.callback(
    Output("tabela-df3-consolidado", "data"),
    Input("filtro-df3-ano-consolidado", "value")
)
def atualizar_tabela_anual_consolidado(anos):

    df_filtrado3 = df3.copy()

    if anos:
        df_filtrado3 = df_filtrado3[
            df_filtrado3["Ano"].astype(str).isin(anos)
        ]

    df_filtrado3["Monat"] = df_filtrado3["Monat"].astype(float)
    df_filtrado3 = df_filtrado3.sort_values("Monat")

    return df_filtrado3.to_dict("records")

#ATUALIZAR COLUNAS DA TABELA PROCESSADA.
@app.callback(
    Output("tabela-processada", "columns"),
    Output("tabela-processada", "data"),
    Input("check-colunas", "value"),
    Input("busca-ticket-id", "value"),
    Input("busca-archive-date", "value")
)
def atualizar_colunas(
    colunas_selecionadas,
    ticket_busca,
    archive_date_busca
):

    if not colunas_selecionadas:
        return [], []

    df_filtrado = df

    if ticket_busca:
        df_filtrado = df_filtrado[
            df_filtrado["Benutzer_ID"]
            .astype(str)
            .str.contains(
                ticket_busca,
                case=False,
                na=False
            )
        ]

    if archive_date_busca:
        df_filtrado = df_filtrado[
            df_filtrado["Periodo_Nome"]
            .astype(str)
            .str.contains(
                archive_date_busca,
                case=False,
                na=False
            )
        ]

    df_filtrado = df_filtrado[colunas_selecionadas]

    return (
        [{"name": c, "id": c} for c in colunas_selecionadas],
        df_filtrado.to_dict("records")
    )

@app.callback(
    Output("download-CATALOGO-MENSAL-xlsx","data"),
    Input("btn-exportar-CATALOGO-MENSAL","n_clicks"),
    State("filtro-grupob","value"),
    prevent_initial_call=True
)
def exportar_catalogo_mensal(n_clicks, grupo):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO2)
    
    if grupo == "Todos":
        query = """
            SELECT * FROM tabela_extrato_mensal
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
            SELECT *
            FROM tabela_extrato_mensal
            WHERE Periodo_Nome = ?
        """

        dados = pd.read_sql_query(
            query,
            conn
        )
    conn.close()

    nome_arquivo = (
        f"CATALOGO_MENSAL_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-CONSOLIDADO-MENSAL-xlsx","data"),
    Input("btn-exportar-CONSOLIDADO-MENSAL","n_clicks"),
    State("filtro-grupo-consolidado","value"),
    prevent_initial_call=True
)
def exportar_consolidado_mensal(n_clicks, grupo):
    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO2)
    
    if grupo == "Todos":
        query = """
            SELECT * FROM tabela_extrato_mensal
        """
        dados = pd.read_sql_query(query, conn)

    else:
        query = """
            SELECT *
            FROM tabela_extrato_mensal
            WHERE Periodo_Nome = ?
        """

        dados = pd.read_sql_query(
            query,
            conn
        )
    conn.close()

    nome_arquivo = (
        f"CONSOLIDADO_MENSAL_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-CATALOGO-ANUAL-xlsx", "data"),
    Input("btn-exportar-CATALOGO-ANUAL", "n_clicks"),
    State("filtro-df3-ano", "value"),
    prevent_initial_call=True
)
def exportar_catalogo_anual(n_clicks, anos):

    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO3)

    try:

        # Nenhum ano selecionado -> exporta tudo
        if not anos:

            query = """
                SELECT *
                FROM tabela_extrato_anual
            """

            dados = pd.read_sql_query(query, conn)

        # Um ou mais anos selecionados
        else:

            placeholders = ",".join(["?"] * len(anos))

            query = f"""
                SELECT *
                FROM tabela_extrato_anual
                WHERE Ano IN ({placeholders})
            """

            dados = pd.read_sql_query(
                query,
                conn,
                params=anos
            )

    finally:
        conn.close()

    nome_arquivo = (
        f"CATALOGO_ANUAL_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-CONSOLIDADO-ANUAL-xlsx", "data"),
    Input("btn-exportar-CONSOLIDADO-ANUAL", "n_clicks"),
    State("filtro-df3-ano-consolidado", "value"),
    prevent_initial_call=True
)
def exportar_consolidado_anual(n_clicks, anos):

    if not n_clicks:
        raise PreventUpdate

    conn = sqlite3.connect(BANCO3)

    try:

        # Nenhum ano selecionado -> exporta tudo
        if not anos:

            query = """
                SELECT *
                FROM tabela_extrato_anual
            """

            dados = pd.read_sql_query(query, conn)

        # Um ou mais anos selecionados
        else:

            placeholders = ",".join(["?"] * len(anos))

            query = f"""
                SELECT *
                FROM tabela_extrato_anual
                WHERE Ano IN ({placeholders})
            """

            dados = pd.read_sql_query(
                query,
                conn,
                params=anos
            )

    finally:
        conn.close()

    nome_arquivo = (
        f"CONSOLIDADO_ANUAL_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )
#-----------------------
#BOTÃO XLSX - TABELA GERAL
#-----------------------
@app.callback(
    Output("download-tabela-geral-xlsx", "data"),
    Input("btn-exportar-tabela-geral", "n_clicks"),
    State("busca-ticket-id", "value"),
    State("busca-archive-date", "value"),
    State("check-colunas", "value"),
    prevent_initial_call=True
)
def exportar_tabela_geral_xlsx(
    n_clicks,
    ticket_busca,
    periodo_busca,
    colunas_selecionadas
):

    if not n_clicks:
        raise PreventUpdate

    dados = df.copy()

    # Filtro Benutzer_ID
    if ticket_busca:
        dados = dados[
            dados["Benutzer_ID"]
            .astype(str)
            .str.contains(
                ticket_busca,
                case=False,
                na=False
            )
        ]

    # Filtro Periodo_Nome
    if periodo_busca:
        dados = dados[
            dados["Periodo_Nome"]
            .astype(str)
            .str.contains(
                periodo_busca,
                case=False,
                na=False
            )
        ]

    # Colunas selecionadas
    if colunas_selecionadas:
        dados = dados[colunas_selecionadas]

    nome_arquivo = (
        f"TABELA_GERAL_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )

    return dcc.send_data_frame(
        dados.to_excel,
        nome_arquivo,
        index=False,
        engine="openpyxl"
    )

@app.callback(
    Output("download-memoria-docx", "data"),
    Input("btn-exportar-memoria", "n_clicks"),
    prevent_initial_call=True
)
def manual_docx(n_clicks):
    os.makedirs('tempfile', exist_ok=True)
    documento = Document()
    documento.add_heading('Metodologias utilizadas para Cálculo dos Indicadores.:', level=1)
    tabela = documento.add_table(rows=18, cols=2)
    tabela.style = 'Table Grid'
    cabecalho = tabela.rows[0].cells
    linha1 = tabela.rows[1].cells
    linha2 = tabela.rows[2].cells
    cabecalho[0].text = 'COLUNA'
    cabecalho[1].text = 'CÁLCULO'
    linha1[0].text = 'KPI'
    linha1[1].text = '-'
    linha2[0].text = 'KPI'
    linha2[1].text = '-'
    
    documento.add_page_break()
    documento.save(r'.\tempfile\Metodologias.docx')
    return dcc.send_file(r'.\tempfile\Metodologias.docx')



# ==========================================
# EXECUÇÃO
# ==========================================
def abrir_navegador():
    webbrowser.open_new("http://127.0.0.1:8054")

if __name__ == "__main__":
    threading.Timer(1, abrir_navegador).start()
    app.run(debug=True,use_reloader=False,port=8054)