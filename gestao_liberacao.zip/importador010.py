import pandas as pd
import glob
import warnings
import os
import numpy as np
import sqlite3

pasta = os.path.dirname(__file__)
pasta_base = os.path.join(pasta,r'base\xlsx')
pasta_base_convertida = os.path.join(pasta,r'base_convertida')
pasta_base_compilada = os.path.join(pasta,r'base_compilada')
pasta_base_distribuicao = os.path.join(pasta,r'base_distribuicao')
pasta_base_sql = os.path.join(pasta, r'base_sql')
excel_indice_base = 'indice_base.xlsx'
excel_base_consolidada = 'base_consolidada.xlsx'
excel_base_adq = 'base_adq.xlsx'
excel_base_relatorio = 'base_relatorio.xlsx'
excel_base_extrato_mensal = 'extrato_periodo.xlsx'
excel_base_extrato_anual = 'extrato_anual.xlsx'
banco_geral = 'relatorio_geral.db'
banco_extrato_mensal = 'extrato_mensal.db'
banco_extrato_anual = 'extrato_anual.db'
arquivos_captura_glob = os.path.join(pasta_base,'*.xlsx')
pasta_indice = os.path.join(pasta,'base_convertida')
pacote_indice_base = os.path.join(pasta_base_convertida, excel_indice_base)
pacote_base_consolidada = os.path.join(pasta_base_convertida, excel_base_consolidada)
pacote_base_adq = os.path.join(pasta_base_convertida, excel_base_adq)
pacote_base_relatorio = os.path.join(pasta_base_compilada,excel_base_relatorio)
pacote_base_extrato_mensal = os.path.join(pasta_base_distribuicao, excel_base_extrato_mensal)
pacote_base_extrato_anual = os.path.join(pasta_base_distribuicao, excel_base_extrato_anual)
pacote_base_banco_geral = os.path.join(pasta_base_sql, banco_geral)
pacote_base_banco_mensal = os.path.join(pasta_base_sql, banco_extrato_mensal)
pacote_base_banco_anual = os.path.join(pasta_base_sql, banco_extrato_anual)

def cria_pastas():
    os.system('cls')
    os.makedirs('base_compilada', exist_ok=True)
    os.makedirs('base_convertida', exist_ok=True)
    os.makedirs('base_distribuicao', exist_ok=True)
    os.makedirs('base_sql', exist_ok=True)

def pacote_consulta():
    os.system('cls')
    lista_arquivo = []
    arquivos = glob.glob(arquivos_captura_glob)
    n_arquivos = len(arquivos)

    for arquivo in arquivos:
        lista_arquivo.append(arquivo)

    print('Total de arquivo(s) capturado(s).: {} arquivo(s) txt.'.format(n_arquivos))
    tabela = {'Ilustações Capuradas':lista_arquivo}
    df_tabela = pd.DataFrame(tabela)
    df_tabela.to_excel(pacote_indice_base, index=False)
    print('Arquivo indice_base.xlsx gerado com sucesso.')

def importador():

    lista_dfs = []
    lista_bases = []

    leitor = pd.read_excel(pacote_indice_base)
    n_linhas = len(leitor)

    warnings.filterwarnings(
        "ignore",
        category=UserWarning,
        module="openpyxl"
    )

    for i in range(n_linhas):

        nome_arquivo = leitor.iloc[i, 0]
        caminho_editado = nome_arquivo[119:]
        lista_bases.append(caminho_editado)

        print(f'Base {caminho_editado} convertida com sucesso.')

        planilhas = pd.read_excel(
            nome_arquivo,
            skiprows=2,
            sheet_name=None
        )

        for nome_aba, df in planilhas.items():

            df['Base'] = caminho_editado
            df['Aba'] = nome_aba

            lista_dfs.append(df)

    df_final = pd.concat(
        lista_dfs,
        ignore_index=True
    )

    #df_final['Bases'] = lista_bases
    df_final.to_excel(
        pacote_base_consolidada,
        index=False
    )

    print('Arquivo base_consolidada.xlsx gerado com sucesso.')

def adq():
    leitor = pd.read_excel(pacote_base_consolidada, usecols=range(0,16), skiprows=1)
    leitor = leitor[leitor.iloc[:,0] != 'Benutzer-ID']
    leitor.to_excel(pacote_base_adq, index=False)
    print('Arquivo base_adq.xlsx gerado com sucesso.')

def relatorio():
    lista_Statzart = ['Sn','Sa','Ka','Kn']

    #ler a base compilada.    
    leitor = pd.read_excel(pacote_base_adq)
    coluna = leitor.columns[14]
    leitor[coluna] = leitor[coluna].astype(str)
    leitor['Monat'] = leitor['Monat'].astype(str).str.replace(r'\.1$','.10',regex=True)
    leitor['Ano'] = leitor[coluna].str[:4].astype(int)
    leitor['Mes'] = leitor[coluna].str[5:7].astype(int)
    leitor['Mes_Nome'] = np.where(leitor['Mes'] == 1,'Janeiro',
                                      np.where(leitor['Mes'] == 2,'Fevereiro',
                                               np.where(leitor['Mes'] == 3,'Março',
                                                        np.where(leitor['Mes'] == 4,'Abril',
                                                                 np.where(leitor['Mes'] == 5,'Maio',
                                                                          np.where(leitor['Mes'] == 6,'Junho',
                                                                                   np.where(leitor['Mes'] == 7,'Julho',
                                                                                            np.where(leitor['Mes'] == 8,'Agosto',
                                                                                                     np.where(leitor['Mes'] == 9,'Setembro',
                                                                                                              np.where(leitor['Mes'] == 10,'Outubro',
                                                                                                                       np.where(leitor['Mes'] == 11,'Novembro',
                                                                                                                                np.where(leitor['Mes'] == 12,'Dezembro','-')))))))))),))
    leitor['Periodo'] = leitor['Mes'].astype(str)+'.'+leitor['Ano'].astype(str)
    leitor['Periodo_Nome'] = leitor['Mes_Nome'].astype(str)+'.'+leitor['Ano'].astype(str)
        
    leitor['Statzart_EQUIVALENTE'] = np.where(leitor['Statzart'] == 'Sn','Liberação',
                                                np.where(leitor['Statzart'] == 'Sa','Modificação',
                                                        np.where(leitor['Statzart'] == 'Ka','Catálogo',
                                                                    np.where(leitor['Statzart'] == 'Kn','Catálogo',
                                                                            'Não elegível para a Projeção.'))))
    leitor['IO'] = np.where(leitor['Statzart'].isin(lista_Statzart),1,0)
    leitor['Registro_liberacao'] = np.where(leitor['Statzart_EQUIVALENTE'] == 'Liberação',1,0)
    leitor['Registro_Modificacao'] = np.where(leitor['Statzart_EQUIVALENTE'] == 'Modificação',1,0)
    leitor['Registro_Catalogo'] = np.where(leitor['Statzart_EQUIVALENTE'] == 'Catálogo',1,0)
    #Consolidado da base Histórica
    leitor['Base_Histórica'] = sum(leitor['IO'])
    leitor['Base_Histórica_ID'] = (leitor.groupby('Benutzer-ID')['IO'].transform('sum'))
    leitor['percent_ID_HIST'] = (leitor['Base_Histórica_ID']/leitor['Base_Histórica']).round(4)
    #Consolidado da coluna libercao
    leitor['Consolidado_liberacao'] = sum(leitor['Registro_liberacao'])
    leitor['Consolidado_liberacao_ID'] = (leitor.groupby('Benutzer-ID')['Registro_liberacao'].transform('sum'))
    leitor['percent_lib_cons'] = (leitor['Consolidado_liberacao_ID']/leitor['Consolidado_liberacao']).round(4)
    #Consolidado da Coluna Modificacao
    leitor['Consolidado_Modificacao'] = sum(leitor['Registro_Modificacao'])
    leitor['Consolidado_Modificacao_ID'] = (leitor.groupby('Benutzer-ID')['Registro_Modificacao'].transform('sum'))
    leitor['percent_mod_cons'] = (leitor['Consolidado_Modificacao_ID']/leitor['Consolidado_Modificacao']).round(4)
    #Consolidado da Coluna Catalogo
    leitor['Consolidado_Catalogo'] = sum(leitor['Registro_Catalogo'])
    leitor['Consolidado_Catalogo_ID'] = (leitor.groupby('Benutzer-ID')['Registro_Catalogo'].transform('sum'))
    leitor['percent_cat_cons'] = (leitor['Consolidado_Catalogo_ID']/leitor['Consolidado_Catalogo']).round(4)
    #SOMASE POR PERÍODO
    leitor['Consolidado_Historico_Periodo'] = (leitor.groupby('Periodo_Nome')['IO'].transform('sum'))
    leitor['Consolidado_Historico_Periodo_ID'] = (leitor.groupby(['Periodo_Nome','Benutzer-ID'])['IO'].transform('sum'))
    leitor['percent_cons_hist_per'] = (leitor['Consolidado_Historico_Periodo_ID']/leitor['Consolidado_Historico_Periodo']).round(4)
    #SOMASE POR LIBERCAO/POR PERÍODO 
    leitor['Consolidado_liberacao_Periodo'] = (leitor.groupby('Periodo_Nome')['Registro_liberacao'].transform('sum'))
    leitor['Consolidado_liberacao_Periodo_ID'] = (leitor.groupby(['Periodo_Nome','Benutzer-ID'])['Registro_liberacao'].transform('sum'))
    leitor['percent_lib_cons_per'] = (leitor['Consolidado_liberacao_Periodo_ID']/leitor['Consolidado_liberacao_Periodo']).round(4)
    #SOMASE POR MODIFICACAO/POR PERÍODO 
    leitor['Consolidado_Modificacao_Periodo'] = (leitor.groupby('Periodo_Nome')['Registro_Modificacao'].transform('sum'))
    leitor['Consolidado_Modificacao_Periodo_ID'] = (leitor.groupby(['Periodo_Nome','Benutzer-ID'])['Registro_Modificacao'].transform('sum'))
    leitor['percent_mod_cons_per'] = (leitor['Consolidado_Modificacao_Periodo_ID']/leitor['Consolidado_Modificacao_Periodo']).round(4)
    #SOMASE POR CATALOGO/POR PERÍODO 
    leitor['Consolidado_Catalogo_Periodo'] = (leitor.groupby('Periodo_Nome')['Registro_Catalogo'].transform('sum'))
    leitor['Consolidado_Catalogo_Periodo_ID'] = (leitor.groupby(['Periodo_Nome','Benutzer-ID'])['Registro_Catalogo'].transform('sum'))
    leitor['percent_cat_cons_per'] = (leitor['Consolidado_Catalogo_Periodo_ID']/leitor['Consolidado_Catalogo_Periodo']).round(4)
    #contagem exclusiva por ano
    leitor['n_periodo_ano'] = (leitor.groupby('Ano')['Periodo_Nome']).transform('nunique')
    #CONSIDERAR PERCENT PARA MÉDIA DOS PERÍODO. DADO A PRODUÇÃO PROPOSTA PELA RAZÃO DO (PERÍODO/ID)
    #PARA MÉDIA DO ANO CONSIDERAR ANO/n_periodo_ano
    #SOMASE POR ANO
    leitor['Consolidado_Historico_Ano'] = (leitor.groupby('Ano')['IO'].transform('sum'))
    leitor['Consolidado_Historico_Ano_ID'] = (leitor.groupby(['Ano','Benutzer-ID'])['IO'].transform('sum'))
    leitor['percent_hist_ano_cons'] = (leitor['Consolidado_Historico_Ano_ID']/leitor['Consolidado_Historico_Ano']).round(4)
    leitor['media_ano'] = (leitor['Consolidado_Historico_Ano']/leitor['n_periodo_ano']).round(4)
    #SOMASE POR LIBERCAO/POR ANO
    leitor['Consolidado_liberacao_Ano'] = (leitor.groupby('Ano')['Registro_liberacao'].transform('sum'))
    leitor['Consolidado_liberacao_Ano_ID'] = (leitor.groupby(['Ano','Benutzer-ID'])['Registro_liberacao'].transform('sum'))
    leitor['percent_lib_ano_cons'] = (leitor['Consolidado_liberacao_Ano_ID']/leitor['Consolidado_liberacao_Ano']).round(4)
    leitor['media_lib_ano'] = (leitor['Consolidado_liberacao_Ano']/leitor['n_periodo_ano']).round(4)
    #SOMASE POR MODIFICACAO/POR ANO
    leitor['Consolidado_Modificacao_Ano'] = (leitor.groupby('Ano')['Registro_Modificacao'].transform('sum'))
    leitor['Consolidado_Modificacao_Ano_ID'] = (leitor.groupby(['Ano','Benutzer-ID'])['Registro_Modificacao'].transform('sum'))
    leitor['percent_modi_ano_cons'] = (leitor['Consolidado_Modificacao_Ano_ID']/leitor['Consolidado_Modificacao_Ano']).round(2)
    leitor['media_modi_ano'] = (leitor['Consolidado_Modificacao_Ano']/leitor['n_periodo_ano']).round(4)
    #SOMASE POR MODIFICACAO/POR ANO
    leitor['Consolidado_Catalogo_Ano'] = (leitor.groupby('Ano')['Registro_Catalogo'].transform('sum'))
    leitor['Consolidado_Catalogo_Ano_ID'] = (leitor.groupby(['Ano','Benutzer-ID'])['Registro_Catalogo'].transform('sum'))
    leitor['percent_cat_ano_cons'] = (leitor['Consolidado_Catalogo_Ano_ID']/leitor['Consolidado_Catalogo_Ano']).round(4)
    leitor['media_cat_ano'] = (leitor['Consolidado_Catalogo_Ano']/leitor['n_periodo_ano']).round(4)
    leitor['distribuicao_hist_per'] = (leitor['Consolidado_Historico_Periodo']/leitor['Consolidado_Historico_Periodo']).round(4)
    leitor['distribuicao_lib_per'] = (leitor['Consolidado_liberacao_Periodo']/leitor['Consolidado_Historico_Periodo']).round(4)
    leitor['distribuicao_mod_per'] = (leitor['Consolidado_Modificacao_Periodo']/leitor['Consolidado_Historico_Periodo']).round(4)
    leitor['distribuicao_cat_per'] = (leitor['Consolidado_Catalogo_Periodo']/leitor['Consolidado_Historico_Periodo']).round(4)
    leitor['distribuicao_hist_Ano'] = (leitor['Consolidado_Historico_Ano']/leitor['Consolidado_Historico_Ano']).round(4)
    leitor['distribuicao_lib_Ano'] = (leitor['Consolidado_liberacao_Ano']/leitor['Consolidado_Historico_Ano']).round(4)
    leitor['distribuicao_Mod_Ano'] = (leitor['Consolidado_Modificacao_Ano']/leitor['Consolidado_Historico_Ano']).round(4)
    leitor['distribuicao_Cat_Ano'] = (leitor['Consolidado_Catalogo_Ano']/leitor['Consolidado_Historico_Ano']).round(4)
    leitor['Pagina'] = np.where(leitor['Textseite'].notna(),'1','Sem nº de página')
    #leitor['Pagina_Periodo'] = (leitor.groupby('Textseite')['Periodo_Nome']).transform('count')
    leitor['Pagina_Periodo'] = (leitor.groupby(['Textseite', 'Periodo_Nome'])['Textseite'].transform('count'))
    leitor['Consolidado_Pagina_Periodo'] = (leitor.groupby('Periodo_Nome')['Pagina_Periodo'].transform(lambda x: x.drop_duplicates().sum()))
    leitor['N_Paginadas'] = (np.where(leitor['Pagina'] == 'Sem nº de página','1','0')).astype(int)
    leitor['N_Paginadas_Periodo'] = leitor.groupby('Periodo_Nome')['N_Paginadas'].transform('sum')
    leitor['Consolidado_N_Paginadas_Periodo'] = (leitor.groupby('Periodo_Nome')['N_Paginadas_Periodo'].transform(lambda x: x.drop_duplicates().sum()))
    leitor['Pagina_Ano'] = (leitor.groupby(['Textseite', 'Ano'])['Textseite'].transform('count'))
    leitor['Consolidado_Pagina_Ano'] = (leitor.groupby('Ano')['Pagina_Ano'].transform(lambda x: x.drop_duplicates().sum()))
    leitor['N_Paginadas_Ano'] = leitor.groupby('Ano')['N_Paginadas'].transform('sum')
    leitor['Consolidado_N_Paginadas_Ano'] = (leitor.groupby('Ano')['N_Paginadas_Ano'].transform(lambda x: x.drop_duplicates().sum()))
    leitor.to_excel(pacote_base_relatorio, index=False)
    print('Arquivo base_relatorio.xlsx gerado com sucesso.')

def compilacao001():
    leitor = pd.read_excel(pacote_base_relatorio)
    leitor_extrato = (leitor.filter(items=['Monat','Ano','Periodo_Nome','Benutzer-ID',
                                           'Consolidado_Historico_Periodo_ID','Consolidado_Historico_Periodo',
                                           'percent_cons_hist_per','Consolidado_liberacao_Periodo_ID',
                                           'Consolidado_liberacao_Periodo','percent_lib_cons_per',
                                           'Consolidado_Modificacao_Periodo_ID','Consolidado_Modificacao_Periodo',
                                           'percent_mod_cons_per','Consolidado_Catalogo_Periodo_ID',
                                           'Consolidado_Catalogo_Periodo','percent_cat_cons_per','distribuicao_hist_per',
                                           'distribuicao_lib_per','distribuicao_mod_per','distribuicao_cat_per',
                                           'Pagina_Periodo','N_Paginadas_Periodo','Consolidado_Pagina_Periodo',
                                           'Consolidado_N_Paginadas_Periodo']).drop_duplicates()
        
                      .sort_values(by='Monat', ascending=True))
    leitor_extrato.to_excel(pacote_base_extrato_mensal , index=False)

def compilacao002():
    leitor = pd.read_excel(pacote_base_relatorio)
    leitor_extrato = (leitor.filter(items=['Monat','Ano','Periodo_Nome','n_periodo_ano',
                                           'Consolidado_Historico_Ano','Consolidado_Historico_Periodo','media_ano',
                                           'Consolidado_liberacao_Ano','Consolidado_liberacao_Periodo','media_lib_ano',
                                           'Consolidado_Modificacao_Ano','Consolidado_Modificacao_Periodo','media_modi_ano',
                                           'Consolidado_Catalogo_Ano','Consolidado_Catalogo_Periodo','media_cat_ano',
                                           'distribuicao_hist_Ano','distribuicao_lib_Ano','distribuicao_Mod_Ano',
                                           'distribuicao_Cat_Ano','N_Paginadas_Ano','Consolidado_N_Paginadas_Ano',
                                           'Consolidado_Pagina_Ano']).drop_duplicates()
        
                      .sort_values(by='Monat', ascending=True))
    leitor_extrato.to_excel(pacote_base_extrato_anual, index=False)

def criar_banco(pacote_base_banco_geral):
    conexao = sqlite3.connect(pacote_base_banco_geral)
    cursor = conexao.cursor()
    cursor = cursor.execute('''
    CREATE TABLE IF NOT EXISTS geral_tabela(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    Benutzer_ID TEXT,
    Statzart TEXT,
    Teilenummer TEXT,
    Kurztext TEXT,
    EAY TEXT,
    Katalog_ID TEXT,
    Textseite TEXT,
    Freigabe_Datum TEXT,
    Freigabe_User TEXT,
    Sachgebiet TEXT,
    SG2 TEXT,
    Tag TEXT,
    Datum TEXT,
    Woche TEXT,
    Monat TEXT,
    Ano INTEGER,
    Mes TEXT,
    Mes_Nome TEXT,
    Periodo TEXT,
    Periodo_Nome TEXT,
    Statzart_EQUIVALENTE TEXT,
    IO TEXT,
    Registro_liberacao TEXT,
    Registro_Modificacao TEXT,
    Registro_Catalogo TEXT,
    Base_Histórica TEXT,
    Base_Histórica_ID TEXT,
    percent_ID_HIST TEXT,
    Consolidado_liberacao TEXT,
    Consolidado_liberacao_ID TEXT,
    percent_lib_cons TEXT,
    Consolidado_Modificacao TEXT,
    Consolidado_Modificacao_ID TEXT,
    percent_mod_cons TEXT,
    Consolidado_Catalogo TEXT,
    Consolidado_Catalogo_ID TEXT,
    percent_cat_cons TEXT,
    Consolidado_Historico_Periodo TEXT,
    Consolidado_Historico_Periodo_ID TEXT,
    percent_cons_hist_per TEXT,
    Consolidado_liberacao_Periodo INTEGER,
    Consolidado_liberacao_Periodo_ID INTEGER,
    percent_lib_cons_per TEXT,
    Consolidado_Modificacao_Periodo INTEGER,
    Consolidado_Modificacao_Periodo_ID INTEGER,
    percent_mod_cons_per TEXT,
    Consolidado_Catalogo_Periodo INTEGER,
    Consolidado_Catalogo_Periodo_ID INTEGER,
    percent_cat_cons_per TEXT,
    n_periodo_ano TEXT,
    Consolidado_Historico_Ano TEXT,
    Consolidado_Historico_Ano_ID TEXT,
    percent_hist_ano_cons TEXT,
    media_ano TEXT,
    Consolidado_liberacao_Ano TEXT,
    Consolidado_liberacao_Ano_ID TEXT,
    percent_lib_ano_cons TEXT,
    media_lib_ano TEXT,
    Consolidado_Modificacao_Ano TEXT,
    Consolidado_Modificacao_Ano_ID TEXT,
    percent_modi_ano_cons TEXT,
    media_modi_ano TEXT,
    Consolidado_Catalogo_Ano TEXT,
    Consolidado_Catalogo_Ano_ID TEXT,
    percent_cat_ano_cons TEXT,
    media_cat_ano TEXT,
    distribuicao_hist_per TEXT,
    distribuicao_lib_per TEXT,
    distribuicao_mod_per TEXT,
    distribuicao_cat_per TEXT,
    distribuicao_hist_Ano TEXT,
    distribuicao_lib_Ano TEXT,
    distribuicao_Mod_Ano TEXT,
    distribuicao_Cat_Ano TEXT
    )
    ''')
    conexao.commit()
    conexao.close()
    print('geral_tabela criada com sucesso!!!')

def criar_banco002():
    conexao = sqlite3.connect(pacote_base_banco_mensal)
    cursor = conexao.cursor()
    cursor = cursor.execute('''
    CREATE TABLE IF NOT EXISTS tabela_extrato_mensal(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    Monat TEXT,
    Ano INTEGER,
    Periodo_Nome TEXT,
    Benutzer_ID TEXT,
    Consolidado_Historico_Periodo_ID TEXT,
    Consolidado_Historico_Periodo TEXT,
    percent_cons_hist_per TEXT,
    Consolidado_liberacao_Periodo_ID INTEGER,
    Consolidado_liberacao_Periodo INTEGER,
    percent_lib_cons_per TEXT,
    Consolidado_Modificacao_Periodo_ID INTEGER,
    Consolidado_Modificacao_Periodo INTEGER,
    percent_mod_cons_per TEXT,
    Consolidado_Catalogo_Periodo_ID INTEGER,
    Consolidado_Catalogo_Periodo INTEGER,
    percent_cat_cons_per TEXT,
    distribuicao_hist_per TEXT,
    distribuicao_lib_per TEXT,
    distribuicao_mod_per TEXT,
    distribuicao_cat_per TEXT,
    Pagina_Periodo INTEGER,
    N_Paginadas_Periodo INTEGER,
    Consolidado_Pagina_Periodo INTEGER,
    Consolidado_N_Paginadas_Periodo INTEGER
    )
    ''')
    conexao.commit()
    conexao.close()
    print('tabela_extrato_mensal criada com sucesso!!!')

def criar_banco003():
    conexao = sqlite3.connect(pacote_base_banco_anual)
    cursor = conexao.cursor()
    cursor = cursor.execute('''
    CREATE TABLE IF NOT EXISTS tabela_extrato_anual(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    Monat TEXT,
    Ano INTEGER,
    Periodo_Nome TEXT,
    n_periodo_ano TEXT,
    Consolidado_Historico_Ano INTEGER,
    Consolidado_Historico_Periodo INTEGER,
    media_ano TEXT,
    Consolidado_liberacao_Ano INTEGER,
    Consolidado_liberacao_Periodo INTEGER,
    media_lib_ano TEXT,
    Consolidado_Modificacao_Ano INTEGER,
    Consolidado_Modificacao_Periodo INTEGER,
    media_modi_ano TEXT,
    Consolidado_Catalogo_Ano INTEGER,
    Consolidado_Catalogo_Periodo INTEGER,
    media_cat_ano TEXT,
    distribuicao_hist_Ano TEXT,
    distribuicao_lib_Ano TEXT,
    distribuicao_Mod_Ano TEXT,
    distribuicao_Cat_Ano TEXT,
    N_Paginadas_Ano INTEGER,
    Consolidado_N_Paginadas_Ano INTEGER,
    Consolidado_Pagina_Ano INTEGER
    )
    ''')
    conexao.commit()
    conexao.close()
    print('tabela_extrato_anual criada com sucesso!!!')

def importar_banco001(pacote_base_relatorio):
    leitor = pd.read_excel(pacote_base_relatorio)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(pacote_base_banco_geral)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO geral_tabela(
    Benutzer_ID,
    Statzart,
    Teilenummer,
    Kurztext,
    EAY,
    Katalog_ID,
    Textseite,
    Freigabe_Datum,
    Freigabe_User,
    Sachgebiet,
    SG2,
    Tag,
    Datum,
    Woche,
    Monat,
    Ano,
    Mes,
    Mes_Nome,
    Periodo,
    Periodo_Nome,
    Statzart_EQUIVALENTE,
    IO,
    Registro_liberacao,
    Registro_Modificacao,
    Registro_Catalogo,
    Base_Histórica,
    Base_Histórica_ID,
    percent_ID_HIST,
    Consolidado_liberacao,
    Consolidado_liberacao_ID,
    percent_lib_cons,
    Consolidado_Modificacao,
    Consolidado_Modificacao_ID,
    percent_mod_cons,
    Consolidado_Catalogo,
    Consolidado_Catalogo_ID,
    percent_cat_cons,
    Consolidado_Historico_Periodo,
    Consolidado_Historico_Periodo_ID,
    percent_cons_hist_per,
    Consolidado_liberacao_Periodo,
    Consolidado_liberacao_Periodo_ID,
    percent_lib_cons_per,
    Consolidado_Modificacao_Periodo,
    Consolidado_Modificacao_Periodo_ID,
    percent_mod_cons_per,
    Consolidado_Catalogo_Periodo,
    Consolidado_Catalogo_Periodo_ID,
    percent_cat_cons_per,
    n_periodo_ano,
    Consolidado_Historico_Ano,
    Consolidado_Historico_Ano_ID,
    percent_hist_ano_cons,
    media_ano,
    Consolidado_liberacao_Ano,
    Consolidado_liberacao_Ano_ID,
    percent_lib_ano_cons,   
    media_lib_ano,
    Consolidado_Modificacao_Ano,
    Consolidado_Modificacao_Ano_ID,
    percent_modi_ano_cons,
    media_modi_ano,
    Consolidado_Catalogo_Ano,
    Consolidado_Catalogo_Ano_ID,
    percent_cat_ano_cons,
    media_cat_ano,
    distribuicao_hist_per,
    distribuicao_lib_per,
    distribuicao_mod_per,
    distribuicao_cat_per,
    distribuicao_hist_Ano,
    distribuicao_lib_Ano,
    distribuicao_Mod_Ano,
    distribuicao_Cat_Ano)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,
?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,
?,?,?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]),
                    str(leitor.iloc[a,8]),
                    str(leitor.iloc[a,9]),
                    str(leitor.iloc[a,10]),
                    str(leitor.iloc[a,11]),
                    str(leitor.iloc[a,12]),
                    str(leitor.iloc[a,13]),
                    str(leitor.iloc[a,14]),
                    str(leitor.iloc[a,15]),
                    str(leitor.iloc[a,16]),
                    str(leitor.iloc[a,17]),
                    str(leitor.iloc[a,18]),
                    str(leitor.iloc[a,19]),
                    str(leitor.iloc[a,20]),
                    str(leitor.iloc[a,21]),
                    str(leitor.iloc[a,22]),
                    str(leitor.iloc[a,23]),
                    str(leitor.iloc[a,24]),
                    str(leitor.iloc[a,25]),
                    str(leitor.iloc[a,26]),
                    str(leitor.iloc[a,27]),
                    str(leitor.iloc[a,28]),
                    str(leitor.iloc[a,29]),
                    str(leitor.iloc[a,30]),
                    str(leitor.iloc[a,31]),
                    str(leitor.iloc[a,32]),
                    str(leitor.iloc[a,33]),
                    str(leitor.iloc[a,34]),
                    str(leitor.iloc[a,35]),
                    str(leitor.iloc[a,36]),
                    str(leitor.iloc[a,37]),
                    str(leitor.iloc[a,38]),
                    str(leitor.iloc[a,39]),
                    str(leitor.iloc[a,40]),
                    str(leitor.iloc[a,41]),
                    str(leitor.iloc[a,42]),
                    str(leitor.iloc[a,43]),
                    str(leitor.iloc[a,44]),
                    str(leitor.iloc[a,45]),
                    str(leitor.iloc[a,46]),
                    str(leitor.iloc[a,47]),
                    str(leitor.iloc[a,48]),
                    str(leitor.iloc[a,49]),
                    str(leitor.iloc[a,50]),
                    str(leitor.iloc[a,51]),
                    str(leitor.iloc[a,52]),
                    str(leitor.iloc[a,53]),
                    str(leitor.iloc[a,54]),
                    str(leitor.iloc[a,55]),
                    str(leitor.iloc[a,56]),
                    str(leitor.iloc[a,57]),
                    str(leitor.iloc[a,58]),
                    str(leitor.iloc[a,59]),
                    str(leitor.iloc[a,60]),
                    str(leitor.iloc[a,61]),
                    str(leitor.iloc[a,62]),
                    str(leitor.iloc[a,63]),
                    str(leitor.iloc[a,64]),
                    str(leitor.iloc[a,65]),
                    str(leitor.iloc[a,66]),
                    str(leitor.iloc[a,67]),
                    str(leitor.iloc[a,68]),
                    str(leitor.iloc[a,69]),
                    str(leitor.iloc[a,70]),
                    str(leitor.iloc[a,71]),
                    str(leitor.iloc[a,72]),
                    str(leitor.iloc[a,73])
                   )
        
        cursor.execute(query, valores)
        print(f'{leitor.iloc[a,19]} - {pacote_base_relatorio} ok.')
    conexao.commit()
    conexao.close()
    print('geral_tabela importada com sucesso!!!')

def importar_banco002(pacote_base_extrato_mensal):
    leitor = pd.read_excel(pacote_base_extrato_mensal)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(pacote_base_banco_mensal)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO tabela_extrato_mensal(
    Monat,
    Ano,
    Periodo_Nome,
    Benutzer_ID,
    Consolidado_Historico_Periodo_ID,
    Consolidado_Historico_Periodo,
    percent_cons_hist_per,
    Consolidado_liberacao_Periodo_ID,
    Consolidado_liberacao_Periodo,
    percent_lib_cons_per,
    Consolidado_Modificacao_Periodo_ID,
    Consolidado_Modificacao_Periodo,
    percent_mod_cons_per,
    Consolidado_Catalogo_Periodo_ID,
    Consolidado_Catalogo_Periodo,
    percent_cat_cons_per,
    distribuicao_hist_per,
    distribuicao_lib_per,
    distribuicao_mod_per,
    distribuicao_cat_per,
    Pagina_Periodo,
    Consolidado_Pagina_Periodo,
    Consolidado_N_Paginadas_Periodo
    )
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]),
                    str(leitor.iloc[a,8]),
                    str(leitor.iloc[a,9]),
                    str(leitor.iloc[a,10]),
                    str(leitor.iloc[a,11]),
                    str(leitor.iloc[a,12]),
                    str(leitor.iloc[a,13]),
                    str(leitor.iloc[a,14]),
                    str(leitor.iloc[a,15]),
                    str(leitor.iloc[a,16]),
                    str(leitor.iloc[a,17]),
                    str(leitor.iloc[a,18]),
                    str(leitor.iloc[a,19]),
                    str(leitor.iloc[a,20]),
                    str(leitor.iloc[a,22]),
                    str(leitor.iloc[a,23])
                   )
        
        cursor.execute(query, valores)
        print(f'{leitor.iloc[a,2]} - {pacote_base_extrato_mensal} ok.')
    conexao.commit()
    conexao.close()
    print('tabela_extrato_mensal importada com sucesso!!!')

def importar_banco003(pacote_base_extrato_anual):
    leitor = pd.read_excel(pacote_base_extrato_anual)
    conta_linhas = len(leitor)

    conexao = sqlite3.connect(pacote_base_banco_anual)
    cursor = conexao.cursor()
    query = '''
    INSERT OR IGNORE INTO tabela_extrato_anual(
    Monat,
    Ano,
    Periodo_Nome,
    n_periodo_ano,
    Consolidado_Historico_Ano,
    Consolidado_Historico_Periodo,
    media_ano,
    Consolidado_liberacao_Ano,
    Consolidado_liberacao_Periodo,
    media_lib_ano,
    Consolidado_Modificacao_Ano,
    Consolidado_Modificacao_Periodo,
    media_modi_ano,
    Consolidado_Catalogo_Ano,
    Consolidado_Catalogo_Periodo,
    media_cat_ano,
    distribuicao_hist_Ano,
    distribuicao_lib_Ano,
    distribuicao_Mod_Ano,
    distribuicao_Cat_Ano,
    N_Paginadas_Ano,
    Consolidado_N_Paginadas_Ano,
    Consolidado_Pagina_Ano
    )
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    '''
    for a in range(conta_linhas):
        valores = (str(leitor.iloc[a,0]),
                    str(leitor.iloc[a,1]),
                    str(leitor.iloc[a,2]),
                    str(leitor.iloc[a,3]),
                    str(leitor.iloc[a,4]),
                    str(leitor.iloc[a,5]),
                    str(leitor.iloc[a,6]),
                    str(leitor.iloc[a,7]),
                    str(leitor.iloc[a,8]),
                    str(leitor.iloc[a,9]),
                    str(leitor.iloc[a,10]),
                    str(leitor.iloc[a,11]),
                    str(leitor.iloc[a,12]),
                    str(leitor.iloc[a,13]),
                    str(leitor.iloc[a,14]),
                    str(leitor.iloc[a,15]),
                    str(leitor.iloc[a,16]),
                    str(leitor.iloc[a,17]),
                    str(leitor.iloc[a,18]),
                    str(leitor.iloc[a,19]),
                    str(leitor.iloc[a,20]),
                    str(leitor.iloc[a,21]),
                    str(leitor.iloc[a,22])
                   )
        
        cursor.execute(query, valores)
        print(f'{leitor.iloc[a,2]} - {pacote_base_extrato_anual} ok.')
    conexao.commit()
    conexao.close()
    print('tabela_extrato_anual importada com sucesso!!!')


cria_pastas()
pacote_consulta()
importador()
adq()
relatorio()
compilacao001()
compilacao002()
criar_banco(pacote_base_banco_geral)
criar_banco002()
criar_banco003()
importar_banco001(pacote_base_relatorio)
importar_banco002(pacote_base_extrato_mensal)
importar_banco003(pacote_base_extrato_anual)